package android.support.v4.app;

import android.view.View;

abstract interface FragmentContainer
{
  public abstract View findViewById(int paramInt);
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     android.support.v4.app.FragmentContainer
 * JD-Core Version:    0.7.1
 */