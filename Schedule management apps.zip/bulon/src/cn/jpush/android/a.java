package cn.jpush.android;

import android.app.Application;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Build.VERSION;
import android.os.Bundle;
import cn.jpush.android.api.i;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.c.v;
import java.util.concurrent.atomic.AtomicBoolean;

public final class a
{
  public static int a;
  public static String b;
  public static String c;
  public static Context d;
  public static String e;
  public static String f;
  public static int g;
  public static String h;
  public static boolean i;
  private static AtomicBoolean j;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[19];
    int k = 0;
    String str1 = "}\033T\017";
    int m = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int n = localObject3.length;
    int i1 = 0;
    label36:
    Object localObject4;
    int i2;
    int i3;
    Object localObject5;
    label52:
    int i4;
    int i5;
    if (n <= 1)
    {
      localObject4 = localObject3;
      i2 = i1;
      i3 = n;
      localObject5 = localObject3;
      i4 = localObject5[i1];
      switch (i2 % 5)
      {
      default: 
        i5 = 47;
      }
    }
    for (;;)
    {
      localObject5[i1] = ((char)(i5 ^ i4));
      i1 = i2 + 1;
      if (i3 == 0)
      {
        localObject5 = localObject4;
        i2 = i1;
        i1 = i3;
        break label52;
      }
      n = i3;
      localObject3 = localObject4;
      if (n > i1) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (m)
      {
      default: 
        localObject1[k] = str2;
        k = 1;
        str1 = "";
        localObject1 = localObject2;
        m = 0;
        break;
      case 0: 
        localObject1[k] = str2;
        k = 2;
        str1 = "C9t9gV(q:dL0";
        m = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[k] = str2;
        k = 3;
        str1 = "";
        m = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[k] = str2;
        k = 4;
        str1 = "d\fU\013Kh\035@P\017j\001@\004Al\005\001G\017";
        m = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[k] = str2;
        k = 5;
        str1 = "";
        m = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[k] = str2;
        k = 6;
        str1 = "o\bM\031J";
        m = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[k] = str2;
        k = 7;
        str1 = "d\fU\013Kh\035@P\017h\031Q!JpI\fJ";
        m = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[k] = str2;
        k = 8;
        str1 = "G&\001\034J{\032H\005AJ\006E\017\017f\033\001\034J{\032H\005AG\bL\017\017m\fG\003Al\r\001\003A)\004@\004Fo\fR\036\001";
        m = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[k] = str2;
        k = 9;
        str1 = "";
        m = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[k] = str2;
        k = 10;
        str1 = "C9t9gV*i+aG,m";
        m = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[k] = str2;
        k = 11;
        str1 = "%Iq\006Jh\032DJHl\035\001\023@|\033\001+_y\002D\023\017o\033N\007\017y\006S\036NeH";
        m = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[k] = str2;
        k = 12;
        str1 = "c\bW\013\001g\fUD_{\fG\017]@9W^|}\bB\001";
        m = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[k] = str2;
        k = 13;
        str1 = "";
        m = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[k] = str2;
        k = 14;
        str1 = "";
        m = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[k] = str2;
        k = 15;
        str1 = "c\bW\013\001g\fUD_{\fG\017]@9W\\nm\rS\017\\z\fR";
        m = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[k] = str2;
        k = 16;
        str1 = "d\fU\013Kh\035@P\017j\001@\004Al\005\001G\017g\006UJKl\017H\004JmIH\004\017d\bO\003Il\032U";
        m = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[k] = str2;
        k = 17;
        str1 = "Z\fS\034Fj\f";
        m = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[k] = str2;
        k = 18;
        str1 = "@\007W\013C`\r\001\013_y\"D\023\0173I";
        m = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[k] = str2;
        z = (String[])localObject2;
        j = new AtomicBoolean(false);
        i = false;
        return;
        i5 = 9;
        continue;
        i5 = 105;
        continue;
        i5 = 33;
        continue;
        i5 = 106;
      }
    }
  }
  
  public static boolean a(Context paramContext)
  {
    if (j.get()) {
      return true;
    }
    r.b();
    v.a(paramContext.getApplicationContext());
    ApplicationInfo localApplicationInfo1 = b(paramContext);
    if (localApplicationInfo1 == null)
    {
      r.e(z[17], z[3]);
      return false;
    }
    try
    {
      PackageInfo localPackageInfo = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 0);
      g = localPackageInfo.versionCode;
      String str3 = localPackageInfo.versionName;
      h = str3;
      if (str3.length() > 30) {
        h = h.substring(0, 30);
      }
      d = paramContext.getApplicationContext();
      if ((Build.VERSION.SDK_INT >= 14) && ((paramContext instanceof Application)))
      {
        boolean bool = cn.jpush.android.c.a.i(paramContext);
        i.a = bool;
        if (bool) {
          i.a((Application)paramContext.getApplicationContext());
        }
      }
      b = paramContext.getPackageName();
      a = localApplicationInfo1.icon;
      if (a == 0) {
        r.e(z[17], z[5]);
      }
      c = paramContext.getPackageManager().getApplicationLabel(localApplicationInfo1).toString();
      try
      {
        ApplicationInfo localApplicationInfo2 = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 128);
        if (localApplicationInfo2 == null) {
          break label292;
        }
        localBundle = localApplicationInfo2.metaData;
      }
      catch (PackageManager.NameNotFoundException localNameNotFoundException)
      {
        Bundle localBundle;
        for (;;)
        {
          String str1;
          r.a(z[17], z[14], localNameNotFoundException);
          localBundle = null;
        }
        if (f.length() == 24) {
          break label388;
        }
        r.e(z[17], z[18] + f + z[11]);
        return false;
        r.b(z[17], z[7] + f);
        String str2 = localBundle.getString(z[10]);
        e = str2;
        if (!ac.a(str2)) {
          break label508;
        }
      }
      if (localBundle == null) {
        break label541;
      }
      str1 = localBundle.getString(z[2]);
      f = str1;
      if (ac.a(str1))
      {
        r.e(z[17], z[13]);
        return false;
      }
    }
    catch (Exception localException)
    {
      for (;;)
      {
        r.b(z[17], z[8]);
        continue;
        label292:
        r.b(z[17], z[1]);
        localBundle = null;
      }
    }
    label388:
    r.b(z[17], z[16]);
    for (;;)
    {
      if (Build.VERSION.SDK_INT == 8)
      {
        System.setProperty(z[12], z[0]);
        System.setProperty(z[15], z[6]);
      }
      j.set(true);
      return true;
      label508:
      r.b(z[17], z[4] + e);
      continue;
      label541:
      r.b(z[17], z[9]);
    }
  }
  
  private static ApplicationInfo b(Context paramContext)
  {
    try
    {
      ApplicationInfo localApplicationInfo = paramContext.getPackageManager().getApplicationInfo(paramContext.getPackageName(), 0);
      return localApplicationInfo;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      r.b(z[17], z[14], localNameNotFoundException);
    }
    return null;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a
 * JD-Core Version:    0.7.1
 */