package cn.jpush.android;

public final class d
  extends Exception
{
  public d() {}
  
  public d(String paramString)
  {
    super(paramString);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.d
 * JD-Core Version:    0.7.1
 */