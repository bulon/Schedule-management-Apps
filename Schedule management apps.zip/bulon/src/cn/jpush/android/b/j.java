package cn.jpush.android.b;

import android.net.wifi.ScanResult;
import cn.jpush.android.c.r;
import org.json.JSONObject;

public final class j
  implements Comparable<j>
{
  private static final String[] z;
  public final String a;
  public final int b;
  public final String c;
  
  static
  {
    String[] arrayOfString1 = new String[4];
    String str1 = "8x%cB'N1yQ.%yK";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 35;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "8b+i";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "&p!RB/u0hP8";
        j = 2;
        arrayOfString2 = arrayOfString1;
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        j = 3;
        arrayOfString2 = arrayOfString1;
        str1 = "*v'";
        i = 2;
        break;
      case 2: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 75;
        break label96;
        i3 = 17;
        break label96;
        i3 = 66;
        break label96;
        i3 = 13;
        break label96;
        m = 0;
      }
    }
  }
  
  public j(i parami, ScanResult paramScanResult)
  {
    this.a = paramScanResult.BSSID;
    this.b = paramScanResult.level;
    this.c = paramScanResult.SSID;
  }
  
  public j(i parami, String paramString1, int paramInt, String paramString2)
  {
    this.a = paramString1;
    this.b = paramInt;
    this.c = paramString2;
  }
  
  public final JSONObject a()
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      String str1 = this.a;
      localJSONObject.put(z[2], str1);
      int i = this.b;
      localJSONObject.put(z[0], i);
      String str2 = this.c;
      localJSONObject.put(z[1], str2);
      localJSONObject.put(z[3], 0);
      return localJSONObject;
    }
    catch (Exception localException)
    {
      r.i();
    }
    return localJSONObject;
  }
  
  public final boolean equals(Object paramObject)
  {
    if (paramObject == this) {}
    j localj;
    do
    {
      return true;
      if (!(paramObject instanceof j)) {
        break;
      }
      localj = (j)paramObject;
    } while ((localj.b == this.b) && (localj.a.equals(this.a)));
    return false;
  }
  
  public final int hashCode()
  {
    return this.b ^ this.a.hashCode();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.b.j
 * JD-Core Version:    0.7.1
 */