package cn.jpush.android.b;

import android.telephony.CellLocation;
import android.telephony.PhoneStateListener;

final class c
  extends PhoneStateListener
{
  c(b paramb) {}
  
  public final void onCellLocationChanged(CellLocation paramCellLocation)
  {
    b.a(this.a, false);
  }
  
  public final void onSignalStrengthChanged(int paramInt)
  {
    b.a(this.a, paramInt);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.b.c
 * JD-Core Version:    0.7.1
 */