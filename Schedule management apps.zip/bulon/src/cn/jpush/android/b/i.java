package cn.jpush.android.b;

import android.content.Context;
import android.net.wifi.ScanResult;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import cn.jpush.android.c.r;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;

public final class i
{
  private static final String z;
  private WifiManager a;
  
  static
  {
    Object localObject1 = "he\th".toCharArray();
    int i = localObject1.length;
    int j = 0;
    Object localObject2;
    int k;
    int m;
    Object localObject3;
    label27:
    int n;
    int i1;
    if (i <= 1)
    {
      localObject2 = localObject1;
      k = j;
      m = i;
      localObject3 = localObject1;
      n = localObject3[j];
      switch (k % 5)
      {
      default: 
        i1 = 29;
      }
    }
    for (;;)
    {
      localObject3[j] = ((char)(i1 ^ n));
      j = k + 1;
      if (m == 0)
      {
        localObject3 = localObject2;
        k = j;
        j = m;
        break label27;
      }
      i = m;
      localObject1 = localObject2;
      if (i > j) {
        break;
      }
      z = new String((char[])localObject1).intern();
      return;
      i1 = 31;
      continue;
      i1 = 12;
      continue;
      i1 = 111;
      continue;
      i1 = 1;
    }
  }
  
  public i(Context paramContext)
  {
    this.a = ((WifiManager)paramContext.getSystemService(z));
  }
  
  private List<j> d()
  {
    if (!a()) {
      return new ArrayList();
    }
    WifiInfo localWifiInfo = this.a.getConnectionInfo();
    if (localWifiInfo != null) {}
    for (j localj1 = new j(this, localWifiInfo.getBSSID(), localWifiInfo.getRssi(), localWifiInfo.getSSID());; localj1 = null)
    {
      ArrayList localArrayList = new ArrayList();
      if (localj1 != null) {
        localArrayList.add(localj1);
      }
      List localList = this.a.getScanResults();
      if ((localList != null) && (localList.size() > 0))
      {
        Iterator localIterator = localList.iterator();
        while (localIterator.hasNext())
        {
          j localj2 = new j(this, (ScanResult)localIterator.next());
          if (!localj2.c.equals(localj1.c)) {
            localArrayList.add(localj2);
          }
        }
      }
      return localArrayList;
    }
  }
  
  public final boolean a()
  {
    try
    {
      boolean bool = this.a.isWifiEnabled();
      return bool;
    }
    catch (Exception localException)
    {
      r.i();
    }
    return false;
  }
  
  public final WifiManager b()
  {
    return this.a;
  }
  
  public final JSONArray c()
  {
    localJSONArray = new JSONArray();
    try
    {
      Iterator localIterator = d().iterator();
      for (;;)
      {
        if (!localIterator.hasNext()) {
          return localJSONArray;
        }
        localJSONArray.put(((j)localIterator.next()).a());
      }
      return localJSONArray;
    }
    catch (Exception localException)
    {
      r.i();
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.b.i
 * JD-Core Version:    0.7.1
 */