package cn.jpush.android.ui;

import android.content.Context;
import android.content.res.AssetManager;
import android.content.res.Resources;
import android.graphics.drawable.BitmapDrawable;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import cn.jpush.android.c.r;
import java.io.IOException;
import java.io.InputStream;

public final class a
  extends RelativeLayout
{
  private static final String[] z;
  ImageView a;
  View.OnTouchListener b = new b(this);
  private final Context c;
  private WebView d;
  private c e = new c(this);
  
  static
  {
    String[] arrayOfString1 = new String[4];
    String str1 = "\022zU\006W\017OB";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 63;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "\r~fX\007";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "4EA\021j*F\032";
        j = 2;
        arrayOfString2 = arrayOfString1;
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        j = 3;
        arrayOfString2 = arrayOfString1;
        str1 = "2ZU\006W\007IL\032L=\004P\033X";
        i = 2;
        break;
      case 2: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 88;
        break label96;
        i3 = 42;
        break label96;
        i3 = 32;
        break label96;
        i3 = 117;
        break label96;
        m = 0;
      }
    }
  }
  
  public a(Context paramContext, cn.jpush.android.a.d paramd)
  {
    super(paramContext);
    this.c = paramContext;
    ProgressBar localProgressBar = new ProgressBar(paramContext, null, 16842872);
    localProgressBar.setMax(100);
    localProgressBar.setLayoutParams(new RelativeLayout.LayoutParams(-1, cn.jpush.android.c.a.a(paramContext, 5.0F)));
    this.d = new WebView(paramContext);
    this.d.setLayoutParams(new RelativeLayout.LayoutParams(-1, -1));
    this.d.setScrollbarFadingEnabled(true);
    this.d.setScrollBarStyle(33554432);
    WebSettings localWebSettings = this.d.getSettings();
    localWebSettings.setJavaScriptEnabled(true);
    localWebSettings.setDefaultTextEncodingName(z[1]);
    localWebSettings.setSupportZoom(true);
    localWebSettings.setCacheMode(2);
    this.d.addJavascriptInterface(new l(paramContext, paramd), z[0]);
    this.d.setWebChromeClient(new d(localProgressBar));
    this.d.setWebViewClient(new f(paramd));
    this.d.setOnTouchListener(this.b);
    addView(localProgressBar, new RelativeLayout.LayoutParams(-1, cn.jpush.android.c.a.a(paramContext, 5.0F)));
    addView(this.d, new RelativeLayout.LayoutParams(-1, -1));
  }
  
  public final void a()
  {
    removeAllViews();
    if (this.d != null)
    {
      this.d.removeAllViews();
      this.d.destroy();
      this.d = null;
    }
    if (this.a != null) {
      this.a = null;
    }
  }
  
  public final void a(View.OnClickListener paramOnClickListener)
  {
    Context localContext = this.c;
    r.b();
    this.a = new ImageView(localContext);
    for (;;)
    {
      try
      {
        localInputStream = localContext.getResources().getAssets().open(z[3]);
        BitmapDrawable localBitmapDrawable = new BitmapDrawable(localInputStream);
        this.a.setImageDrawable(localBitmapDrawable);
        this.a.setVisibility(4);
      }
      catch (IOException localIOException1)
      {
        InputStream localInputStream;
        RelativeLayout.LayoutParams localLayoutParams;
        continue;
      }
      try
      {
        localInputStream.close();
        localLayoutParams = new RelativeLayout.LayoutParams(cn.jpush.android.c.a.a(localContext, 40.0F), cn.jpush.android.c.a.a(localContext, 40.0F));
        localLayoutParams.addRule(10, -1);
        localLayoutParams.addRule(11, -1);
        addView(this.a, localLayoutParams);
        this.e.sendEmptyMessage(0);
      }
      catch (IOException localIOException2) {}
    }
    if (this.a != null) {
      this.a.setOnClickListener(paramOnClickListener);
    }
  }
  
  public final void a(String paramString)
  {
    if (this.d != null)
    {
      new StringBuilder(z[2]).append(paramString).toString();
      r.b();
      this.d.loadUrl(paramString);
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.ui.a
 * JD-Core Version:    0.7.1
 */