package cn.jpush.android.ui;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RemoteViews;

public class JPushRemoteViews
  extends RemoteViews
{
  public View apply(Context paramContext, ViewGroup paramViewGroup)
  {
    return super.apply(paramContext, paramViewGroup);
  }
  
  public void reapply(Context paramContext, View paramView)
  {
    super.reapply(paramContext, paramView);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.ui.JPushRemoteViews
 * JD-Core Version:    0.7.1
 */