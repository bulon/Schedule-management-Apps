package cn.jpush.android.ui;

import android.app.Activity;
import android.content.Context;
import cn.jpush.android.a.d;
import java.lang.ref.WeakReference;

public final class l
{
  private final WeakReference<Activity> a;
  private final d b;
  
  public l(Context paramContext, d paramd)
  {
    this.a = new WeakReference((Activity)paramContext);
    this.b = paramd;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.ui.l
 * JD-Core Version:    0.7.1
 */