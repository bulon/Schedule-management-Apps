package cn.jpush.android.ui;

import android.view.View;
import android.view.View.OnClickListener;
import cn.jpush.android.c.r;

final class i
  implements View.OnClickListener
{
  i(PushActivity paramPushActivity) {}
  
  public final void onClick(View paramView)
  {
    r.b();
    this.a.finish();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.ui.i
 * JD-Core Version:    0.7.1
 */