package cn.jpush.android;

public enum c
{
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[18];
    int i1 = 0;
    String str1 = "'dO\0356$p[\r3%lZ\034*'jQ\0277)P\0321";
    int i2 = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int i3 = localObject3.length;
    int i4 = 0;
    label36:
    Object localObject4;
    int i5;
    int i6;
    Object localObject5;
    label52:
    int i7;
    int i8;
    if (i3 <= 1)
    {
      localObject4 = localObject3;
      i5 = i4;
      i6 = i3;
      localObject5 = localObject3;
      i7 = localObject5[i4];
      switch (i5 % 5)
      {
      default: 
        i8 = 101;
      }
    }
    for (;;)
    {
      localObject5[i4] = ((char)(i8 ^ i7));
      i4 = i5 + 1;
      if (i6 == 0)
      {
        localObject5 = localObject4;
        i5 = i4;
        i4 = i6;
        break label52;
      }
      i3 = i6;
      localObject3 = localObject4;
      if (i3 > i4) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (i2)
      {
      default: 
        localObject1[i1] = str2;
        i1 = 1;
        str1 = "'dO\0356$lR\f:>jX";
        localObject1 = localObject2;
        i2 = 0;
        break;
      case 0: 
        localObject1[i1] = str2;
        i1 = 2;
        str1 = "'dO\0356$lR\f:!jL\033$+jZ\f";
        i2 = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i1] = str2;
        i1 = 3;
        str1 = "'dO\0356$lR\f:9aM\r\"/g^\006+)f[";
        i2 = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i1] = str2;
        i1 = 4;
        str1 = "'dO\0356$lR\f:)a^\n))lW\006+)cV\f";
        i2 = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i1] = str2;
        i1 = 5;
        str1 = "";
        i2 = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i1] = str2;
        i1 = 6;
        str1 = "'dO\0356$lR\f:+jK\013--aQ\r)%k";
        i2 = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i1] = str2;
        i1 = 7;
        str1 = "'dO\0356$lR\f:(j\\\013--aQ\r)%k-";
        i2 = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i1] = str2;
        i1 = 8;
        str1 = "'dO\0356$lR\f:!jL\033$+j";
        i2 = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i1] = str2;
        i1 = 9;
        str1 = "'dO\0356$lR\f:/cV\r+8|Z\006!!|X";
        i2 = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i1] = str2;
        i1 = 10;
        str1 = "'dO\0356$lR\f:!nG";
        i2 = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i1] = str2;
        i1 = 11;
        str1 = "'dO\0356$lR\f: `X\00708";
        i2 = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i1] = str2;
        i1 = 12;
        str1 = "'dO\0356$lR\f:8nX\027$ nV\033";
        i2 = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i1] = str2;
        i1 = 13;
        str1 = "";
        i2 = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i1] = str2;
        i1 = 14;
        str1 = "'dO\0356$lR\f:+jK\013--aQ\r)%k-";
        i2 = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i1] = str2;
        i1 = 15;
        str1 = "'dO\0356$lR\f:$nM\034')nK";
        i2 = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i1] = str2;
        i1 = 16;
        str1 = "'dO\0356$lR\f: `X\001+";
        i2 = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i1] = str2;
        i1 = 17;
        str1 = "'dO\0356$lR\f:(j\\\013--aQ\r)%k";
        i2 = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i1] = str2;
        z = (String[])localObject2;
        a = new c(z[1], 0);
        b = new c(z[16], 1);
        c = new c(z[15], 2);
        d = new c(z[8], 3);
        e = new c(z[2], 4);
        f = new c(z[11], 5);
        g = new c(z[6], 6);
        h = new c(z[17], 7);
        i = new c(z[10], 8);
        j = new c(z[5], 9);
        k = new c(z[12], 10);
        l = new c(z[4], 11);
        m = new c(z[13], 12);
        n = new c(z[0], 13);
        o = new c(z[3], 14);
        p = new c(z[9], 15);
        q = new c(z[14], 16);
        r = new c(z[7], 17);
        c[] arrayOfc = new c[18];
        arrayOfc[0] = a;
        arrayOfc[1] = b;
        arrayOfc[2] = c;
        arrayOfc[3] = d;
        arrayOfc[4] = e;
        arrayOfc[5] = f;
        arrayOfc[6] = g;
        arrayOfc[7] = h;
        arrayOfc[8] = i;
        arrayOfc[9] = j;
        arrayOfc[10] = k;
        arrayOfc[11] = l;
        arrayOfc[12] = m;
        arrayOfc[13] = n;
        arrayOfc[14] = o;
        arrayOfc[15] = p;
        arrayOfc[16] = q;
        arrayOfc[17] = r;
        s = arrayOfc;
        return;
        i8 = 108;
        continue;
        i8 = 47;
        continue;
        i8 = 31;
        continue;
        i8 = 72;
      }
    }
  }
  
  private c() {}
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c
 * JD-Core Version:    0.7.1
 */