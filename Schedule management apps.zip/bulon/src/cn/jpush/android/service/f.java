package cn.jpush.android.service;

import android.content.Context;
import android.os.Handler;
import android.os.Message;
import android.widget.Toast;

final class f
  extends Handler
{
  private static final String z;
  private Context b;
  
  static
  {
    Object localObject1 = "><S\035\r\tXs\035\021M\026\b_\032\027b\027".toCharArray();
    int i = localObject1.length;
    int j = 0;
    Object localObject2;
    int k;
    int m;
    Object localObject3;
    label27:
    int n;
    int i1;
    if (i <= 1)
    {
      localObject2 = localObject1;
      k = j;
      m = i;
      localObject3 = localObject1;
      n = localObject3[j];
      switch (k % 5)
      {
      default: 
        i1 = 127;
      }
    }
    for (;;)
    {
      localObject3[j] = ((char)(i1 ^ n));
      j = k + 1;
      if (m == 0)
      {
        localObject3 = localObject2;
        k = j;
        j = m;
        break label27;
      }
      i = m;
      localObject1 = localObject2;
      if (i > j) {
        break;
      }
      z = new String((char[])localObject1).intern();
      return;
      i1 = 109;
      continue;
      i1 = 120;
      continue;
      i1 = 16;
      continue;
      i1 = 124;
    }
  }
  
  public f(DownloadService paramDownloadService, Context paramContext)
  {
    super(paramContext.getMainLooper());
    this.b = paramContext;
  }
  
  public final void handleMessage(Message paramMessage)
  {
    super.handleMessage(paramMessage);
    Toast.makeText(this.b, z, 1).show();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.f
 * JD-Core Version:    0.7.1
 */