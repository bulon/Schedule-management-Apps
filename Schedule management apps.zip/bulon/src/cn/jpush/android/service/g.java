package cn.jpush.android.service;

import cn.jpush.android.a.d;

final class g
  implements Runnable
{
  g(PushService paramPushService, d paramd) {}
  
  public final void run()
  {
    ServiceInterface.a(this.b.getApplicationContext(), this.a);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.g
 * JD-Core Version:    0.7.1
 */