package cn.jpush.android.service;

import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import cn.jpush.android.c.r;

final class b
  extends Handler
{
  private c b = null;
  
  public b(a parama, Looper paramLooper, c paramc)
  {
    super(paramLooper);
    this.b = paramc;
  }
  
  public final void handleMessage(Message paramMessage)
  {
    super.handleMessage(paramMessage);
    if (this.a.a)
    {
      r.a();
      return;
    }
    if (this.b != null) {
      this.b.a(a.a(this.a), a.b(this.a));
    }
    a.c(this.a).sendEmptyMessageDelayed(0, 2000L);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.b
 * JD-Core Version:    0.7.1
 */