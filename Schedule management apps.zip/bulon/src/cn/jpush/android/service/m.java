package cn.jpush.android.service;

import android.content.Context;
import java.lang.reflect.Method;

public final class m
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = ">]Y,N6W\0231Rq`D-U:^m,N/VO*H:@";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 33;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "8VI";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 95;
        break label96;
        i3 = 51;
        break label96;
        i3 = 61;
        break label96;
        i3 = 94;
        break label96;
        m = 0;
      }
    }
  }
  
  public static String a(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      Class localClass = paramContext.getClassLoader().loadClass(z[0]);
      Class[] arrayOfClass = { String.class, String.class };
      Method localMethod = localClass.getMethod(z[1], arrayOfClass);
      Object[] arrayOfObject = new Object[2];
      arrayOfObject[0] = new String(paramString1);
      arrayOfObject[1] = new String(paramString2);
      String str = (String)localMethod.invoke(localClass, arrayOfObject);
      return str;
    }
    catch (IllegalArgumentException localIllegalArgumentException)
    {
      throw localIllegalArgumentException;
    }
    catch (Exception localException) {}
    return paramString2;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.m
 * JD-Core Version:    0.7.1
 */