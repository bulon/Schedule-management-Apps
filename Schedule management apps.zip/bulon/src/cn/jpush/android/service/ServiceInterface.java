package cn.jpush.android.service;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import cn.jpush.android.a.d;
import cn.jpush.android.api.TagAliasCallback;
import cn.jpush.android.api.b;
import cn.jpush.android.api.k;
import cn.jpush.android.c.a;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.c.w;
import cn.jpush.android.c.z;
import java.util.WeakHashMap;
import java.util.concurrent.ConcurrentHashMap;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class ServiceInterface
{
  public static long a;
  public static String b;
  public static ConcurrentHashMap<Integer, b> d = new ConcurrentHashMap();
  private static String e;
  private static int f;
  private static String g;
  private static int h;
  private static final String[] z;
  WeakHashMap<Integer, TagAliasCallback> c = new WeakHashMap();
  
  static
  {
    Object localObject1 = new String[48];
    int i = 0;
    String str1 = "\020-\004S\027";
    int j = -1;
    Object localObject2 = localObject1;
    int i10;
    label133:
    String str2;
    for (;;)
    {
      Object localObject3 = str1.toCharArray();
      int k = localObject3.length;
      int m = 0;
      if (k <= 1) {}
      while (k > m)
      {
        Object localObject7 = localObject3;
        int i7 = m;
        int i8 = k;
        Object localObject8 = localObject3;
        for (;;)
        {
          int i9 = localObject8[m];
          switch (i7 % 5)
          {
          default: 
            i10 = 114;
            localObject8[m] = ((char)(i10 ^ i9));
            m = i7 + 1;
            if (i8 != 0) {
              break label133;
            }
            localObject8 = localObject7;
            i7 = m;
            m = i8;
          }
        }
        k = i8;
        localObject3 = localObject7;
      }
      str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "\002>\035E";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "\004)\033T\023\00487R\006\025";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "\037?:E\001\002-\032T \002/";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "\027/\034I\035\030v\032E\002\031>\034o\002\023>\tT\033\031\"H\rR\025#\006T\027\0308R";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "8\031$lR\025#\006T\027\0168";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "\005)\031\033\022";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "\002-\017S";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "\027 \001A\001";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "\0048\013\026\023 \tY";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "\0048\013";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "%)\032V\033\025)!N\006\023>\016A\021\023";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "\027<\030";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "\0058\007P-\002$\032E\023\022";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "\005)\032V\033\025)7S\006\031<\rD";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "\005%\004E\034\025)8U\001\036\030\001M\027";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "\030#\034I\024\027/\034I\035\030\023\006U\037";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "\0069\033H\006\037!\r";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "\025 \007S\027\0069\033H";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "Gb^\016C";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "\004)\030\026\0278\t";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "\004)\030\033\022";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "%)\006DR\033)\033S\025\023l\016R\035\033l,bHV";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "\004)\030\002\004)\016I\n";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "\0025\030E";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = "Zl\013O\026\023vH";
        j = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i] = str2;
        i = 32;
        str1 = "\033?\017\001\002-\034U\001";
        j = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i] = str2;
        i = 33;
        str1 = "\033)\033S\023\021)\001D";
        j = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i] = str2;
        i = 34;
        str1 = "\004)\033U\036\002";
        j = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i] = str2;
        i = 35;
        str1 = "\022-\034A";
        j = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i] = str2;
        i = 36;
        str1 = "V>\rP\035\0048HC\035\0308\rN\006Ll";
        j = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i] = str2;
        i = 37;
        str1 = "\0378\001M\027";
        j = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i] = str2;
        i = 38;
        str1 = "\023\"\fT?\037\"\033";
        j = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i] = str2;
        i = 39;
        str1 = "\0058\tR\006>#\035R";
        j = 38;
        localObject1 = localObject2;
        break;
      case 38: 
        localObject1[i] = str2;
        i = 40;
        str1 = "\023\"\fh\035\003>";
        j = 39;
        localObject1 = localObject2;
        break;
      case 39: 
        localObject1[i] = str2;
        i = 41;
        str1 = "\0058\tR\006;%\006S";
        j = 40;
        localObject1 = localObject2;
        break;
      case 40: 
        localObject1[i] = str2;
        i = 42;
        str1 = "";
        j = 41;
        localObject1 = localObject2;
        break;
      case 41: 
        localObject1[i] = str2;
        i = 43;
        str1 = "";
        j = 42;
        localObject1 = localObject2;
        break;
      case 42: 
        localObject1[i] = str2;
        i = 44;
        str1 = "\024#\fY";
        j = 43;
        localObject1 = localObject2;
        break;
      case 43: 
        localObject1[i] = str2;
        i = 45;
        str1 = "7\0348L\033\0058HL\027\030+\034HHV";
        j = 44;
        localObject1 = localObject2;
        break;
      case 44: 
        localObject1[i] = str2;
        i = 46;
        str1 = "\027<\030\036\037?\034";
        j = 45;
        localObject1 = localObject2;
        break;
      case 45: 
        localObject1[i] = str2;
        i = 47;
        str1 = "7<\030L\033\0058H\032R";
        j = 46;
        localObject1 = localObject2;
      }
    }
    localObject1[i] = str2;
    z = (String[])localObject2;
    a = 0L;
    int n = -1;
    String str3 = "G}_\016CEyF\021DFb]\022";
    label1351:
    label1489:
    String str4;
    for (;;)
    {
      Object localObject4 = str3.toCharArray();
      int i1 = localObject4.length;
      int i2 = 0;
      if (i1 <= 1) {}
      while (i1 > i2)
      {
        Object localObject5 = localObject4;
        int i3 = i2;
        int i4 = i1;
        Object localObject6 = localObject4;
        int i5 = localObject6[i2];
        int i6;
        switch (i3 % 5)
        {
        default: 
          i6 = 114;
        }
        for (;;)
        {
          localObject6[i2] = ((char)(i6 ^ i5));
          i2 = i3 + 1;
          if (i4 != 0) {
            break label1489;
          }
          localObject6 = localObject5;
          i3 = i2;
          i2 = i4;
          break label1351;
          i10 = 118;
          break;
          i10 = 76;
          break;
          i10 = 104;
          break;
          i10 = 32;
          break;
          i6 = 118;
          continue;
          i6 = 76;
          continue;
          i6 = 104;
          continue;
          i6 = 32;
        }
        i1 = i4;
        localObject4 = localObject5;
      }
      str4 = new String((char[])localObject4).intern();
      switch (n)
      {
      default: 
        e = str4;
        f = 9001;
        str3 = "G}_\016CEyF\021DFb]\022";
        n = 0;
        break;
      case 0: 
        g = str4;
        h = 9002;
        n = 1;
        str3 = "";
      }
    }
    b = str4;
  }
  
  static b a(int paramInt)
  {
    return (b)d.get(Integer.valueOf(paramInt));
  }
  
  public static void a(Context paramContext)
  {
    if (k(paramContext)) {}
    while (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    Intent localIntent = new Intent(paramContext, PushService.class);
    localIntent.setAction(z[43]);
    localIntent.putExtra(z[14], paramContext.getPackageName());
    paramContext.startService(localIntent);
  }
  
  public static void a(Context paramContext, int paramInt)
  {
    if (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    Intent localIntent = new Intent(paramContext, PushService.class);
    Bundle localBundle = new Bundle();
    localBundle.putString(z[11], z[11]);
    localBundle.putInt(z[10], paramInt);
    localIntent.putExtras(localBundle);
    paramContext.startService(localIntent);
  }
  
  public static void a(Context paramContext, d paramd)
  {
    r.a();
    Intent localIntent = new Intent(paramContext, DownloadService.class);
    localIntent.putExtra(z[44], paramd);
    paramContext.startService(localIntent);
  }
  
  public static void a(Context paramContext, String paramString)
  {
    if (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    z.b(paramContext, z[18], paramString);
  }
  
  public static void a(Context paramContext, String paramString1, String paramString2, b paramb)
  {
    if (k(paramContext)) {}
    while (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    int i = 0;
    if (paramb != null)
    {
      TagAliasCallback localTagAliasCallback = paramb.c;
      i = 0;
      if (localTagAliasCallback != null)
      {
        i = a.c(paramContext);
        Integer localInteger = Integer.valueOf(i);
        d.put(localInteger, paramb);
      }
    }
    Intent localIntent = new Intent(paramContext, PushService.class);
    localIntent.setAction(z[8]);
    localIntent.putExtra(z[9], paramString1);
    localIntent.putExtra(z[7], paramString2);
    localIntent.putExtra(z[6], i);
    paramContext.startService(localIntent);
  }
  
  public static void a(Context paramContext, JSONObject paramJSONObject)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException(z[5]);
    }
    if ((paramJSONObject != null) && (paramJSONObject.length() > 0))
    {
      w.a(paramContext, paramJSONObject);
      new StringBuilder(z[4]).append(paramJSONObject.toString()).toString();
      r.b();
    }
  }
  
  public static void a(Context paramContext, boolean paramBoolean, String paramString)
  {
    if (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    Intent localIntent = new Intent(paramContext, PushService.class);
    localIntent.setAction(z[22]);
    localIntent.putExtra(z[21], paramBoolean);
    localIntent.putExtra(z[20], paramString);
    paramContext.startService(localIntent);
  }
  
  public static void a(String paramString)
  {
    e = paramString;
  }
  
  public static void a(String paramString, int paramInt, Context paramContext)
  {
    a(paramString, paramInt, null, paramContext);
  }
  
  public static void a(String paramString1, int paramInt, String paramString2, Context paramContext)
  {
    if (paramContext == null)
    {
      r.b();
      return;
    }
    StringBuffer localStringBuffer = new StringBuffer();
    localStringBuffer.append(z[30] + paramString1 + z[31] + paramInt + "-" + l.b(paramInt));
    if (!ac.a(paramString2)) {
      localStringBuffer.append(z[36] + paramString2);
    }
    localStringBuffer.toString();
    r.b();
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put(z[33], paramString1);
      localJSONObject.put(z[34], paramInt);
      if (!ac.a(paramString2)) {
        localJSONObject.put(z[35], paramString2);
      }
      localJSONObject.put(z[37], System.currentTimeMillis() / 1000L);
      localJSONObject.put(z[29], z[32]);
      w.a(paramContext, localJSONObject);
      return;
    }
    catch (JSONException localJSONException) {}
  }
  
  public static boolean a()
  {
    return PushProtocol.GetSdkVersion() >= 160;
  }
  
  public static boolean a(Context paramContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put(z[39], paramInt1);
      localJSONObject.put(z[41], paramInt2);
      localJSONObject.put(z[40], paramInt3);
      localJSONObject.put(z[38], paramInt4);
      a(paramContext, localJSONObject.toString());
      return true;
    }
    catch (JSONException localJSONException) {}
    return false;
  }
  
  public static String b()
  {
    return z[23];
  }
  
  static void b(int paramInt)
  {
    d.remove(Integer.valueOf(paramInt));
  }
  
  public static void b(Context paramContext)
  {
    if (k(paramContext)) {
      return;
    }
    z.b(paramContext, z[17], 1);
    PushService.b(false);
    z.b(paramContext, z[3], z[0]);
    Intent localIntent = new Intent(paramContext, PushService.class);
    localIntent.setAction(z[16]);
    localIntent.putExtra(z[14], paramContext.getPackageName());
    paramContext.startService(localIntent);
  }
  
  public static void b(Context paramContext, int paramInt)
  {
    z.b(paramContext, z[19], paramInt);
  }
  
  public static void b(String paramString)
  {
    g = paramString;
  }
  
  public static void c(int paramInt)
  {
    f = paramInt;
  }
  
  public static void c(Context paramContext)
  {
    if (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    Intent localIntent = new Intent(paramContext, PushService.class);
    localIntent.setAction(z[15]);
    localIntent.putExtra(z[14], paramContext.getPackageName());
    paramContext.startService(localIntent);
  }
  
  public static void d(int paramInt)
  {
    h = paramInt;
  }
  
  public static void d(Context paramContext)
  {
    PushService.b(true);
    z.b(paramContext, z[3], z[1]);
    z.b(paramContext, z[17], 0);
    Intent localIntent = new Intent(paramContext, PushService.class);
    localIntent.setAction(z[42]);
    localIntent.putExtra(z[14], paramContext.getPackageName());
    paramContext.startService(localIntent);
  }
  
  public static void e(Context paramContext)
  {
    if (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    Intent localIntent = new Intent(paramContext, PushService.class);
    Bundle localBundle = new Bundle();
    localBundle.putString(z[11], z[11]);
    localIntent.putExtras(localBundle);
    paramContext.startService(localIntent);
  }
  
  public static void f(Context paramContext)
  {
    if (z.a(paramContext, z[3], z[1]).equals(z[0])) {
      return;
    }
    r.a();
    if (PushService.a())
    {
      Intent localIntent = new Intent(paramContext, PushService.class);
      localIntent.setAction(z[2]);
      paramContext.startService(localIntent);
      return;
    }
    r.c();
  }
  
  public static void g(Context paramContext)
  {
    if (paramContext == null) {
      r.b();
    }
    for (;;)
    {
      return;
      JSONArray localJSONArray1 = a.n(paramContext);
      if ((localJSONArray1 == null) || (localJSONArray1.length() == 0)) {
        continue;
      }
      JSONArray localJSONArray2 = new JSONArray();
      int i = localJSONArray1.length();
      JSONArray localJSONArray3 = localJSONArray2;
      int j = 0;
      label43:
      if (j < i) {}
      try
      {
        localJSONArray3.put(localJSONArray1.getJSONObject(j));
        label61:
        if ((localJSONArray3.toString().length() > 15360) || (j == i - 1))
        {
          JSONObject localJSONObject2 = a.a(z[46], localJSONArray1);
          if ((localJSONObject2 != null) && (localJSONObject2.length() > 0)) {
            w.a(paramContext, localJSONObject2);
          }
          localJSONArray3 = new JSONArray();
        }
        j++;
        break label43;
        JSONObject localJSONObject1 = a.a(z[46], localJSONArray1);
        if ((localJSONObject1 == null) || (localJSONObject1.length() <= 0)) {
          continue;
        }
        w.a(paramContext, localJSONObject1);
        new StringBuilder(z[45]).append(localJSONObject1.toString().getBytes().length).toString();
        r.c();
        new StringBuilder(z[47]).append(localJSONObject1).toString();
        r.c();
        return;
      }
      catch (JSONException localJSONException)
      {
        break label61;
      }
    }
  }
  
  /* Error */
  public static void h(Context paramContext)
  {
    // Byte code:
    //   0: aconst_null
    //   1: astore_1
    //   2: aload_0
    //   3: invokestatic 396	cn/jpush/android/a/n:a	(Landroid/content/Context;)Landroid/database/Cursor;
    //   6: astore 6
    //   8: aload 6
    //   10: astore_1
    //   11: aload_1
    //   12: ifnull +192 -> 204
    //   15: aload_1
    //   16: invokeinterface 401 1 0
    //   21: ifle +183 -> 204
    //   24: new 278	java/lang/StringBuilder
    //   27: dup
    //   28: getstatic 135	cn/jpush/android/service/ServiceInterface:z	[Ljava/lang/String;
    //   31: bipush 26
    //   33: aaload
    //   34: invokespecial 279	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   37: aload_1
    //   38: invokeinterface 401 1 0
    //   43: invokevirtual 305	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   46: invokevirtual 287	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   49: pop
    //   50: invokestatic 362	cn/jpush/android/c/r:c	()V
    //   53: aload_1
    //   54: invokeinterface 404 1 0
    //   59: pop
    //   60: aload_1
    //   61: invokeinterface 407 1 0
    //   66: ifne +138 -> 204
    //   69: aload_1
    //   70: aload_1
    //   71: getstatic 135	cn/jpush/android/service/ServiceInterface:z	[Ljava/lang/String;
    //   74: bipush 25
    //   76: aaload
    //   77: invokeinterface 411 2 0
    //   82: invokeinterface 415 2 0
    //   87: istore 10
    //   89: aload_1
    //   90: aload_1
    //   91: getstatic 135	cn/jpush/android/service/ServiceInterface:z	[Ljava/lang/String;
    //   94: bipush 24
    //   96: aaload
    //   97: invokeinterface 411 2 0
    //   102: invokeinterface 418 2 0
    //   107: astore 11
    //   109: new 420	java/lang/Thread
    //   112: dup
    //   113: new 422	cn/jpush/android/service/k
    //   116: dup
    //   117: aload_1
    //   118: aload_1
    //   119: getstatic 135	cn/jpush/android/service/ServiceInterface:z	[Ljava/lang/String;
    //   122: bipush 28
    //   124: aaload
    //   125: invokeinterface 411 2 0
    //   130: invokeinterface 418 2 0
    //   135: aload 11
    //   137: invokevirtual 386	java/lang/String:getBytes	()[B
    //   140: invokespecial 425	cn/jpush/android/service/k:<init>	(Ljava/lang/String;[B)V
    //   143: invokespecial 428	java/lang/Thread:<init>	(Ljava/lang/Runnable;)V
    //   146: invokevirtual 431	java/lang/Thread:start	()V
    //   149: new 278	java/lang/StringBuilder
    //   152: dup
    //   153: getstatic 135	cn/jpush/android/service/ServiceInterface:z	[Ljava/lang/String;
    //   156: bipush 27
    //   158: aaload
    //   159: invokespecial 279	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   162: aload 11
    //   164: invokevirtual 286	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: invokevirtual 287	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   170: pop
    //   171: invokestatic 362	cn/jpush/android/c/r:c	()V
    //   174: aload_0
    //   175: iload 10
    //   177: invokestatic 434	cn/jpush/android/a/n:a	(Landroid/content/Context;I)Z
    //   180: pop
    //   181: aload_1
    //   182: invokeinterface 437 1 0
    //   187: pop
    //   188: goto -128 -> 60
    //   191: astore 5
    //   193: aload_1
    //   194: ifnull +9 -> 203
    //   197: aload_1
    //   198: invokeinterface 440 1 0
    //   203: return
    //   204: aload_1
    //   205: ifnull -2 -> 203
    //   208: aload_1
    //   209: invokeinterface 440 1 0
    //   214: return
    //   215: astore_2
    //   216: aconst_null
    //   217: astore_3
    //   218: aload_2
    //   219: astore 4
    //   221: aload_3
    //   222: ifnull +9 -> 231
    //   225: aload_3
    //   226: invokeinterface 440 1 0
    //   231: aload 4
    //   233: athrow
    //   234: astore 7
    //   236: aload_1
    //   237: astore_3
    //   238: aload 7
    //   240: astore 4
    //   242: goto -21 -> 221
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	245	0	paramContext	Context
    //   1	236	1	localObject1	Object
    //   215	4	2	localObject2	Object
    //   217	21	3	localObject3	Object
    //   219	22	4	localObject4	Object
    //   191	1	5	localException	Exception
    //   6	3	6	localCursor	android.database.Cursor
    //   234	5	7	localObject5	Object
    //   87	89	10	i	int
    //   107	56	11	str	String
    // Exception table:
    //   from	to	target	type
    //   2	8	191	java/lang/Exception
    //   15	60	191	java/lang/Exception
    //   60	188	191	java/lang/Exception
    //   2	8	215	finally
    //   15	60	234	finally
    //   60	188	234	finally
  }
  
  public static void i(Context paramContext)
  {
    k.a(paramContext);
  }
  
  public static boolean j(Context paramContext)
  {
    return z.a(paramContext, z[17], 0) == 1;
  }
  
  public static boolean k(Context paramContext)
  {
    boolean bool = j(paramContext);
    if (bool) {
      r.d(z[13], z[12]);
    }
    return bool;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.ServiceInterface
 * JD-Core Version:    0.7.1
 */