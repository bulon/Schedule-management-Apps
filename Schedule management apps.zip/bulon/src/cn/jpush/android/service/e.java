package cn.jpush.android.service;

import android.os.Handler;
import android.os.Message;
import cn.jpush.android.api.k;

final class e
  extends Handler
{
  e(DownloadService paramDownloadService) {}
  
  public final void handleMessage(Message paramMessage)
  {
    super.handleMessage(paramMessage);
    k.a(this.a, paramMessage.what);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.e
 * JD-Core Version:    0.7.1
 */