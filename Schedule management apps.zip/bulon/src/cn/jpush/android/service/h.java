package cn.jpush.android.service;

import android.content.Context;
import cn.jpush.android.b.d;
import cn.jpush.android.c.a;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.c.w;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

final class h
  extends d
{
  private static final String[] A;
  
  static
  {
    Object localObject1 = new String[15];
    int i = 0;
    String str1 = "\002|`5";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 18;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "\035`j\016{\037if";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "\035`j\016e\030i`";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "&fo82\035jg6f\0315)";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "\030{`<w";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "\022je=";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "\022je=M\005`~4`\002";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "\005vy4";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "\020ce";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "=`j0f\030`gk2";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "\035`j\016q\024ce";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "\006fo8";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "\006fo8M\005`~4`\002";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "\035`j\016u\001|";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "\026z";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        A = (String[])localObject2;
        return;
        i3 = 113;
        continue;
        i3 = 15;
        continue;
        i3 = 9;
        continue;
        i3 = 81;
      }
    }
  }
  
  h(PushService paramPushService, Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    super(paramContext, paramString, paramBoolean1, paramBoolean2);
  }
  
  private static boolean a(JSONArray paramJSONArray1, JSONArray paramJSONArray2, String paramString)
  {
    if (ac.a(paramString))
    {
      if (!ac.a(PushService.l())) {
        return false;
      }
    }
    else if (!paramString.equals(PushService.l())) {
      return false;
    }
    if (ac.a(PushService.m()))
    {
      if ((paramJSONArray2 != null) && (paramJSONArray2.length() != 0)) {
        return false;
      }
    }
    else
    {
      if (paramJSONArray2 == null) {
        return false;
      }
      if (paramJSONArray2.length() == 0) {
        return false;
      }
      if (!PushService.m().equals(paramJSONArray2.toString())) {
        return false;
      }
      r.c();
    }
    if (ac.a(PushService.n()))
    {
      if ((paramJSONArray1 != null) && (paramJSONArray1.length() != 0)) {
        return false;
      }
    }
    else
    {
      if (paramJSONArray1 == null) {
        return false;
      }
      if (paramJSONArray1.length() == 0) {
        return false;
      }
      try
      {
        String str = ((JSONObject)paramJSONArray1.get(0)).optString(A[0]);
        if (!ac.a(str))
        {
          boolean bool = str.equals(PushService.n());
          if (!bool) {
            return false;
          }
        }
      }
      catch (Exception localException)
      {
        return false;
      }
    }
    return true;
  }
  
  public final void d()
  {
    label386:
    JSONArray localJSONArray1;
    JSONArray localJSONArray2;
    JSONArray localJSONArray3;
    String str1;
    for (;;)
    {
      try
      {
        boolean bool1 = PushService.o();
        if (!bool1) {
          return;
        }
        if (!this.a.equals(A[6])) {
          continue;
        }
        JSONArray localJSONArray7 = b();
        JSONObject localJSONObject5 = a.a(A[10], localJSONArray7);
        if ((localJSONObject5 != null) && (localJSONObject5.length() > 0))
        {
          w.a(this.e.getApplicationContext(), localJSONObject5);
          new StringBuilder(A[9]).append(localJSONObject5).toString();
          r.c();
        }
      }
      catch (Exception localException1)
      {
        JSONArray localJSONArray6;
        JSONObject localJSONObject4;
        r.i();
        return;
        if (!this.a.equals(A[14])) {
          break label386;
        }
        String str2 = a();
        if (str2 == null) {
          continue;
        }
        boolean bool3 = "".equals(str2);
        if (bool3) {
          continue;
        }
        try
        {
          JSONObject localJSONObject2 = new JSONObject(str2);
          JSONArray localJSONArray5 = new JSONArray();
          localJSONArray5.put(localJSONObject2);
          JSONObject localJSONObject3 = a.a(A[13], localJSONArray5);
          if ((localJSONObject3 == null) || (localJSONObject3.length() <= 0)) {
            continue;
          }
          w.a(this.e.getApplicationContext(), localJSONObject3);
          new StringBuilder(A[9]).append(localJSONObject3).toString();
          r.c();
        }
        catch (JSONException localJSONException2)
        {
          localJSONException2.getMessage();
          r.e();
        }
        continue;
      }
      finally
      {
        g();
      }
      g();
      return;
      if (this.a.equals(A[12]))
      {
        localJSONArray6 = c();
        localJSONObject4 = a.a(A[2], localJSONArray6);
        if ((localJSONObject4 != null) && (localJSONObject4.length() > 0))
        {
          w.a(this.e.getApplicationContext(), localJSONObject4);
          new StringBuilder(A[3]).append(localJSONObject4.toString().getBytes().length).toString();
          r.c();
          new StringBuilder(A[9]).append(localJSONObject4).toString();
          r.c();
        }
      }
      else if (this.a.equals(A[8]))
      {
        localJSONArray1 = c();
        localJSONArray2 = b();
        localJSONArray3 = new JSONArray();
        str1 = a();
        if (!a(localJSONArray1, localJSONArray2, str1)) {
          break;
        }
        r.c();
      }
    }
    if (str1 != null)
    {
      boolean bool2 = "".equals(str1);
      if (bool2) {}
    }
    for (;;)
    {
      for (;;)
      {
        try
        {
          localJSONArray3.put(new JSONObject(str1));
          localJSONArray4 = localJSONArray3;
        }
        catch (Exception localException2)
        {
          JSONObject localJSONObject1;
          localJSONArray4 = null;
          continue;
        }
        localJSONObject1 = new JSONObject();
        try
        {
          localJSONObject1.put(A[7], A[1]);
          localJSONObject1.put(A[4], System.currentTimeMillis() / 1000L);
          if ((localJSONArray1 != null) && (localJSONArray1.length() > 0))
          {
            localJSONObject1.put(A[11], localJSONArray1);
            PushService.f(((JSONObject)localJSONArray1.get(0)).optString(A[0]));
          }
          if ((localJSONArray2 != null) && (localJSONArray2.length() > 0))
          {
            localJSONObject1.put(A[5], localJSONArray2);
            PushService.g(localJSONArray2.toString());
          }
          if ((localJSONArray4 != null) && (localJSONArray4.length() > 0))
          {
            localJSONObject1.put(A[14], localJSONArray4);
            PushService.h(str1);
          }
          w.a(this.e.getApplicationContext(), localJSONObject1);
        }
        catch (JSONException localJSONException1) {}
      }
      break;
      JSONArray localJSONArray4 = localJSONArray3;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.h
 * JD-Core Version:    0.7.1
 */