package cn.jpush.android.service;

public abstract interface c
{
  public abstract void a(int paramInt);
  
  public abstract void a(long paramLong1, long paramLong2);
  
  public abstract void a(String paramString, boolean paramBoolean);
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.c
 * JD-Core Version:    0.7.1
 */