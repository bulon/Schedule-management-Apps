package cn.jpush.android.service;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.os.Message;
import android.os.Process;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import cn.jpush.android.a.e;
import cn.jpush.android.a.n;
import cn.jpush.android.api.TagAliasCallback;
import cn.jpush.android.api.b;
import cn.jpush.android.c;
import cn.jpush.android.c.ab;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.ad;
import cn.jpush.android.c.q;
import cn.jpush.android.c.r;
import cn.jpush.android.c.u;
import cn.jpush.android.c.z;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.LineNumberReader;
import java.io.StringReader;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentLinkedQueue;
import org.json.JSONException;
import org.json.JSONObject;

public class PushService
  extends Service
{
  private static boolean A;
  private static boolean B;
  private static String C;
  private static String D;
  private static int E;
  private static String F;
  private static String G;
  private static int H;
  private static int I;
  private static String J;
  private static boolean P;
  private static boolean Q;
  private static int R;
  private static boolean T;
  private static List<String> U;
  public static long a;
  private static Queue<e> aa = new LinkedList();
  private static String ab = null;
  private static String ac = null;
  private static String ad = null;
  public static boolean b;
  private static final String[] bb;
  public static boolean c;
  public static int d;
  public static long e;
  public static long f;
  public static long g;
  public static int h;
  public static long i;
  public static long j;
  public static String k;
  public static int l;
  public static boolean m;
  public static boolean n;
  protected static long o;
  protected static String p;
  protected static String q;
  public static boolean v;
  public static String w;
  public static boolean x;
  public static boolean y;
  public static int z;
  private j K;
  private boolean L;
  private boolean M;
  private boolean N = false;
  private boolean O = true;
  private cn.jpush.android.b.d S;
  private int V;
  private int W;
  private long X;
  private long Y;
  private int Z;
  private Handler ae = new i(this);
  protected int r = 0;
  protected byte[] s = new byte[2048];
  Queue<String> t = new LinkedList();
  Queue<String> u = new ConcurrentLinkedQueue();
  
  static
  {
    Object localObject1 = new String['Ç'];
    int i1 = 0;
    String str1 = "\bQ/#r";
    int i2 = -1;
    Object localObject2 = localObject1;
    int i15;
    label136:
    String str2;
    for (;;)
    {
      Object localObject3 = str1.toCharArray();
      int i3 = localObject3.length;
      int i4 = 0;
      if (i3 <= 1) {}
      while (i3 > i4)
      {
        Object localObject7 = localObject3;
        int i12 = i4;
        int i13 = i3;
        Object localObject8 = localObject3;
        for (;;)
        {
          int i14 = localObject8[i4];
          switch (i12 % 5)
          {
          default: 
            i15 = 1;
            localObject8[i4] = ((char)(i15 ^ i14));
            i4 = i12 + 1;
            if (i13 != 0) {
              break label136;
            }
            localObject8 = localObject7;
            i12 = i4;
            i4 = i13;
          }
        }
        i3 = i13;
        localObject3 = localObject7;
      }
      str2 = new String((char[])localObject3).intern();
      switch (i2)
      {
      default: 
        localObject1[i1] = str2;
        i1 = 1;
        str1 = "\035\\!1";
        localObject1 = localObject2;
        i2 = 0;
        break;
      case 0: 
        localObject1[i1] = str2;
        i1 = 2;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lT'o\003\005H:i\024\003U r\b";
        i2 = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i1] = str2;
        i1 = 3;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lS,n\022\rS,m\023\021I";
        i2 = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i1] = str2;
        i1 = 4;
        str1 = "9H5*R\fO0+b\f";
        i2 = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i1] = str2;
        i1 = 5;
        str1 = "^[#$7\b\n\"u7\n\n~pcX[v'e\b\trtc[^p!5Y\\";
        i2 = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i1] = str2;
        i1 = 6;
        str1 = "\b^2+n\007\007),S\f^0\001n\004P',eS\035";
        i2 = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i1] = str2;
        i1 = 7;
        str1 = "\004N!\026x\031Xf!";
        i2 = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i1] = str2;
        i1 = 8;
        str1 = "<S-,n\036Sf!l\r\035kb";
        i2 = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i1] = str2;
        i1 = 9;
        str1 = "=U#bq\b^-#f\f\035*'o\016U2bh\032\035|b";
        i2 = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i1] = str2;
        i1 = 10;
        str1 = "\004X51`\016X";
        i2 = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i1] = str2;
        i1 = 11;
        str1 = "";
        i2 = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i1] = str2;
        i1 = 12;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lR=r\026\022T:u";
        i2 = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i1] = str2;
        i1 = 13;
        str1 = "<S#:q\f^2'eS\0353,j\007R1,!\004N!bu\020M#b,";
        i2 = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i1] = str2;
        i1 = 14;
        str1 = "/\\/.d\r\0352-!\033X6-s\035\0354'b\fT0'eI\020f";
        i2 = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i1] = str2;
        i1 = 15;
        str1 = "";
        i2 = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i1] = str2;
        i1 = 16;
        str1 = ";X\"7q\005T%#u\f\035+1fI\020f";
        i2 = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i1] = str2;
        i1 = 17;
        str1 = "\032X(&d\033t\"";
        i2 = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i1] = str2;
        i1 = 18;
        str1 = "E\035+1f Yf!";
        i2 = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i1] = str2;
        i1 = 19;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lO&i\017\004H*|\022\013N'b\024\007B,t\020\007E6m\024\rY0";
        i2 = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i1] = str2;
        i1 = 20;
        str1 = "";
        i2 = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i1] = str2;
        i1 = 21;
        str1 = "\023T6\004m\bZf+rI\007f";
        i2 = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i1] = str2;
        i1 = 22;
        str1 = ":H%!d\fYf6nIO#2n\033If0d\nX/4d\r\035kb";
        i2 = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i1] = str2;
        i1 = 23;
        str1 = "E\035+1f*R(6d\007I|";
        i2 = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i1] = str2;
        i1 = 24;
        str1 = "E\0355'o\rX4\013eS";
        i2 = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i1] = str2;
        i1 = 25;
        str1 = "$X51`\016Xf\004h\fQ\"1!D\035'2q Y|";
        i2 = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i1] = str2;
        i1 = 26;
        str1 = "\bM6\013e";
        i2 = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i1] = str2;
        i1 = 27;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lS,z\017\021U;|\022\013N'";
        i2 = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i1] = str2;
        i1 = 28;
        str1 = "L\rt\032";
        i2 = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i1] = str2;
        i1 = 29;
        str1 = "\033X52B\006Y#$\r";
        i2 = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i1] = str2;
        i1 = 30;
        str1 = "\bM6bq\b^-#f\f\035(#l\f\035*'o\016I.b<I\035";
        i2 = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i1] = str2;
        i1 = 31;
        str1 = "\033X!+r\035O'6h\006Sf\013ES\035";
        i2 = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i1] = str2;
        i1 = 32;
        str1 = "\031\\%)`\016Xf,`\004X|b";
        i2 = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i1] = str2;
        i1 = 33;
        str1 = "";
        i2 = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i1] = str2;
        i1 = 34;
        str1 = "\004i.0d\bYf+rI\\*+w\f\035/&!T\035";
        i2 = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i1] = str2;
        i1 = 35;
        str1 = "\032S%";
        i2 = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i1] = str2;
        i1 = 36;
        str1 = "\032N)-";
        i2 = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i1] = str2;
        i1 = 37;
        str1 = ":X2bl:I'0u&S\b'u\036R4)B\006S('b\035X\"bu\006\035";
        i2 = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i1] = str2;
        i1 = 38;
        str1 = ":X2bl:I'0u&S\0231d\033m4'r\fS2bu\006\035";
        i2 = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i1] = str2;
        i1 = 39;
        str1 = "\034N6";
        i2 = 38;
        localObject1 = localObject2;
        break;
      case 38: 
        localObject1[i1] = str2;
        i1 = 40;
        str1 = "\004t(6d\033K'.";
        i2 = 39;
        localObject1 = localObject2;
        break;
      case 39: 
        localObject1[i1] = str2;
        i1 = 41;
        str1 = "\033I%";
        i2 = 40;
        localObject1 = localObject2;
        break;
      case 40: 
        localObject1[i1] = str2;
        i1 = 42;
        str1 = "<M\"#u\f\03546bIT(6d\033K'.!\035Rf";
        i2 = 41;
        localObject1 = localObject2;
        break;
      case 41: 
        localObject1[i1] = str2;
        i1 = 43;
        str1 = "\004n2#s\035r(\027r\fO\0260d\032X(6";
        i2 = 42;
        localObject1 = localObject2;
        break;
      case 42: 
        localObject1[i1] = str2;
        i1 = 44;
        str1 = "";
        i2 = 43;
        localObject1 = localObject2;
        break;
      case 43: 
        localObject1[i1] = str2;
        i1 = 45;
        str1 = ":X2bR=|\024\026^:x\024\024H*x\031\rO6r\026\007OII)b";
        i2 = 44;
        localObject1 = localObject2;
        break;
      case 44: 
        localObject1[i1] = str2;
        i1 = 46;
        str1 = "\035O3'";
        i2 = 45;
        localObject1 = localObject2;
        break;
      case 45: 
        localObject1[i1] = str2;
        i1 = 47;
        str1 = "\017\\*1d";
        i2 = 46;
        localObject1 = localObject2;
        break;
      case 46: 
        localObject1[i1] = str2;
        i1 = 48;
        str1 = "\fE/6";
        i2 = 47;
        localObject1 = localObject2;
        break;
      case 47: 
        localObject1[i1] = str2;
        i1 = 49;
        str1 = ";X!+r\035X4bf\fIf#!\fO4-sI^)/l\bS\"b";
        i2 = 48;
        localObject1 = localObject2;
        break;
      case 48: 
        localObject1[i1] = str2;
        i1 = 50;
        str1 = "\fO4-sIY#1b\033T66h\006S|H";
        i2 = 49;
        localObject1 = localObject2;
        break;
      case 49: 
        localObject1[i1] = str2;
        i1 = 51;
        str1 = ";X!+r\035X4bG\bT*'eIJ/6iIX40n\033\035%-e\f\007f";
        i2 = 50;
        localObject1 = localObject2;
        break;
      case 50: 
        localObject1[i1] = str2;
        i1 = 52;
        str1 = "I丳f\003q\031v#;;";
        i2 = 51;
        localObject1 = localObject2;
        break;
      case 51: 
        localObject1[i1] = str2;
        i1 = 53;
        str1 = "";
        i2 = 52;
        localObject1 = localObject2;
        break;
      case 52: 
        localObject1[i1] = str2;
        i1 = 54;
        str1 = "IP\026-s\035\035{b";
        i2 = 53;
        localObject1 = localObject2;
        break;
      case 53: 
        localObject1[i1] = str2;
        i1 = 55;
        str1 = "\031Vf4d\033N/-oS\035";
        i2 = 54;
        localObject1 = localObject2;
        break;
      case 54: 
        localObject1[i1] = str2;
        i1 = 56;
        str1 = "乤匄鄋";
        i2 = 55;
        localObject1 = localObject2;
        break;
      case 55: 
        localObject1[i1] = str2;
        i1 = 57;
        str1 = "M\031";
        i2 = 56;
        localObject1 = localObject2;
        break;
      case 56: 
        localObject1[i1] = str2;
        i1 = 58;
        str1 = "\rX44h\ft\"b<I";
        i2 = 57;
        localObject1 = localObject2;
        break;
      case 57: 
        localObject1[i1] = str2;
        i1 = 59;
        str1 = ";X!+r\035X4x!";
        i2 = 58;
        localObject1 = localObject2;
        break;
      case 58: 
        localObject1[i1] = str2;
        i1 = 60;
        str1 = " S/6!\036T2*!D\035";
        i2 = 59;
        localObject1 = localObject2;
        break;
      case 59: 
        localObject1[i1] = str2;
        i1 = 61;
        str1 = "X\023pl0";
        i2 = 60;
        localObject1 = localObject2;
        break;
      case 60: 
        localObject1[i1] = str2;
        i1 = 62;
        str1 = ";X!+r\035X4bS\f^0bg\bT*'eI\020f0d\035\007";
        i2 = 61;
        localObject1 = localObject2;
        break;
      case 61: 
        localObject1[i1] = str2;
        i1 = 63;
        str1 = "卬吰|b";
        i2 = 62;
        localObject1 = localObject2;
        break;
      case 62: 
        localObject1[i1] = str2;
        i1 = 64;
        str1 = "\031U),d";
        i2 = 63;
        localObject1 = localObject2;
        break;
      case 63: 
        localObject1[i1] = str2;
        i1 = 65;
        str1 = "";
        i2 = 64;
        localObject1 = localObject2;
        break;
      case 64: 
        localObject1[i1] = str2;
        i1 = 66;
        str1 = "\033X!+r\035O'6h\006S\031+e";
        i2 = 65;
        localObject1 = localObject2;
        break;
      case 65: 
        localObject1[i1] = str2;
        i1 = 67;
        str1 = "\033X!+r\035t\002b<I";
        i2 = 66;
        localObject1 = localObject2;
        break;
      case 66: 
        localObject1[i1] = str2;
        i1 = 68;
        str1 = "";
        i2 = 67;
        localObject1 = localObject2;
        break;
      case 67: 
        localObject1[i1] = str2;
        i1 = 69;
        str1 = "9O#$r/T*'";
        i2 = 68;
        localObject1 = localObject2;
        break;
      case 68: 
        localObject1[i1] = str2;
        i1 = 70;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023\024\007F n\022\020@=t\t\f^ y";
        i2 = 69;
        localObject1 = localObject2;
        break;
      case 69: 
        localObject1[i1] = str2;
        i1 = 71;
        str1 = "";
        i2 = 70;
        localObject1 = localObject2;
        break;
      case 70: 
        localObject1[i1] = str2;
        i1 = 72;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023\007\022Q\"x\037";
        i2 = 71;
        localObject1 = localObject2;
        break;
      case 71: 
        localObject1[i1] = str2;
        i1 = 73;
        str1 = ",S' m\f\035\005*`\007S#.!\032H%!d\032N|b";
        i2 = 72;
        localObject1 = localObject2;
        break;
      case 72: 
        localObject1[i1] = str2;
        i1 = 74;
        str1 = ",S' m\f~.#o\007X*\020d\030H#1uI\\62-IN#,e\fOf's\033R4x!LNfgr";
        i2 = 73;
        localObject1 = localObject2;
        break;
      case 73: 
        localObject1[i1] = str2;
        i1 = 75;
        str1 = ":X2bl-X #t\005I\026-s\035\035{b";
        i2 = 74;
        localObject1 = localObject2;
        break;
      case 74: 
        localObject1[i1] = str2;
        i1 = 76;
        str1 = "\004m)0u";
        i2 = 75;
        localObject1 = localObject2;
        break;
      case 75: 
        localObject1[i1] = str2;
        i1 = 77;
        str1 = "\004t\026";
        i2 = 76;
        localObject1 = localObject2;
        break;
      case 76: 
        localObject1[i1] = str2;
        i1 = 78;
        str1 = "";
        i2 = 77;
        localObject1 = localObject2;
        break;
      case 77: 
        localObject1[i1] = str2;
        i1 = 79;
        str1 = "\004~30s\fS2\021h\032m)1";
        i2 = 78;
        localObject1 = localObject2;
        break;
      case 78: 
        localObject1[i1] = str2;
        i1 = 80;
        str1 = "<N#bR nf2n\033I|b";
        i2 = 79;
        localObject1 = localObject2;
        break;
      case 79: 
        localObject1[i1] = str2;
        i1 = 81;
        str1 = ".X2br\fO0'sIT6bd\033O)0!\036T2*;I";
        i2 = 80;
        localObject1 = localObject2;
        break;
      case 80: 
        localObject1[i1] = str2;
        i1 = 82;
        str1 = ":t\025bR\034^%'r\032";
        i2 = 81;
        localObject1 = localObject2;
        break;
      case 81: 
        localObject1[i1] = str2;
        i1 = 83;
        str1 = ":X2be\f['7m\035t\026b<I";
        i2 = 82;
        localObject1 = localObject2;
        break;
      case 82: 
        localObject1[i1] = str2;
        i1 = 84;
        str1 = "<N#b!\031R46;I";
        i2 = 83;
        localObject1 = localObject2;
        break;
      case 83: 
        localObject1[i1] = str2;
        i1 = 85;
        str1 = "\001I22^\033X6-s\035b5+r6H4.";
        i2 = 84;
        localObject1 = localObject2;
        break;
      case 84: 
        localObject1[i1] = str2;
        i1 = 86;
        str1 = "-s\025bh\007[)bh\032\007f";
        i2 = 85;
        localObject1 = localObject2;
        break;
      case 85: 
        localObject1[i1] = str2;
        i1 = 87;
        str1 = "5\031";
        i2 = 86;
        localObject1 = localObject2;
        break;
      case 86: 
        localObject1[i1] = str2;
        i1 = 88;
        str1 = ":t\025bS\f^#+w\fYf\021u\033T(%;I";
        i2 = 87;
        localObject1 = localObject2;
        break;
      case 87: 
        localObject1[i1] = str2;
        i1 = 89;
        str1 = "\032X(&d\033\035\017\006;I";
        i2 = 88;
        localObject1 = localObject2;
        break;
      case 88: 
        localObject1[i1] = str2;
        i1 = 90;
        str1 = "\034T\"$\r";
        i2 = 89;
        localObject1 = localObject2;
        break;
      case 89: 
        localObject1[i1] = str2;
        i1 = 91;
        str1 = "5\031\032f";
        i2 = 90;
        localObject1 = localObject2;
        break;
      case 90: 
        localObject1[i1] = str2;
        i1 = 92;
        str1 = "";
        i2 = 91;
        localObject1 = localObject2;
        break;
      case 91: 
        localObject1[i1] = str2;
        i1 = 93;
        str1 = "\035\\!1@\007Y\007.h\bNbf";
        i2 = 92;
        localObject1 = localObject2;
        break;
      case 92: 
        localObject1[i1] = str2;
        i1 = 94;
        str1 = "\033X%'h\037X\"f%";
        i2 = 93;
        localObject1 = localObject2;
        break;
      case 93: 
        localObject1[i1] = str2;
        i1 = 95;
        str1 = ",O4-sII'%`\005T'1";
        i2 = 94;
        localObject1 = localObject2;
        break;
      case 94: 
        localObject1[i1] = str2;
        i1 = 96;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2l@%t\007\021^=|\001\021";
        i2 = 95;
        localObject1 = localObject2;
        break;
      case 95: 
        localObject1[i1] = str2;
        i1 = 97;
        str1 = "(Q4'`\rDf\021d\035m31i=T+'-IZ/4dIH6b,I";
        i2 = 96;
        localObject1 = localObject2;
        break;
      case 96: 
        localObject1[i1] = str2;
        i1 = 98;
        str1 = "\032X7\035h\r";
        i2 = 97;
        localObject1 = localObject2;
        break;
      case 97: 
        localObject1[i1] = str2;
        i1 = 99;
        str1 = "";
        i2 = 98;
        localObject1 = localObject2;
        break;
      case 98: 
        localObject1[i1] = str2;
        i1 = 100;
        str1 = "\033X56`\033I\0310u\n";
        i2 = 99;
        localObject1 = localObject2;
        break;
      case 99: 
        localObject1[i1] = str2;
        i1 = 101;
        str1 = "\004~),o\f^2+n\007\035{b";
        i2 = 100;
        localObject1 = localObject2;
        break;
      case 100: 
        localObject1[i1] = str2;
        i1 = 102;
        str1 = "\017R45`\033Yf#b\035T),;I";
        i2 = 101;
        localObject1 = localObject2;
        break;
      case 101: 
        localObject1[i1] = str2;
        i1 = 103;
        str1 = "(Q4'`\rDf\016n\016Z#&! S";
        i2 = 102;
        localObject1 = localObject2;
        break;
      case 102: 
        localObject1[i1] = str2;
        i1 = 104;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lS,m\t\020U";
        i2 = 103;
        localObject1 = localObject2;
        break;
      case 103: 
        localObject1[i1] = str2;
        i1 = 105;
        str1 = "\b^2+n\007\007.#o\rQ#\013o\017R\024'q\006O2b,I";
        i2 = 104;
        localObject1 = localObject2;
        break;
      case 104: 
        localObject1[i1] = str2;
        i1 = 106;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lT:x\024\035F;r\023\fE";
        i2 = 105;
        localObject1 = localObject2;
        break;
      case 105: 
        localObject1[i1] = str2;
        i1 = 107;
        str1 = "\032I)2^\035U4'`\r";
        i2 = 106;
        localObject1 = localObject2;
        break;
      case 106: 
        localObject1[i1] = str2;
        i1 = 108;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lH't\022";
        i2 = 107;
        localObject1 = localObject2;
        break;
      case 107: 
        localObject1[i1] = str2;
        i1 = 109;
        str1 = "\005R%\026x\031X5bh\032\007f";
        i2 = 108;
        localObject1 = localObject2;
        break;
      case 108: 
        localObject1[i1] = str2;
        i1 = 110;
        str1 = "5\020";
        i2 = 109;
        localObject1 = localObject2;
        break;
      case 109: 
        localObject1[i1] = str2;
        i1 = 111;
        str1 = "\001\\(&m\fn2-q9H5*!\032H%!d\032N|b";
        i2 = 110;
        localObject1 = localObject2;
        break;
      case 110: 
        localObject1[i1] = str2;
        i1 = 112;
        str1 = "\nQ)1d\031H5*";
        i2 = 111;
        localObject1 = localObject2;
        break;
      case 111: 
        localObject1[i1] = str2;
        i1 = 113;
        str1 = "\bM6";
        i2 = 112;
        localObject1 = localObject2;
        break;
      case 112: 
        localObject1[i1] = str2;
        i1 = 114;
        str1 = "\nSh(q\034N.l`\007Y4-h\r\023/,u\fS2lQ<n\016\035U p\003";
        i2 = 113;
        localObject1 = localObject2;
        break;
      case 113: 
        localObject1[i1] = str2;
        i1 = 115;
        str1 = "\034N#0^\016O)7o\r";
        i2 = 114;
        localObject1 = localObject2;
        break;
      case 114: 
        localObject1[i1] = str2;
        i1 = 116;
        str1 = "";
        i2 = 115;
        localObject1 = localObject2;
        break;
      case 115: 
        localObject1[i1] = str2;
        i1 = 117;
        str1 = "E\035";
        i2 = 116;
        localObject1 = localObject2;
        break;
      case 116: 
        localObject1[i1] = str2;
        i1 = 118;
        str1 = "\001\\(&m\fn2-q9H5*!\bM6n!\032X(&d\033\035#0s\006O|b$\032\035c1";
        i2 = 117;
        localObject1 = localObject2;
        break;
      case 117: 
        localObject1[i1] = str2;
        i1 = 119;
        str1 = "\001\\(&m\fn#6Q\034N.\026h\004Xf1t\n^#1rI\020f";
        i2 = 118;
        localObject1 = localObject2;
        break;
      case 118: 
        localObject1[i1] = str2;
        i1 = 120;
        str1 = "\006S\0256`\033I\005-l\004\\(&!D\03556`\033I\017&;";
        i2 = 119;
        localObject1 = localObject2;
        break;
      case 119: 
        localObject1[i1] = str2;
        i1 = 121;
        str1 = "\005R%\026x\031X";
        i2 = 120;
        localObject1 = localObject2;
        break;
      case 120: 
        localObject1[i1] = str2;
        i1 = 122;
        str1 = "\033I%\035e\fQ';";
        i2 = 121;
        localObject1 = localObject2;
        break;
      case 121: 
        localObject1[i1] = str2;
        i1 = 123;
        str1 = "5b";
        i2 = 122;
        localObject1 = localObject2;
        break;
      case 122: 
        localObject1[i1] = str2;
        i1 = 124;
        str1 = "";
        i2 = 123;
        localObject1 = localObject2;
        break;
      case 123: 
        localObject1[i1] = str2;
        i1 = 125;
        str1 = ":X44h\nXf t\007Y*'!D\035";
        i2 = 124;
        localObject1 = localObject2;
        break;
      case 124: 
        localObject1[i1] = str2;
        i1 = 126;
        str1 = "\033X6-s\035";
        i2 = 125;
        localObject1 = localObject2;
        break;
      case 125: 
        localObject1[i1] = str2;
        i1 = 127;
        str1 = "\bR1";
        i2 = 126;
        localObject1 = localObject2;
        break;
      case 126: 
        localObject1[i1] = str2;
        i1 = 128;
        str1 = ":H%!d\fYf6nIO#2n\033If+o\017Rfo!";
        i2 = 127;
        localObject1 = localObject2;
        break;
      case 127: 
        localObject1[i1] = str2;
        i1 = 129;
        str1 = "\032I'0S\035^f5h\035Uf/H\007I#0w\bQf!";
        i2 = 128;
        localObject1 = localObject2;
        break;
      case 128: 
        localObject1[i1] = str2;
        i1 = 130;
        str1 = "";
        i2 = 129;
        localObject1 = localObject2;
        break;
      case 129: 
        localObject1[i1] = str2;
        i1 = 131;
        str1 = "\bQ'0l";
        i2 = 130;
        localObject1 = localObject2;
        break;
      case 130: 
        localObject1[i1] = str2;
        i1 = 132;
        str1 = ":X(&!:X2\026`\016N\007,e(Q/#rIO#3t\fN2bu\006\0355's\037X4b,I";
        i2 = 131;
        localObject1 = localObject2;
        break;
      case 131: 
        localObject1[i1] = str2;
        i1 = 133;
        str1 = "\032I)2Q\034N.n";
        i2 = 132;
        localObject1 = localObject2;
        break;
      case 132: 
        localObject1[i1] = str2;
        i1 = 134;
        str1 = "\016M5";
        i2 = 133;
        localObject1 = localObject2;
        break;
      case 133: 
        localObject1[i1] = str2;
        i1 = 135;
        str1 = "\nX*.^\035R1's\032";
        i2 = 134;
        localObject1 = localObject2;
        break;
      case 134: 
        localObject1[i1] = str2;
        i1 = 136;
        str1 = "\036T +^\035R1's\032";
        i2 = 135;
        localObject1 = localObject2;
        break;
      case 135: 
        localObject1[i1] = str2;
        i1 = 137;
        str1 = "\nR*\026x\031X";
        i2 = 136;
        localObject1 = localObject2;
        break;
      case 136: 
        localObject1[i1] = str2;
        i1 = 138;
        str1 = "";
        i2 = 137;
        localObject1 = localObject2;
        break;
      case 137: 
        localObject1[i1] = str2;
        i1 = 139;
        str1 = "\bQ*";
        i2 = 138;
        localObject1 = localObject2;
        break;
      case 138: 
        localObject1[i1] = str2;
        i1 = 140;
        str1 = "";
        i2 = 139;
        localObject1 = localObject2;
        break;
      case 139: 
        localObject1[i1] = str2;
        i1 = 141;
        str1 = "";
        i2 = 140;
        localObject1 = localObject2;
        break;
      case 140: 
        localObject1[i1] = str2;
        i1 = 142;
        str1 = "<x";
        i2 = 141;
        localObject1 = localObject2;
        break;
      case 141: 
        localObject1[i1] = str2;
        i1 = 143;
        str1 = "\004i.0d\bYf+rIS3.mE\0354'r\035\\46!\035U#bu\001O##eE\035/&!T\035";
        i2 = 142;
        localObject1 = localObject2;
        break;
      case 142: 
        localObject1[i1] = str2;
        i1 = 144;
        str1 = "\rX0\035h\007[)\035s\fM\0316h\004X";
        i2 = 143;
        localObject1 = localObject2;
        break;
      case 143: 
        localObject1[i1] = str2;
        i1 = 145;
        str1 = "";
        i2 = 144;
        localObject1 = localObject2;
        break;
      case 144: 
        localObject1[i1] = str2;
        i1 = 146;
        str1 = "\005^2+l\f";
        i2 = 145;
        localObject1 = localObject2;
        break;
      case 145: 
        localObject1[i1] = str2;
        i1 = 147;
        str1 = "\006S\002'r\035O);!D\03560n\nX51H\r\007";
        i2 = 146;
        localObject1 = localObject2;
        break;
      case 146: 
        localObject1[i1] = str2;
        i1 = 148;
        str1 = "\033X6-s\035\021";
        i2 = 147;
        localObject1 = localObject2;
        break;
      case 147: 
        localObject1[i1] = str2;
        i1 = 149;
        str1 = "";
        i2 = 148;
        localObject1 = localObject2;
        break;
      case 148: 
        localObject1[i1] = str2;
        i1 = 150;
        str1 = "\fS' m\f~.#o\007X*n";
        i2 = 149;
        localObject1 = localObject2;
        break;
      case 149: 
        localObject1[i1] = str2;
        i1 = 151;
        str1 = "/\\/.d\r\0352-!\033X6-s\035\0356's\004T51h\006Sf+o\017Rfo!\031\\!';I";
        i2 = 150;
        localObject1 = localObject2;
        break;
      case 150: 
        localObject1[i1] = str2;
        i1 = 152;
        str1 = "";
        i2 = 151;
        localObject1 = localObject2;
        break;
      case 151: 
        localObject1[i1] = str2;
        i1 = 153;
        str1 = "E\037";
        i2 = 152;
        localObject1 = localObject2;
        break;
      case 152: 
        localObject1[i1] = str2;
        i1 = 154;
        str1 = "E\0354'uS";
        i2 = 153;
        localObject1 = localObject2;
        break;
      case 153: 
        localObject1[i1] = str2;
        i1 = 155;
        str1 = "\033I%bh\007\035";
        i2 = 154;
        localObject1 = localObject2;
        break;
      case 154: 
        localObject1[i1] = str2;
        i1 = 156;
        str1 = "IQ'6d\033";
        i2 = 155;
        localObject1 = localObject2;
        break;
      case 155: 
        localObject1[i1] = str2;
        i1 = 157;
        str1 = "\035^6\035e\bI'";
        i2 = 156;
        localObject1 = localObject2;
        break;
      case 156: 
        localObject1[i1] = str2;
        i1 = 158;
        str1 = ".X2b!\035^6be\bI'bg\033R+bE+\021f6i\f\035%-t\007If+rS\035";
        i2 = 157;
        localObject1 = localObject2;
        break;
      case 157: 
        localObject1[i1] = str2;
        i1 = 159;
        str1 = "\033X6\035h\r";
        i2 = 158;
        localObject1 = localObject2;
        break;
      case 158: 
        localObject1[i1] = str2;
        i1 = 160;
        str1 = ".X2bu\nMf&`\035\\f$s\006Pf\006CS\035";
        i2 = 159;
        localObject1 = localObject2;
        break;
      case 159: 
        localObject1[i1] = str2;
        i1 = 161;
        str1 = "=U#br\fO0+b\f\0351+m\005\035-+m\005\035/6r\fQ bh\007\035";
        i2 = 160;
        localObject1 = localObject2;
        break;
      case 160: 
        localObject1[i1] = str2;
        i1 = 162;
        str1 = "\006S\002+r\nR(,d\nI#&";
        i2 = 161;
        localObject1 = localObject2;
        break;
      case 161: 
        localObject1[i1] = str2;
        i1 = 163;
        str1 = "\006S\002+r\nR(,d\nI#&!\bS\"bs\fI4;!$n\001\035J,x\026\035@%t\020\007^'r\013\003MI";
        i2 = 162;
        localObject1 = localObject2;
        break;
      case 162: 
        localObject1[i1] = str2;
        i1 = 164;
        str1 = "/\\/.d\r\0352-!\032X2bq\034N.\026h\004Xfo!\033X2x!";
        i2 = 163;
        localObject1 = localObject2;
        break;
      case 163: 
        localObject1[i1] = str2;
        i1 = 165;
        str1 = "";
        i2 = 164;
        localObject1 = localObject2;
        break;
      case 164: 
        localObject1[i1] = str2;
        i1 = 166;
        str1 = "";
        i2 = 165;
        localObject1 = localObject2;
        break;
      case 165: 
        localObject1[i1] = str2;
        i1 = 167;
        str1 = "\004{/0r\035q)%f\fY\017,";
        i2 = 166;
        localObject1 = localObject2;
        break;
      case 166: 
        localObject1[i1] = str2;
        i1 = 168;
        str1 = "\033X%'h\037X\"";
        i2 = 167;
        localObject1 = localObject2;
        break;
      case 167: 
        localObject1[i1] = str2;
        i1 = 169;
        str1 = "\032X(&d\033T\"";
        i2 = 168;
        localObject1 = localObject2;
        break;
      case 168: 
        localObject1[i1] = str2;
        i1 = 170;
        str1 = "\032I)2Q\034N.";
        i2 = 169;
        localObject1 = localObject2;
        break;
      case 169: 
        localObject1[i1] = str2;
        i1 = 171;
        str1 = "/\\/.d\r\0352-!,S' m\f~.#o\007X*b,IO#6;I";
        i2 = 170;
        localObject1 = localObject2;
        break;
      case 170: 
        localObject1[i1] = str2;
        i1 = 172;
        str1 = "\fS' m\f~.#o\007X*";
        i2 = 171;
        localObject1 = localObject2;
        break;
      case 171: 
        localObject1[i1] = str2;
        i1 = 173;
        str1 = "";
        i2 = 172;
        localObject1 = localObject2;
        break;
      case 172: 
        localObject1[i1] = str2;
        i1 = 174;
        str1 = "";
        i2 = 173;
        localObject1 = localObject2;
        break;
      case 173: 
        localObject1[i1] = str2;
        i1 = 175;
        str1 = "I\007f";
        i2 = 174;
        localObject1 = localObject2;
        break;
      case 174: 
        localObject1[i1] = str2;
        i1 = 176;
        str1 = ":H%!d\fYf6nIx(#c\005X\005*`\007S#.!D\035";
        i2 = 175;
        localObject1 = localObject2;
        break;
      case 175: 
        localObject1[i1] = str2;
        i1 = 177;
        str1 = "";
        i2 = 176;
        localObject1 = localObject2;
        break;
      case 176: 
        localObject1[i1] = str2;
        i1 = 178;
        str1 = "/\\/.d\r\0352-!\032X2bu\bZ5\003o\r|*+`\032\035kbs\fI|b";
        i2 = 177;
        localObject1 = localObject2;
        break;
      case 177: 
        localObject1[i1] = str2;
        i1 = 179;
        str1 = "";
        i2 = 178;
        localObject1 = localObject2;
        break;
      case 178: 
        localObject1[i1] = str2;
        i1 = 180;
        str1 = "";
        i2 = 179;
        localObject1 = localObject2;
        break;
      case 179: 
        localObject1[i1] = str2;
        i1 = 181;
        str1 = "";
        i2 = 180;
        localObject1 = localObject2;
        break;
      case 180: 
        localObject1[i1] = str2;
        i1 = 182;
        str1 = "\035\\!1@\007Y\007.h\bN";
        i2 = 181;
        localObject1 = localObject2;
        break;
      case 181: 
        localObject1[i1] = str2;
        i1 = 183;
        str1 = "/\\/.d\r\0352-!\033X6-s\035\035/,g\006\035kbs\fI|";
        i2 = 182;
        localObject1 = localObject2;
        break;
      case 182: 
        localObject1[i1] = str2;
        i1 = 184;
        str1 = "/\\/.d\r\0352-!\032I)2Q\034N.b,IO#6;I";
        i2 = 183;
        localObject1 = localObject2;
        break;
      case 183: 
        localObject1[i1] = str2;
        i1 = 185;
        str1 = ":H%!d\fYf6nIN2-q9H5*!D\035";
        i2 = 184;
        localObject1 = localObject2;
        break;
      case 184: 
        localObject1[i1] = str2;
        i1 = 186;
        str1 = "\bM6+e";
        i2 = 185;
        localObject1 = localObject2;
        break;
      case 185: 
        localObject1[i1] = str2;
        i1 = 187;
        str1 = "\nR\"'";
        i2 = 186;
        localObject1 = localObject2;
        break;
      case 186: 
        localObject1[i1] = str2;
        i1 = 188;
        str1 = "\007H*.!\n\\*.c\b^-b!D\035";
        i2 = 187;
        localObject1 = localObject2;
        break;
      case 187: 
        localObject1[i1] = str2;
        i1 = 189;
        str1 = ":H%!d\fYf5h\035Uf1d\030t\"b!D\035";
        i2 = 188;
        localObject1 = localObject2;
        break;
      case 188: 
        localObject1[i1] = str2;
        i1 = 190;
        str1 = "\032X77d\007^#";
        i2 = 189;
        localObject1 = localObject2;
        break;
      case 189: 
        localObject1[i1] = str2;
        i1 = 191;
        str1 = "\031Q'6g\006O+";
        i2 = 190;
        localObject1 = localObject2;
        break;
      case 190: 
        localObject1[i1] = str2;
        i1 = 192;
        str1 = "\fO4-s\032";
        i2 = 191;
        localObject1 = localObject2;
        break;
      case 191: 
        localObject1[i1] = str2;
        i1 = 193;
        str1 = "";
        i2 = 192;
        localObject1 = localObject2;
        break;
      case 192: 
        localObject1[i1] = str2;
        i1 = 194;
        str1 = "\032X44d\033\035%-o\017T!br\034^%'r\032";
        i2 = 193;
        localObject1 = localObject2;
        break;
      case 193: 
        localObject1[i1] = str2;
        i1 = 195;
        str1 = "<S-,n\036S";
        i2 = 194;
        localObject1 = localObject2;
        break;
      case 194: 
        localObject1[i1] = str2;
        i1 = 196;
        str1 = "=U#bw\fO5+n\007s'/dIT5bo\006If4`\005T\"n!9Q##r\f\035%*d\nVf;n\034Of\003o\rO)+e$\\(+g\fN2ly\004Q";
        i2 = 195;
        localObject1 = localObject2;
        break;
      case 195: 
        localObject1[i1] = str2;
        i1 = 197;
        str1 = "\f\\5;u\006P#1r\bZ#lb\006Pb";
        i2 = 196;
        localObject1 = localObject2;
        break;
      case 196: 
        localObject1[i1] = str2;
        i1 = 198;
        str1 = "\016R),b\001X%)/\nR+f";
        i2 = 197;
        localObject1 = localObject2;
      }
    }
    localObject1[i1] = str2;
    bb = (String[])localObject2;
    b = false;
    c = false;
    d = 2;
    e = 7200000L;
    f = 86400000L;
    g = 3600000L;
    h = 300;
    i = 0L;
    j = 0L;
    A = false;
    B = true;
    String str3 = "X\005ul3Z\017hp8G\fz";
    int i5 = -1;
    label5285:
    label5424:
    String str4;
    for (;;)
    {
      Object localObject4 = str3.toCharArray();
      int i6 = localObject4.length;
      int i7 = 0;
      if (i6 <= 1) {}
      while (i6 > i7)
      {
        Object localObject5 = localObject4;
        int i8 = i7;
        int i9 = i6;
        Object localObject6 = localObject4;
        int i10 = localObject6[i7];
        int i11;
        switch (i8 % 5)
        {
        default: 
          i11 = 1;
        }
        for (;;)
        {
          localObject6[i7] = ((char)(i11 ^ i10));
          i7 = i8 + 1;
          if (i9 != 0) {
            break label5424;
          }
          localObject6 = localObject5;
          i8 = i7;
          i7 = i9;
          break label5285;
          i15 = 105;
          break;
          i15 = 61;
          break;
          i15 = 70;
          break;
          i15 = 66;
          break;
          i11 = 105;
          continue;
          i11 = 61;
          continue;
          i11 = 70;
          continue;
          i11 = 66;
        }
        i6 = i9;
        localObject4 = localObject5;
      }
      str4 = new String((char[])localObject4).intern();
      switch (i5)
      {
      default: 
        k = str4;
        l = 3000;
        str3 = "X\fql0Z\bhs7Y\023ru";
        i5 = 0;
        break;
      case 0: 
        C = str4;
        str3 = "";
        i5 = 1;
        break;
      case 1: 
        D = str4;
        E = 3000;
        str3 = "\032\023,2t\032Uh!o";
        i5 = 2;
        break;
      case 2: 
        F = str4;
        str3 = "X\fwl0Z\023rz/X\rr";
        i5 = 3;
        break;
      case 3: 
        G = str4;
        H = 9000;
        I = 0;
        m = true;
        n = true;
        str3 = "\007H*.";
        i5 = 4;
      }
    }
    J = str4;
    o = 0L;
    p = null;
    q = "";
    P = false;
    Q = false;
    R = 10;
    v = false;
    T = true;
    w = bb[''];
    x = false;
    y = false;
    ArrayList localArrayList = new ArrayList();
    U = localArrayList;
    localArrayList.add(F + "$" + G);
    U.add(bb['Å'] + G);
    U.add(bb['Æ'] + G);
    z = 0;
  }
  
  private void A()
  {
    r.b();
    v();
    p();
  }
  
  private void B()
  {
    this.ae.removeMessages(1007);
  }
  
  private void C()
  {
    r.b();
    this.S = a(this, w, y, x);
    this.S.f();
  }
  
  private static int a(int paramInt1, long paramLong, String paramString1, String paramString2, int paramInt2)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString2);
      localJSONObject.put(bb['¿'], "a");
      if ((paramInt1 != 0) && (paramLong != 0L))
      {
        int i1 = PushProtocol.TagAlias(paramInt1, paramLong, paramString1, localJSONObject.toString(), paramInt2);
        return i1;
      }
    }
    catch (Exception localException) {}
    return -1;
  }
  
  public static long a(Context paramContext)
  {
    if (o != 0L) {
      return o;
    }
    P = c(paramContext);
    return o;
  }
  
  private cn.jpush.android.b.d a(Context paramContext, String paramString, boolean paramBoolean1, boolean paramBoolean2)
  {
    return new h(this, paramContext, paramString, paramBoolean1, paramBoolean2);
  }
  
  public static void a(int paramInt)
  {
    E = paramInt;
  }
  
  private void a(int paramInt1, int paramInt2)
  {
    String str = bb[94] + paramInt1 + bb[57] + paramInt2;
    if (!this.t.contains(str)) {
      this.t.offer(str);
    }
  }
  
  private void a(Context paramContext, String paramString)
  {
    r.a();
    String[] arrayOfString = q.a(paramContext);
    if ((arrayOfString == null) || (arrayOfString.length == 0))
    {
      r.e();
      return;
    }
    int i1 = arrayOfString.length;
    String str1 = "[";
    int i2 = 0;
    int i3 = 0;
    int i4 = 0;
    label39:
    String str2;
    if (i2 < i1)
    {
      str2 = arrayOfString[i2];
      if (i3 != 0) {
        break label342;
      }
    }
    label342:
    for (str1 = str1 + "\"" + str2 + "\"";; str1 = str1 + bb[''] + str2 + "\"")
    {
      int i5 = i2 + 1;
      int i6 = i3 + 1;
      if ((i6 >= 50) || (str1.length() > 1000) || (i5 == i1))
      {
        String str3 = str1 + "]";
        String str4 = bb[''];
        Object[] arrayOfObject = new Object[5];
        arrayOfObject[0] = Integer.valueOf(i1);
        arrayOfObject[1] = Integer.valueOf(i4);
        arrayOfObject[2] = paramString;
        arrayOfObject[3] = Long.valueOf(o);
        arrayOfObject[4] = str3;
        String str5 = String.format(str4, arrayOfObject);
        r.b();
        if (Q) {
          p();
        }
        if ((this.r != 0) && (this.K != null) && (this.K.isAlive()))
        {
          int i8 = PushProtocol.RepPush(this.r, o, (byte)8, str5);
          if (i8 != 0)
          {
            new StringBuilder(bb['']).append(i4).append(bb['']).append(i8).toString();
            r.a();
          }
        }
        int i7 = i4 + 1;
        str1 = "[";
        i4 = i7;
        i6 = 0;
      }
      i3 = i6;
      i2 = i5;
      break label39;
      break;
    }
  }
  
  public static void a(String paramString)
  {
    C = paramString;
  }
  
  private void a(String paramString, int paramInt)
  {
    if (paramInt != 0)
    {
      b localb = (b)ServiceInterface.d.get(Integer.valueOf(paramInt));
      if ((localb != null) && (localb.c != null))
      {
        Message localMessage = new Message();
        localMessage.obj = Integer.valueOf(paramInt);
        localMessage.what = 1006;
        this.ae.sendMessageDelayed(localMessage, 20000L);
      }
    }
    for (int i1 = paramInt;; i1 = z.b(getApplicationContext()))
    {
      b(paramString, J, i1);
      if ((this.r != 0) && (o != 0L)) {
        break;
      }
      r.b();
      x();
      return;
    }
    if (a(this.r, o, J, paramString, i1) < 0)
    {
      x();
      return;
    }
    h(i1);
    r.c(bb[4], bb[''] + paramString);
  }
  
  private void a(String paramString1, String paramString2)
  {
    z();
    x();
    if ((paramString1 == null) || (paramString2 == null))
    {
      String.format(bb[74], new Object[] { paramString1, paramString2 });
      r.e();
      return;
    }
    if ((this.r == 0) || (o == 0L))
    {
      r.b();
      c(paramString1, paramString2);
      x();
      return;
    }
    int i1 = PushProtocol.EnChannel(this.r, o, paramString1, paramString2);
    if (i1 < 0)
    {
      c(paramString1, paramString2);
      x();
      return;
    }
    new StringBuilder(bb[73]).append(i1).toString();
    r.c();
  }
  
  private void a(String paramString1, String paramString2, int paramInt)
  {
    String str3;
    try
    {
      Iterator localIterator = this.t.iterator();
      String[] arrayOfString;
      while (localIterator.hasNext())
      {
        String str2 = (String)localIterator.next();
        if (str2.startsWith(bb[93]))
        {
          arrayOfString = str2.split(bb[91]);
          if (arrayOfString.length > 3)
          {
            str3 = e(arrayOfString[2], paramString1);
            if (!ac.a(str3)) {
              this.t.remove(str2);
            }
          }
        }
      }
      try
      {
        ServiceInterface.b(Integer.valueOf(arrayOfString[3]).intValue());
        paramString1 = str3;
      }
      catch (Exception localException2)
      {
        for (;;)
        {
          String str1;
          paramString1 = str3;
        }
      }
      str1 = bb[93] + paramString2 + bb[57] + paramString1 + bb[57] + paramInt;
      new StringBuilder(bb[92]).append(paramString1).toString();
      r.b();
      this.t.offer(str1);
      return;
    }
    catch (Exception localException1) {}
  }
  
  private void a(String paramString1, String paramString2, String paramString3, String paramString4)
  {
    Intent localIntent = new Intent(paramString4);
    if (paramString2 != null) {
      localIntent.putExtra(bb[72], paramString2);
    }
    localIntent.putExtra(bb[70], paramString3);
    localIntent.addCategory(paramString1);
    sendBroadcast(localIntent, String.format(bb[71], new Object[] { paramString1 }));
  }
  
  public static void a(boolean paramBoolean)
  {
    A = paramBoolean;
  }
  
  private void a(boolean paramBoolean1, boolean paramBoolean2)
  {
    
    if (paramBoolean2)
    {
      if (this.r != 0) {
        this.r = PushProtocol.Close(this.r);
      }
      this.r = PushProtocol.InitConn();
      c();
      new StringBuilder(bb[60]).append(C).append(bb[54]).append(E).toString();
      r.b();
      if (PushProtocol.InitPush(this.r, C, E) != 0)
      {
        r.b();
        if (this.r != 0) {
          this.r = PushProtocol.Close(this.r);
        }
        f(0);
        break label119;
        break label119;
      }
    }
    label119:
    while (this.r == 0) {
      return;
    }
    TelephonyManager localTelephonyManager = (TelephonyManager)getSystemService(bb[64]);
    String str1 = cn.jpush.android.c.a.j(getApplicationContext());
    if (cn.jpush.android.c.a.c(getApplicationContext(), bb[65])) {}
    for (String str2 = localTelephonyManager.getSubscriberId();; str2 = null)
    {
      if (str1 == null) {
        str1 = " ";
      }
      if (str2 == null) {
        str2 = " ";
      }
      String str3 = getPackageName();
      String str4 = str1 + bb[57] + str2 + bb[57] + str3 + bb[57] + J;
      String str5 = t();
      String str6 = cn.jpush.android.c.a.a(getApplicationContext(), bb[61]);
      new StringBuilder(bb[59]).append(str4).toString();
      r.b();
      new StringBuilder(bb[55]).append(str5).toString();
      r.b();
      r.b();
      int i1 = this.r;
      String str7 = cn.jpush.android.c.a.l(getApplicationContext());
      String str8 = cn.jpush.android.c.a.k(getApplicationContext());
      String str9 = cn.jpush.android.c.a.g(getApplicationContext(), " ");
      String str10 = cn.jpush.android.c.a.h(getApplicationContext(), " ");
      if (ac.a(str7)) {
        str7 = " ";
      }
      if (ac.a(str8)) {
        str8 = " ";
      }
      if (ac.a(str9)) {
        str9 = " ";
      }
      PushProtocol.RegPush(i1, str4, str5, str6, cn.jpush.android.c.a.a + bb[57] + str7 + bb[57] + str10 + bb[57] + str8 + bb[57] + str9);
      int i2 = 0;
      int i3 = PushProtocol.RecvPush(this.r, this.s, 30);
      if (i3 > 0)
      {
        int i4 = cn.jpush.android.c.a.a(this.s);
        int i5 = cn.jpush.android.c.a.b(this.s);
        if (i4 != c.a.ordinal())
        {
          new StringBuilder(bb[49]).append(i4).toString();
          r.e();
          return;
        }
        for (int i6 = 0; i6 < 2; i6++) {
          i2 = (i2 << 8) + (0xFF & this.s[(i6 + 6)]);
        }
        if (i2 == 0)
        {
          if (h == 86401)
          {
            r.b();
            z.b(getApplicationContext(), bb[40], 300);
            h = 300;
            z();
          }
          int i10 = 0;
          long l2;
          for (long l1 = 0L; i10 < 4; l1 = l2)
          {
            l2 = (l1 << 8) + (0xFF & this.s[(i10 + 8)]);
            i10++;
          }
          int i11 = 0;
          int i24;
          for (int i12 = 0; i11 < 2; i12 = i24)
          {
            i24 = (i12 << 8) + (0xFF & this.s[(i11 + 12)]);
            i11++;
          }
          byte[] arrayOfByte2 = new byte[i12];
          for (int i13 = 0; i13 < arrayOfByte2.length; i13++) {
            arrayOfByte2[i13] = ((byte)(0xFF & this.s[(i13 + 14)]));
          }
          String str13 = new String(arrayOfByte2);
          new StringBuilder(bb[53]).append(l1).toString();
          r.c();
          o = l1;
          p = str13;
          P = true;
          int i19;
          try
          {
            FileOutputStream localFileOutputStream = openFileOutput(bb[69], 0);
            localFileOutputStream.write(ByteBuffer.allocate(8).putLong(o).array());
            localFileOutputStream.write(p.getBytes());
            localFileOutputStream.close();
            i14 = i12 + 14;
            i15 = 0;
            for (int i16 = 0; i16 < 2; i16++) {
              i15 = (i15 << 8) + (0xFF & this.s[(i14 + i16)]);
            }
          }
          catch (FileNotFoundException localFileNotFoundException)
          {
            for (;;)
            {
              r.g();
            }
          }
          catch (IOException localIOException)
          {
            int i14;
            int i15;
            for (;;)
            {
              r.g();
            }
            int i17 = i14 + 2;
            byte[] arrayOfByte3 = new byte[i15];
            for (int i18 = 0; i18 < arrayOfByte3.length; i18++) {
              arrayOfByte3[i18] = ((byte)(0xFF & this.s[(i17 + i18)]));
            }
            String str14 = new String(arrayOfByte3);
            new StringBuilder(bb[67]).append(str14).toString();
            r.b();
            if (!ac.a(str14))
            {
              z.b(getApplicationContext(), bb[66], str14);
              a(cn.jpush.android.a.b, cn.jpush.android.a.f, str14, bb[27]);
            }
            i19 = i17 + i15;
          }
          if (i19 >= i5) {
            break;
          }
          int i20 = 0;
          for (int i21 = 0; i21 < 2; i21++) {
            i20 = (i20 << 8) + (0xFF & this.s[(i19 + i21)]);
          }
          int i22 = i19 + 2;
          byte[] arrayOfByte4 = new byte[i20];
          if (i5 != i20 + i22)
          {
            r.e();
            return;
          }
          for (int i23 = 0; i23 < arrayOfByte4.length; i23++) {
            arrayOfByte4[i23] = ((byte)(0xFF & this.s[(i22 + i23)]));
          }
          String str15 = new String(arrayOfByte4);
          new StringBuilder(bb[58]).append(str15).toString();
          r.b();
          cn.jpush.android.c.a.i(getApplicationContext(), str15);
          return;
        }
        if (i2 == 1007)
        {
          int i7 = 0;
          for (int i8 = 0; i8 < 2; i8++) {
            i7 = (i7 << 8) + (0xFF & this.s[(i8 + 8)]);
          }
          byte[] arrayOfByte1 = new byte[i7];
          for (int i9 = 0; i9 < arrayOfByte1.length; i9++) {
            arrayOfByte1[i9] = ((byte)(0xFF & this.s[(i9 + 10)]));
          }
          String str12 = new String(arrayOfByte1);
          new StringBuilder(bb[68]).append(str12).toString();
          r.e();
          cn.jpush.android.c.a.c(str12);
          if (paramBoolean1) {
            break;
          }
          a(true, false);
          return;
        }
        r.e(bb[4], bb[51] + i2);
        String str11 = l.a(i2);
        if (str11 != null) {
          r.e(bb[4], bb[50] + str11);
        }
        if (1006 == i2)
        {
          s();
          return;
        }
        if (1007 == i2)
        {
          r.c();
          return;
        }
        if (1005 != i2) {
          break;
        }
        cn.jpush.android.c.a.b(getApplicationContext(), bb[63] + getPackageName() + bb[52] + cn.jpush.android.a.f + bb[56], bb[63] + getPackageName() + bb[52] + cn.jpush.android.a.f + bb[56]);
        s();
        return;
      }
      r.e(bb[4], bb[62] + i3);
      this.Y = 0L;
      return;
    }
  }
  
  public static boolean a()
  {
    return B;
  }
  
  public static String b(Context paramContext)
  {
    if (!ac.a(p)) {
      return p;
    }
    P = c(paramContext);
    return p;
  }
  
  public static void b(int paramInt)
  {
    H = paramInt;
  }
  
  public static void b(String paramString)
  {
    D = paramString;
  }
  
  private void b(String paramString1, String paramString2)
  {
    String str = bb[''] + paramString1 + "," + paramString2;
    if (this.t.contains(str)) {
      return;
    }
    this.t.offer(str);
  }
  
  private void b(String paramString1, String paramString2, int paramInt)
  {
    try
    {
      StringBuilder localStringBuilder = new StringBuilder();
      localStringBuilder.append(paramInt).append(bb[57]).append(paramString2).append(bb[57]).append(paramString1);
      String str = localStringBuilder.toString();
      d(paramString1, paramString2);
      this.u.offer(str);
      if (this.u.size() >= 200) {
        this.u.poll();
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  public static void b(boolean paramBoolean)
  {
    B = paramBoolean;
  }
  
  public static boolean b()
  {
    return true;
  }
  
  public static void c(int paramInt)
  {
    I = paramInt;
  }
  
  public static void c(String paramString)
  {
    F = paramString;
  }
  
  private void c(String paramString1, String paramString2)
  {
    String str = bb[''] + paramString1 + "," + paramString2;
    if (this.t.contains(str)) {
      return;
    }
    this.t.offer(str);
  }
  
  public static void c(boolean paramBoolean)
  {
    Q = paramBoolean;
  }
  
  protected static boolean c(Context paramContext)
  {
    for (;;)
    {
      boolean bool2;
      try
      {
        r.c();
        try
        {
          byte[] arrayOfByte = new byte[8];
          FileInputStream localFileInputStream = paramContext.openFileInput(bb[69]);
          localFileInputStream.read(arrayOfByte, 0, 8);
          o = 0L;
          int i1 = 0;
          if (i1 < 8)
          {
            o = (o << 8) + (0xFF & arrayOfByte[i1]);
            i1++;
            continue;
          }
          StringBuilder localStringBuilder = new StringBuilder();
          int i2 = localFileInputStream.read();
          if (i2 != -1)
          {
            localStringBuilder.append((char)i2);
            continue;
          }
          long l1;
          boolean bool1;
          localObject = finally;
        }
        catch (FileNotFoundException localFileNotFoundException)
        {
          r.b();
          o = 0L;
          l1 = o;
          bool1 = l1 < 0L;
          bool2 = false;
          if (!bool1)
          {
            return bool2;
            localFileInputStream.close();
            p = localStringBuilder.toString();
            continue;
          }
        }
        catch (IOException localIOException)
        {
          r.g();
          continue;
        }
        if (!ac.a(q)) {
          break label186;
        }
      }
      finally {}
      q = cn.jpush.android.c.a.u(paramContext);
      label186:
      if (ac.a(q))
      {
        r.b();
        bool2 = false;
      }
      else
      {
        bool2 = true;
      }
    }
  }
  
  public static void d(int paramInt)
  {
    R = paramInt;
  }
  
  public static void d(String paramString)
  {
    G = paramString;
  }
  
  private void d(String paramString1, String paramString2)
  {
    if ((ac.a(paramString1)) || (ac.a(paramString2))) {
      return;
    }
    for (;;)
    {
      String str1;
      try
      {
        Iterator localIterator = this.u.iterator();
        if (!localIterator.hasNext()) {
          break;
        }
        str1 = (String)localIterator.next();
        if (ac.a(str1)) {
          continue;
        }
        String[] arrayOfString = str1.split(bb[91]);
        if (arrayOfString.length > 2)
        {
          int i1 = Integer.valueOf(arrayOfString[0]).intValue();
          String str2 = arrayOfString[1];
          if ((!paramString1.equals(arrayOfString[2])) || (!paramString2.equals(str2))) {
            continue;
          }
          this.u.remove(str1);
          i(i1);
          continue;
        }
        new StringBuilder(bb[95]).append(str1).toString();
      }
      catch (Exception localException)
      {
        localException.getMessage();
        r.e();
        return;
      }
      r.e();
      this.u.remove(str1);
    }
  }
  
  public static void d(boolean paramBoolean)
  {
    T = paramBoolean;
  }
  
  private static String e(String paramString1, String paramString2)
  {
    try
    {
      JSONObject localJSONObject1 = new JSONObject(paramString1);
      JSONObject localJSONObject2 = new JSONObject(paramString2);
      if (localJSONObject2.has(bb[0])) {
        localJSONObject1.put(bb[0], localJSONObject2.get(bb[0]));
      }
      if (localJSONObject2.has(bb[1])) {
        localJSONObject1.put(bb[1], localJSONObject2.get(bb[1]));
      }
      String str = localJSONObject1.toString();
      return str;
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
    }
    return null;
  }
  
  private void f(String paramString1, String paramString2)
  {
    this.t.offer(bb[''] + paramString1 + "," + paramString2);
  }
  
  private void g(int paramInt)
  {
    new StringBuilder(bb['']).append(paramInt).append(bb['']).toString();
    r.b();
    this.ae.removeMessages(1005);
    this.ae.removeMessages(1004);
    this.ae.sendEmptyMessageDelayed(1004, paramInt);
  }
  
  private void h(int paramInt)
  {
    Message localMessage = new Message();
    localMessage.obj = Integer.valueOf(paramInt);
    localMessage.what = 1008;
    this.ae.sendMessageDelayed(localMessage, 10000L);
  }
  
  private void i(int paramInt)
  {
    this.ae.removeMessages(1008, Integer.valueOf(paramInt));
  }
  
  private void i(String paramString)
  {
    r.b();
    int i1 = 0;
    int i6;
    for (int i2 = 0; i1 < 2; i2 = i6)
    {
      i6 = (i2 << 8) + (0xFF & this.s[(i1 + 6)]);
      i1++;
    }
    String str1 = bb[29];
    Object[] arrayOfObject1 = new Object[1];
    arrayOfObject1[0] = Integer.valueOf(i2);
    String.format(str1, arrayOfObject1);
    r.b();
    long l1 = 0L;
    for (int i3 = 0; i3 < 4; i3++) {
      l1 = (l1 << 8) + (0xFF & this.s[(i3 + 8)]);
    }
    String str2 = bb[90];
    Object[] arrayOfObject2 = new Object[1];
    arrayOfObject2[0] = Long.valueOf(l1);
    String.format(str2, arrayOfObject2);
    r.b();
    byte[] arrayOfByte1 = new byte[100];
    for (int i4 = 0; (i4 < arrayOfByte1.length) && (this.s[(i4 + 12)] != 0); i4++) {
      arrayOfByte1[i4] = ((byte)(0xFF & this.s[(i4 + 12)]));
    }
    String str3 = new String(arrayOfByte1, 0, i4);
    new StringBuilder(bb[32]).append(str3).toString();
    r.b();
    byte[] arrayOfByte2 = new byte[30];
    for (int i5 = 0; (i5 < arrayOfByte2.length) && (this.s[(i5 + 112)] != 0); i5++) {
      arrayOfByte2[i5] = ((byte)(0xFF & this.s[(i5 + 112)]));
    }
    String str4 = new String(arrayOfByte2, 0, i5);
    new StringBuilder(bb[89]).append(str4).toString();
    r.b();
    if (i2 == 0)
    {
      Intent localIntent = new Intent(paramString);
      localIntent.putExtra(bb[72], str4);
      localIntent.addCategory(str3);
      sendBroadcast(localIntent, String.format(bb[71], new Object[] { str3 }));
    }
  }
  
  private void j(String paramString)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      int i1 = localJSONObject.optInt(bb['»'], cn.jpush.android.api.d.i);
      int i2 = localJSONObject.optInt(bb['¾']);
      if (i2 != 0)
      {
        b localb = ServiceInterface.a(i2);
        if (localb != null)
        {
          TagAliasCallback localTagAliasCallback = localb.c;
          new StringBuilder(bb['½']).append(i2).toString();
          r.b();
          if (localTagAliasCallback != null)
          {
            ServiceInterface.b(i2);
            k(i2);
            this.ae.removeMessages(1006, Integer.valueOf(i2));
            localTagAliasCallback.gotResult(i1, localb.a, localb.b);
            return;
          }
          new StringBuilder(bb['¼']).append(i2).toString();
          r.e();
          return;
        }
      }
    }
    catch (Exception localException) {}
  }
  
  private boolean j(int paramInt)
  {
    try
    {
      Iterator localIterator = this.u.iterator();
      while (localIterator.hasNext())
      {
        String str = (String)localIterator.next();
        if (!ac.a(str))
        {
          String[] arrayOfString = str.split(bb[91]);
          if (arrayOfString.length > 2)
          {
            int i1 = Integer.valueOf(arrayOfString[0]).intValue();
            if (paramInt == i1) {
              return true;
            }
          }
        }
      }
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
    }
    return false;
  }
  
  private void k(int paramInt)
  {
    for (;;)
    {
      try
      {
        Iterator localIterator = this.u.iterator();
        if (localIterator.hasNext())
        {
          str = (String)localIterator.next();
          String[] arrayOfString = str.split(bb[91]);
          if (arrayOfString.length < 2) {
            continue;
          }
          int i1 = Integer.valueOf(arrayOfString[0]).intValue();
          this.u.remove(str);
          i(i1);
          if (i1 != paramInt) {
            continue;
          }
        }
      }
      catch (Exception localException)
      {
        String str;
        localException.getMessage();
        r.e();
        continue;
      }
      finally {}
      return;
      new StringBuilder(bb[95]).append(str).toString();
      r.e();
      this.u.remove(str);
    }
  }
  
  private void k(String paramString)
  {
    
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString);
      z.a(getApplicationContext(), localJSONObject);
      if (z.a(this, bb['Á'], bb['À']).toLowerCase().equals(bb[46]))
      {
        r.b();
        if (this.r != 0) {
          PushProtocol.RepPush(this.r, o, (byte)3, bb['Â']);
        }
      }
      return;
    }
    catch (Exception localException)
    {
      r.g();
    }
  }
  
  private void l(String paramString)
  {
    
    JSONObject localJSONObject;
    int i1;
    HashMap localHashMap;
    for (;;)
    {
      int i5;
      String str;
      try
      {
        localJSONObject = new JSONObject(paramString);
        i1 = localJSONObject.optInt(bb[''], -1);
        if (i1 == -1) {
          return;
        }
        localHashMap = new HashMap();
        int i2 = localJSONObject.optInt(bb[''], -1);
        if (i2 != -1)
        {
          if (i2 == 0)
          {
            T = true;
            localHashMap.put(bb[''], Boolean.valueOf(true));
          }
        }
        else
        {
          int i3 = localJSONObject.optInt(bb[124], -1);
          new StringBuilder(bb['']).append(i3).toString();
          r.b();
          if (i3 != -1)
          {
            if (i3 != 0) {
              break label417;
            }
            localHashMap.put(bb[124], Boolean.valueOf(true));
          }
          int i4 = localJSONObject.optInt(bb[127], -1);
          if (i4 != -1)
          {
            if (i4 != 0) {
              break label436;
            }
            localHashMap.put(bb[127], Boolean.valueOf(true));
          }
          localHashMap.toString();
          r.b();
          if (i1 != 2) {
            break;
          }
          i5 = localJSONObject.optInt(bb[121], -1);
          str = bb[''];
          if (i5 != -1)
          {
            if (i5 != 0) {
              break label455;
            }
            str = bb[''];
          }
          Intent localIntent1 = new Intent(this, PushService.class);
          Bundle localBundle1 = new Bundle();
          localBundle1.putString(bb[121], str);
          if (localHashMap.get(bb[124]) != null) {
            localBundle1.putBoolean(bb[124], ((Boolean)localHashMap.get(bb[124])).booleanValue());
          }
          if (localHashMap.get(bb[127]) != null) {
            localBundle1.putBoolean(bb[127], ((Boolean)localHashMap.get(bb[127])).booleanValue());
          }
          localIntent1.putExtras(localBundle1);
          startService(localIntent1);
          return;
        }
        localHashMap.put(bb[''], Boolean.valueOf(false));
        continue;
        localHashMap.put(bb[124], Boolean.valueOf(false));
      }
      catch (JSONException localJSONException)
      {
        r.g();
        return;
      }
      label417:
      continue;
      label436:
      localHashMap.put(bb[127], Boolean.valueOf(false));
      continue;
      label455:
      if (i5 == 1) {
        str = bb[''];
      } else if (i5 == 2) {
        str = bb[''];
      } else if (i5 == 3) {
        str = bb[''];
      }
    }
    if (localHashMap.get(bb[127]) != null) {
      x = ((Boolean)localHashMap.get(bb[127])).booleanValue();
    }
    if (localHashMap.get(bb[124]) != null) {
      y = ((Boolean)localHashMap.get(bb[124])).booleanValue();
    }
    if (localHashMap.get(bb['']) != null) {
      T = ((Boolean)localHashMap.get(bb[''])).booleanValue();
    }
    int i6 = localJSONObject.optInt(bb[121], -1);
    if (i6 != -1)
    {
      if (i6 != 0) {
        break label718;
      }
      w = bb[''];
    }
    while (i1 == 0)
    {
      Intent localIntent2 = new Intent(this, PushService.class);
      Bundle localBundle2 = new Bundle();
      localBundle2.putString(bb[41], bb[41]);
      localIntent2.putExtras(localBundle2);
      startService(localIntent2);
      return;
      label718:
      if (i6 == 1) {
        w = bb[''];
      } else if (i6 == 2) {
        w = bb[''];
      } else if (i6 == 3) {
        w = bb[''];
      }
    }
  }
  
  private void m(String paramString)
  {
    int i1 = 0;
    try
    {
      r.b();
      int i2 = 0;
      int i4;
      for (int i3 = 0; i2 < 2; i3 = i4)
      {
        i4 = (i3 << 8) + (0xFF & this.s[(i2 + 6)]);
        i2++;
      }
      String str1 = bb[29];
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf(i3);
      String.format(str1, arrayOfObject1);
      r.b();
      byte[] arrayOfByte1 = new byte[8];
      for (int i5 = 0; i5 < arrayOfByte1.length; i5++) {
        arrayOfByte1[i5] = ((byte)(0xFF & this.s[(i5 + 8)]));
      }
      StringBuilder localStringBuilder = new StringBuilder(2 * arrayOfByte1.length);
      int i6 = arrayOfByte1.length;
      for (int i7 = 0; i7 < i6; i7++)
      {
        int i8 = arrayOfByte1[i7];
        String str2 = bb[28];
        Object[] arrayOfObject2 = new Object[1];
        arrayOfObject2[0] = Integer.valueOf(i8 & 0xFF);
        localStringBuilder.append(String.format(str2, arrayOfObject2));
      }
      String str3 = localStringBuilder.toString();
      new StringBuilder(bb[31]).append(str3).toString();
      r.b();
      int i9 = 0;
      int i10 = 0;
      while (i9 < 2)
      {
        i10 = (i10 << 8) + (0xFF & this.s[(i9 + 16)]);
        i9++;
      }
      new StringBuilder(bb[30]).append(i10).toString();
      r.b();
      byte[] arrayOfByte2 = new byte[100];
      while ((i1 < arrayOfByte2.length) && (this.s[(i1 + 18)] != 0))
      {
        arrayOfByte2[i1] = ((byte)(0xFF & this.s[(i1 + 18)]));
        i1++;
      }
      String str4 = new String(arrayOfByte2, 0, i1);
      new StringBuilder(bb[32]).append(str4).toString();
      r.b();
      if (i3 == 0)
      {
        a(str4, null, str3, paramString);
        return;
      }
      String str5 = bb[33];
      Object[] arrayOfObject3 = new Object[1];
      arrayOfObject3[0] = Integer.valueOf(i3);
      String.format(str5, arrayOfObject3);
      r.c();
      return;
    }
    catch (Exception localException)
    {
      r.i();
    }
  }
  
  private void n(String paramString)
  {
    int i1 = 0;
    try
    {
      r.b();
      int i2 = 0;
      int i4;
      for (int i3 = 0; i2 < 2; i3 = i4)
      {
        i4 = (i3 << 8) + (0xFF & this.s[(i2 + 6)]);
        i2++;
      }
      String str1 = bb[29];
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = Integer.valueOf(i3);
      String.format(str1, arrayOfObject1);
      r.b();
      long l1 = 0L;
      for (int i5 = 0; i5 < 4; i5++) {
        l1 = (l1 << 8) + (0xFF & this.s[(i5 + 8)]);
      }
      String str2 = bb[90];
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = Long.valueOf(l1);
      String.format(str2, arrayOfObject2);
      r.b();
      byte[] arrayOfByte1 = new byte[8];
      for (int i6 = 0; i6 < arrayOfByte1.length; i6++) {
        arrayOfByte1[i6] = ((byte)(0xFF & this.s[(i6 + 12)]));
      }
      StringBuilder localStringBuilder = new StringBuilder(2 * arrayOfByte1.length);
      int i7 = arrayOfByte1.length;
      for (int i8 = 0; i8 < i7; i8++)
      {
        int i9 = arrayOfByte1[i8];
        String str3 = bb[28];
        Object[] arrayOfObject3 = new Object[1];
        arrayOfObject3[0] = Integer.valueOf(i9 & 0xFF);
        localStringBuilder.append(String.format(str3, arrayOfObject3));
      }
      String str4 = localStringBuilder.toString();
      new StringBuilder(bb[31]).append(str4).toString();
      r.b();
      byte[] arrayOfByte2 = new byte[100];
      for (int i10 = 0; (i10 < arrayOfByte2.length) && (this.s[(i10 + 20)] != 0); i10++) {
        arrayOfByte2[i10] = ((byte)(0xFF & this.s[(i10 + 20)]));
      }
      String str5 = new String(arrayOfByte2, 0, i10);
      new StringBuilder(bb[32]).append(str5).toString();
      r.b();
      byte[] arrayOfByte3 = new byte[30];
      while ((i1 < arrayOfByte3.length) && (this.s[(i1 + 120)] != 0))
      {
        arrayOfByte3[i1] = ((byte)(0xFF & this.s[(i1 + 120)]));
        i1++;
      }
      String str6 = new String(arrayOfByte3, 0, i1);
      new StringBuilder(bb[89]).append(str6).toString();
      r.b();
      if (i3 == 0)
      {
        a(str5, str6, str4, paramString);
        return;
      }
      String str7 = bb[33];
      Object[] arrayOfObject4 = new Object[1];
      arrayOfObject4[0] = Integer.valueOf(i3);
      String.format(str7, arrayOfObject4);
      r.c();
      return;
    }
    catch (Exception localException)
    {
      r.i();
    }
  }
  
  private void o(String paramString)
  {
    
    int i5;
    label355:
    for (;;)
    {
      try
      {
        JSONObject localJSONObject = new JSONObject(paramString);
        int i1 = localJSONObject.optInt(bb[41], -1);
        if (i1 != -1)
        {
          new StringBuilder(bb[42]).append(Integer.toString(i1)).toString();
          r.b();
          h = i1 * 60;
          z.b(this, bb[40], h);
        }
        int i2 = localJSONObject.optInt(bb[39], -1);
        if (i2 != -1)
        {
          new StringBuilder(bb[38]).append(Integer.toString(i2)).toString();
          r.b();
          if (i2 == 0)
          {
            m = false;
            z.b(this, bb[43], bb[47]);
          }
        }
        else
        {
          int i3 = localJSONObject.optInt(bb[35], -1);
          if (i3 != -1)
          {
            new StringBuilder(bb[37]).append(Integer.toString(i3)).toString();
            r.b();
            if (i3 != 0) {
              break label355;
            }
            n = false;
            z.b(this, bb[35], i3);
          }
          int i4 = localJSONObject.optInt(bb[36], -1);
          if (i4 != -1)
          {
            new StringBuilder(bb[45]).append(Integer.toString(i4)).toString();
            r.b();
            z.b(this, bb[36], i4);
          }
          i5 = localJSONObject.optInt(bb[48], -1);
          if (i5 == -1) {
            return;
          }
          if (i5 != 0) {
            break;
          }
          z.b(this, bb[44], bb[47]);
          r.b();
          stopSelf();
          return;
        }
        m = true;
        z.b(this, bb[43], bb[46]);
        continue;
        n = true;
      }
      catch (JSONException localJSONException)
      {
        r.g();
        return;
      }
    }
    if (i5 == 1)
    {
      r.b();
      stopSelf();
      return;
    }
    if (i5 == 2) {
      ServiceInterface.f(getApplicationContext());
    }
  }
  
  private void p()
  {
    new StringBuilder(bb['¡']).append(R).append("s").toString();
    r.b();
    this.ae.removeMessages(1001);
    this.ae.sendEmptyMessageDelayed(1001, 1000 * R);
  }
  
  private byte[] q()
  {
    String str1 = cn.jpush.android.c.a.d(this);
    String str2 = ((TelephonyManager)getSystemService(bb[64])).getNetworkOperator();
    String str3 = bb[''] + str1;
    try
    {
      int i3 = Integer.valueOf(str2).intValue();
      i1 = i3;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        byte[] arrayOfByte1;
        byte[] arrayOfByte2;
        boolean bool;
        int i2;
        int i1 = 0;
      }
    }
    arrayOfByte1 = new byte[''];
    arrayOfByte2 = new byte[] { 0, 80 };
    System.arraycopy(arrayOfByte2, 0, arrayOfByte1, 0, arrayOfByte2.length);
    u.a(arrayOfByte1, str3, 2);
    u.d(arrayOfByte1, i1, 34);
    u.d(arrayOfByte1, Integer.parseInt(o), 38);
    if (J.length() > 50) {
      J = J.substring(0, 49);
    }
    u.a(arrayOfByte1, J, 42);
    u.a(arrayOfByte1, bb[61], 92);
    bool = c;
    i2 = 0;
    if (bool) {
      i2 = 1;
    }
    u.d(arrayOfByte1, i2, 102);
    return arrayOfByte1;
  }
  
  /* Error */
  private void r()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   5: aload_0
    //   6: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   9: bipush 69
    //   11: aaload
    //   12: invokevirtual 1259	cn/jpush/android/service/PushService:deleteFile	(Ljava/lang/String;)Z
    //   15: pop
    //   16: iconst_0
    //   17: putstatic 563	cn/jpush/android/service/PushService:P	Z
    //   20: lconst_0
    //   21: putstatic 555	cn/jpush/android/service/PushService:o	J
    //   24: aload_0
    //   25: monitorexit
    //   26: return
    //   27: astore_1
    //   28: aload_0
    //   29: monitorexit
    //   30: aload_1
    //   31: athrow
    //   32: astore_2
    //   33: goto -9 -> 24
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	36	0	this	PushService
    //   27	4	1	localObject	Object
    //   32	1	2	localException	Exception
    // Exception table:
    //   from	to	target	type
    //   2	5	27	finally
    //   5	24	27	finally
    //   5	24	32	java/lang/Exception
  }
  
  private void s()
  {
    r.b();
    z.b(getApplicationContext(), bb[40], 86401);
    h = 86401;
    stopSelf();
  }
  
  private String t()
  {
    try
    {
      Object localObject = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
      if (((String)localObject).length() > 30)
      {
        r.e(bb[4], bb['Ä']);
        String str = ((String)localObject).substring(0, 30);
        localObject = str;
      }
      return (String)localObject;
    }
    catch (Exception localException) {}
    return bb['Ã'];
  }
  
  private void u()
  {
    int i1 = 0;
    if (this.s.length < 17)
    {
      r.e();
      return;
    }
    int i2 = cn.jpush.android.c.a.a(this.s[6]);
    for (int i3 = 0; i3 < 8; i3++) {}
    if (i2 == 2)
    {
      r.b();
      B();
      return;
    }
    if (i2 == 10)
    {
      for (int i4 = 0; i4 < 2; i4++) {
        i1 = (i1 << 8) + (0xFF & this.s[(i4 + 4)]);
      }
      new StringBuilder(bb['']).append(i1).toString();
      r.b();
      i(i1);
      k(i1);
      return;
    }
    new StringBuilder(bb[8]).append(i2).toString();
    r.d();
  }
  
  private void v()
  {
    try
    {
      r.b();
      if (this.r != 0) {
        PushProtocol.Stop(this.r);
      }
      return;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  /* Error */
  private void w()
  {
    // Byte code:
    //   0: aload_0
    //   1: monitorenter
    //   2: aload_0
    //   3: getfield 640	cn/jpush/android/service/PushService:ae	Landroid/os/Handler;
    //   6: sipush 1008
    //   9: invokevirtual 654	android/os/Handler:removeMessages	(I)V
    //   12: aload_0
    //   13: getfield 629	cn/jpush/android/service/PushService:u	Ljava/util/Queue;
    //   16: invokeinterface 893 1 0
    //   21: astore 4
    //   23: aload 4
    //   25: invokeinterface 898 1 0
    //   30: ifeq +128 -> 158
    //   33: aload 4
    //   35: invokeinterface 902 1 0
    //   40: checkcast 77	java/lang/String
    //   43: astore 5
    //   45: new 585	java/lang/StringBuilder
    //   48: dup
    //   49: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   52: sipush 149
    //   55: aaload
    //   56: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   59: aload 5
    //   61: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   67: pop
    //   68: invokestatic 717	cn/jpush/android/c/r:e	()V
    //   71: aload 5
    //   73: invokestatic 917	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   76: ifne -53 -> 23
    //   79: aload 5
    //   81: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   84: bipush 91
    //   86: aaload
    //   87: invokevirtual 910	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   90: astore 7
    //   92: aload 7
    //   94: arraylength
    //   95: iconst_2
    //   96: if_icmple +65 -> 161
    //   99: aload 7
    //   101: iconst_0
    //   102: aaload
    //   103: invokestatic 923	java/lang/Integer:valueOf	(Ljava/lang/String;)Ljava/lang/Integer;
    //   106: invokevirtual 926	java/lang/Integer:intValue	()I
    //   109: istore 10
    //   111: aload 7
    //   113: iconst_1
    //   114: aaload
    //   115: astore 11
    //   117: aload 7
    //   119: iconst_2
    //   120: aaload
    //   121: astore 12
    //   123: aload_0
    //   124: getfield 620	cn/jpush/android/service/PushService:r	I
    //   127: getstatic 555	cn/jpush/android/service/PushService:o	J
    //   130: aload 11
    //   132: aload 12
    //   134: iload 10
    //   136: invokestatic 875	cn/jpush/android/service/PushService:a	(IJLjava/lang/String;Ljava/lang/String;I)I
    //   139: pop
    //   140: aload_0
    //   141: iload 10
    //   143: invokespecial 877	cn/jpush/android/service/PushService:h	(I)V
    //   146: goto -123 -> 23
    //   149: astore_2
    //   150: aload_2
    //   151: invokevirtual 1128	java/lang/Exception:getMessage	()Ljava/lang/String;
    //   154: pop
    //   155: invokestatic 717	cn/jpush/android/c/r:e	()V
    //   158: aload_0
    //   159: monitorexit
    //   160: return
    //   161: new 585	java/lang/StringBuilder
    //   164: dup
    //   165: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   168: bipush 95
    //   170: aaload
    //   171: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   174: aload 5
    //   176: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   179: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   182: pop
    //   183: invokestatic 717	cn/jpush/android/c/r:e	()V
    //   186: aload_0
    //   187: getfield 629	cn/jpush/android/service/PushService:u	Ljava/util/Queue;
    //   190: aload 5
    //   192: invokeinterface 920 2 0
    //   197: pop
    //   198: goto -175 -> 23
    //   201: astore_1
    //   202: aload_0
    //   203: monitorexit
    //   204: aload_1
    //   205: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	206	0	this	PushService
    //   201	4	1	localObject	Object
    //   149	2	2	localException	Exception
    //   21	13	4	localIterator	Iterator
    //   43	148	5	str1	String
    //   90	28	7	arrayOfString	String[]
    //   109	33	10	i1	int
    //   115	16	11	str2	String
    //   121	12	12	str3	String
    // Exception table:
    //   from	to	target	type
    //   12	23	149	java/lang/Exception
    //   23	146	149	java/lang/Exception
    //   161	198	149	java/lang/Exception
    //   2	12	201	finally
    //   12	23	201	finally
    //   23	146	201	finally
    //   150	158	201	finally
    //   161	198	201	finally
  }
  
  private void x()
  {
    r.b();
    B();
    if (this.K != null)
    {
      if (!this.K.isAlive()) {}
      for (;;)
      {
        try
        {
          this.K.join();
          this.K = new j(this);
          this.K.start();
          return;
        }
        catch (Exception localException3)
        {
          r.g();
          return;
        }
        new StringBuilder(bb[34]).append(this.K.getId()).toString();
        r.b();
        try
        {
          Thread.sleep(600L);
          if (!this.K.a)
          {
            r.b();
            this.K = new j(this);
            this.K.start();
            return;
          }
        }
        catch (Exception localException2)
        {
          r.g();
          return;
        }
      }
    }
    try
    {
      this.K = new j(this);
      this.K.start();
      return;
    }
    catch (Exception localException1)
    {
      r.g();
    }
  }
  
  private void y()
  {
    
    for (;;)
    {
      String str = (String)this.t.poll();
      if (str == null) {
        break;
      }
      n.a(getApplicationContext(), str);
    }
  }
  
  private void z()
  {
    new StringBuilder(bb['']).append(h).toString();
    r.b();
    int i1 = h;
    boolean bool = B;
    B = bool;
    if (bool)
    {
      r.b();
      PendingIntent localPendingIntent = PendingIntent.getBroadcast(this, 0, new Intent(this, AlarmReceiver.class), 0);
      ((AlarmManager)getSystemService(bb[''])).set(0, System.currentTimeMillis() + i1 * 1000, localPendingIntent);
      String str = bb[''];
      Object[] arrayOfObject = new Object[1];
      arrayOfObject[0] = Integer.valueOf(i1);
      String.format(str, arrayOfObject);
      r.c();
    }
  }
  
  /* Error */
  public final void c()
  {
    // Byte code:
    //   0: invokestatic 783	java/lang/System:currentTimeMillis	()J
    //   3: aload_0
    //   4: getfield 690	cn/jpush/android/service/PushService:Y	J
    //   7: lsub
    //   8: invokestatic 791	java/lang/Math:abs	(J)J
    //   11: ldc2_w 1313
    //   14: lcmp
    //   15: ifge +7 -> 22
    //   18: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   21: return
    //   22: new 1316	java/net/DatagramSocket
    //   25: dup
    //   26: invokespecial 1317	java/net/DatagramSocket:<init>	()V
    //   29: astore_1
    //   30: sipush 1024
    //   33: newarray 慢⁤污潬慣楴湯
    //   36: iconst_3
    //   37: getstatic 583	cn/jpush/android/service/PushService:U	Ljava/util/List;
    //   40: getstatic 606	cn/jpush/android/service/PushService:z	I
    //   43: invokeinterface 1320 2 0
    //   48: checkcast 77	java/lang/String
    //   51: astore 7
    //   53: aload 7
    //   55: ifnull +66 -> 121
    //   58: aload 7
    //   60: ldc_w 592
    //   63: invokevirtual 1323	java/lang/String:indexOf	(Ljava/lang/String;)I
    //   66: ifle +55 -> 121
    //   69: new 585	java/lang/StringBuilder
    //   72: dup
    //   73: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   76: bipush 86
    //   78: aaload
    //   79: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   82: aload 7
    //   84: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   87: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   90: pop
    //   91: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   94: aload 7
    //   96: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   99: bipush 87
    //   101: aaload
    //   102: invokevirtual 910	java/lang/String:split	(Ljava/lang/String;)[Ljava/lang/String;
    //   105: astore 36
    //   107: aload 36
    //   109: iconst_0
    //   110: aaload
    //   111: putstatic 537	cn/jpush/android/service/PushService:F	Ljava/lang/String;
    //   114: aload 36
    //   116: iconst_1
    //   117: aaload
    //   118: putstatic 541	cn/jpush/android/service/PushService:G	Ljava/lang/String;
    //   121: getstatic 537	cn/jpush/android/service/PushService:F	Ljava/lang/String;
    //   124: invokestatic 1329	java/net/InetAddress:getAllByName	(Ljava/lang/String;)[Ljava/net/InetAddress;
    //   127: iconst_0
    //   128: aaload
    //   129: astore 34
    //   131: aload 34
    //   133: astore 11
    //   135: aload_0
    //   136: invokespecial 1331	cn/jpush/android/service/PushService:q	()[B
    //   139: astore 12
    //   141: aload 12
    //   143: arraylength
    //   144: istore 13
    //   146: iload 13
    //   148: sipush 256
    //   151: if_icmple +741 -> 892
    //   154: sipush 256
    //   157: istore 14
    //   159: getstatic 543	cn/jpush/android/service/PushService:H	I
    //   162: bipush 80
    //   164: if_icmpne +297 -> 461
    //   167: new 585	java/lang/StringBuilder
    //   170: dup
    //   171: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   174: bipush 84
    //   176: aaload
    //   177: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   180: getstatic 543	cn/jpush/android/service/PushService:H	I
    //   183: invokevirtual 699	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   186: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   189: pop
    //   190: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   193: new 1333	java/net/DatagramPacket
    //   196: dup
    //   197: aload 12
    //   199: iload 14
    //   201: aload 11
    //   203: getstatic 543	cn/jpush/android/service/PushService:H	I
    //   206: invokespecial 1336	java/net/DatagramPacket:<init>	([BILjava/net/InetAddress;I)V
    //   209: astore 16
    //   211: aload_1
    //   212: sipush 3000
    //   215: invokevirtual 1339	java/net/DatagramSocket:setSoTimeout	(I)V
    //   218: aload_1
    //   219: aload 16
    //   221: invokevirtual 1343	java/net/DatagramSocket:send	(Ljava/net/DatagramPacket;)V
    //   224: new 1333	java/net/DatagramPacket
    //   227: dup
    //   228: aload 6
    //   230: aload 6
    //   232: arraylength
    //   233: invokespecial 1346	java/net/DatagramPacket:<init>	([BI)V
    //   236: astore 17
    //   238: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   241: aload_1
    //   242: aload 17
    //   244: invokevirtual 1349	java/net/DatagramSocket:receive	(Ljava/net/DatagramPacket;)V
    //   247: aload 17
    //   249: invokevirtual 1352	java/net/DatagramPacket:getLength	()I
    //   252: newarray 慢⁤污潬慣楴湯
    //   255: ldc 25
    //   257: sipush -18939
    //   260: astore_0
    //   261: iconst_0
    //   262: aload 18
    //   264: iconst_0
    //   265: aload 18
    //   267: arraylength
    //   268: invokestatic 1241	java/lang/System:arraycopy	(Ljava/lang/Object;ILjava/lang/Object;II)V
    //   271: new 77	java/lang/String
    //   274: dup
    //   275: aload 18
    //   277: invokespecial 1027	java/lang/String:<init>	([B)V
    //   280: astore 19
    //   282: new 585	java/lang/StringBuilder
    //   285: dup
    //   286: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   289: bipush 88
    //   291: aaload
    //   292: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   295: aload 19
    //   297: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   300: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   303: pop
    //   304: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   307: aconst_null
    //   308: putstatic 531	cn/jpush/android/service/PushService:D	Ljava/lang/String;
    //   311: new 668	org/json/JSONObject
    //   314: dup
    //   315: aload 19
    //   317: invokespecial 669	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   320: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   323: bipush 78
    //   325: aaload
    //   326: invokevirtual 1359	org/json/JSONObject:getJSONArray	(Ljava/lang/String;)Lorg/json/JSONArray;
    //   329: astore 21
    //   331: aload 21
    //   333: ifnull +15 -> 348
    //   336: aload 21
    //   338: invokevirtual 1362	org/json/JSONArray:length	()I
    //   341: istore 22
    //   343: iload 22
    //   345: ifne +182 -> 527
    //   348: aload_1
    //   349: ifnull -328 -> 21
    //   352: aload_1
    //   353: invokevirtual 1363	java/net/DatagramSocket:close	()V
    //   356: return
    //   357: astore 8
    //   359: getstatic 541	cn/jpush/android/service/PushService:G	Ljava/lang/String;
    //   362: invokestatic 1367	java/net/InetAddress:getByName	(Ljava/lang/String;)Ljava/net/InetAddress;
    //   365: astore 9
    //   367: new 585	java/lang/StringBuilder
    //   370: dup
    //   371: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   374: bipush 81
    //   376: aaload
    //   377: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   380: getstatic 537	cn/jpush/android/service/PushService:F	Ljava/lang/String;
    //   383: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   386: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   389: pop
    //   390: aload 9
    //   392: astore 11
    //   394: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   397: goto -262 -> 135
    //   400: astore_3
    //   401: aload_1
    //   402: astore 4
    //   404: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   407: getstatic 543	cn/jpush/android/service/PushService:H	I
    //   410: bipush 80
    //   412: if_icmpeq +434 -> 846
    //   415: bipush 80
    //   417: putstatic 543	cn/jpush/android/service/PushService:H	I
    //   420: aload_0
    //   421: invokevirtual 958	cn/jpush/android/service/PushService:c	()V
    //   424: iconst_1
    //   425: getstatic 606	cn/jpush/android/service/PushService:z	I
    //   428: iadd
    //   429: iconst_3
    //   430: irem
    //   431: putstatic 606	cn/jpush/android/service/PushService:z	I
    //   434: aload_0
    //   435: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   438: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   441: bipush 79
    //   443: aaload
    //   444: getstatic 606	cn/jpush/android/service/PushService:z	I
    //   447: invokestatic 1024	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;I)V
    //   450: aload 4
    //   452: ifnull -431 -> 21
    //   455: aload 4
    //   457: invokevirtual 1363	java/net/DatagramSocket:close	()V
    //   460: return
    //   461: new 585	java/lang/StringBuilder
    //   464: dup
    //   465: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   468: bipush 80
    //   470: aaload
    //   471: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   474: sipush 10000
    //   477: getstatic 543	cn/jpush/android/service/PushService:H	I
    //   480: iadd
    //   481: invokevirtual 699	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   484: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   487: pop
    //   488: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   491: new 1333	java/net/DatagramPacket
    //   494: dup
    //   495: aload 12
    //   497: iload 14
    //   499: aload 11
    //   501: sipush 10000
    //   504: getstatic 543	cn/jpush/android/service/PushService:H	I
    //   507: iadd
    //   508: invokespecial 1336	java/net/DatagramPacket:<init>	([BILjava/net/InetAddress;I)V
    //   511: astore 16
    //   513: goto -302 -> 211
    //   516: astore_2
    //   517: aload_1
    //   518: ifnull +7 -> 525
    //   521: aload_1
    //   522: invokevirtual 1363	java/net/DatagramSocket:close	()V
    //   525: aload_2
    //   526: athrow
    //   527: aload 21
    //   529: invokevirtual 1362	org/json/JSONArray:length	()I
    //   532: ifle +31 -> 563
    //   535: aload 21
    //   537: iconst_0
    //   538: invokevirtual 1370	org/json/JSONArray:optString	(I)Ljava/lang/String;
    //   541: astore 31
    //   543: aload 31
    //   545: bipush 58
    //   547: invokevirtual 1372	java/lang/String:indexOf	(I)I
    //   550: istore 32
    //   552: iload 32
    //   554: iconst_m1
    //   555: if_icmpne +248 -> 803
    //   558: aload 31
    //   560: putstatic 527	cn/jpush/android/service/PushService:C	Ljava/lang/String;
    //   563: aload 21
    //   565: invokevirtual 1362	org/json/JSONArray:length	()I
    //   568: iconst_2
    //   569: if_icmplt +224 -> 793
    //   572: aload 21
    //   574: iconst_1
    //   575: invokevirtual 1370	org/json/JSONArray:optString	(I)Ljava/lang/String;
    //   578: astore 23
    //   580: aload 23
    //   582: invokestatic 917	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   585: ifne +151 -> 736
    //   588: aload 23
    //   590: bipush 58
    //   592: invokevirtual 1372	java/lang/String:indexOf	(I)I
    //   595: istore 26
    //   597: iload 26
    //   599: ifle +137 -> 736
    //   602: aload 23
    //   604: iconst_0
    //   605: iload 26
    //   607: invokevirtual 1256	java/lang/String:substring	(II)Ljava/lang/String;
    //   610: astore 27
    //   612: getstatic 521	cn/jpush/android/service/PushService:k	Ljava/lang/String;
    //   615: aload 27
    //   617: invokevirtual 1123	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   620: ifne +48 -> 668
    //   623: aload 27
    //   625: putstatic 521	cn/jpush/android/service/PushService:k	Ljava/lang/String;
    //   628: new 585	java/lang/StringBuilder
    //   631: dup
    //   632: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   635: bipush 83
    //   637: aaload
    //   638: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   641: aload 27
    //   643: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   646: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   649: pop
    //   650: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   653: aload_0
    //   654: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   657: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   660: bipush 77
    //   662: aaload
    //   663: aload 27
    //   665: invokestatic 1059	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   668: aload 23
    //   670: iload 26
    //   672: iconst_1
    //   673: iadd
    //   674: invokevirtual 1374	java/lang/String:substring	(I)Ljava/lang/String;
    //   677: invokestatic 1252	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   680: istore 28
    //   682: getstatic 523	cn/jpush/android/service/PushService:l	I
    //   685: iload 28
    //   687: if_icmpeq +49 -> 736
    //   690: iload 28
    //   692: putstatic 523	cn/jpush/android/service/PushService:l	I
    //   695: new 585	java/lang/StringBuilder
    //   698: dup
    //   699: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   702: bipush 75
    //   704: aaload
    //   705: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   708: iload 28
    //   710: invokevirtual 699	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   713: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   716: pop
    //   717: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   720: aload_0
    //   721: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   724: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   727: bipush 76
    //   729: aaload
    //   730: getstatic 523	cn/jpush/android/service/PushService:l	I
    //   733: invokestatic 1024	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;I)V
    //   736: aload 21
    //   738: invokevirtual 1362	org/json/JSONArray:length	()I
    //   741: iconst_3
    //   742: if_icmplt +51 -> 793
    //   745: aload 21
    //   747: iconst_2
    //   748: invokevirtual 1370	org/json/JSONArray:optString	(I)Ljava/lang/String;
    //   751: astore 24
    //   753: aload 24
    //   755: invokestatic 917	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   758: ifne +35 -> 793
    //   761: invokestatic 1378	cn/jpush/android/c/w:a	()Ljava/lang/String;
    //   764: aload 24
    //   766: invokevirtual 1381	java/lang/String:contains	(Ljava/lang/CharSequence;)Z
    //   769: ifne +24 -> 793
    //   772: aload 24
    //   774: invokestatic 1383	cn/jpush/android/c/w:a	(Ljava/lang/String;)Ljava/lang/String;
    //   777: pop
    //   778: aload_0
    //   779: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   782: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   785: bipush 85
    //   787: aaload
    //   788: aload 24
    //   790: invokestatic 1059	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   793: aload_0
    //   794: invokestatic 783	java/lang/System:currentTimeMillis	()J
    //   797: putfield 690	cn/jpush/android/service/PushService:Y	J
    //   800: goto -452 -> 348
    //   803: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   806: iconst_4
    //   807: aaload
    //   808: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   811: bipush 82
    //   813: aaload
    //   814: invokestatic 1385	cn/jpush/android/c/r:b	(Ljava/lang/String;Ljava/lang/String;)V
    //   817: aload 31
    //   819: iconst_0
    //   820: iload 32
    //   822: invokevirtual 1256	java/lang/String:substring	(II)Ljava/lang/String;
    //   825: putstatic 527	cn/jpush/android/service/PushService:C	Ljava/lang/String;
    //   828: aload 31
    //   830: iload 32
    //   832: iconst_1
    //   833: iadd
    //   834: invokevirtual 1374	java/lang/String:substring	(I)Ljava/lang/String;
    //   837: invokestatic 1252	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   840: putstatic 533	cn/jpush/android/service/PushService:E	I
    //   843: goto -280 -> 563
    //   846: sipush 9000
    //   849: putstatic 543	cn/jpush/android/service/PushService:H	I
    //   852: aload 4
    //   854: ifnull -833 -> 21
    //   857: aload 4
    //   859: invokevirtual 1363	java/net/DatagramSocket:close	()V
    //   862: return
    //   863: astore 38
    //   865: aload 38
    //   867: astore_2
    //   868: aconst_null
    //   869: astore_1
    //   870: goto -353 -> 517
    //   873: astore 5
    //   875: aload 4
    //   877: astore_1
    //   878: aload 5
    //   880: astore_2
    //   881: goto -364 -> 517
    //   884: astore 37
    //   886: aconst_null
    //   887: astore 4
    //   889: goto -485 -> 404
    //   892: iload 13
    //   894: istore 14
    //   896: goto -737 -> 159
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	899	0	this	PushService
    //   29	849	1	localObject1	Object
    //   516	10	2	localObject2	Object
    //   867	14	2	localObject3	Object
    //   400	1	3	localException1	Exception
    //   402	486	4	localObject4	Object
    //   873	6	5	localObject5	Object
    //   35	196	6	arrayOfByte1	byte[]
    //   51	44	7	str1	String
    //   357	1	8	localUnknownHostException	java.net.UnknownHostException
    //   365	26	9	localInetAddress1	java.net.InetAddress
    //   133	367	11	localObject6	Object
    //   139	357	12	arrayOfByte2	byte[]
    //   144	749	13	i1	int
    //   157	738	14	i2	int
    //   209	303	16	localDatagramPacket1	java.net.DatagramPacket
    //   236	21	17	localDatagramPacket2	java.net.DatagramPacket
    //   254	22	18	arrayOfByte3	byte[]
    //   280	36	19	str2	String
    //   329	417	21	localJSONArray	org.json.JSONArray
    //   341	3	22	i3	int
    //   578	91	23	str3	String
    //   751	38	24	str4	String
    //   595	79	26	i4	int
    //   610	54	27	str5	String
    //   680	29	28	i5	int
    //   541	288	31	str6	String
    //   550	284	32	i6	int
    //   129	3	34	localInetAddress2	java.net.InetAddress
    //   105	10	36	arrayOfString	String[]
    //   884	1	37	localException2	Exception
    //   863	3	38	localObject7	Object
    // Exception table:
    //   from	to	target	type
    //   121	131	357	java/net/UnknownHostException
    //   30	53	400	java/lang/Exception
    //   58	121	400	java/lang/Exception
    //   121	131	400	java/lang/Exception
    //   135	146	400	java/lang/Exception
    //   159	211	400	java/lang/Exception
    //   211	331	400	java/lang/Exception
    //   336	343	400	java/lang/Exception
    //   359	390	400	java/lang/Exception
    //   394	397	400	java/lang/Exception
    //   461	513	400	java/lang/Exception
    //   527	552	400	java/lang/Exception
    //   558	563	400	java/lang/Exception
    //   563	597	400	java/lang/Exception
    //   602	668	400	java/lang/Exception
    //   668	736	400	java/lang/Exception
    //   736	793	400	java/lang/Exception
    //   793	800	400	java/lang/Exception
    //   803	843	400	java/lang/Exception
    //   30	53	516	finally
    //   58	121	516	finally
    //   121	131	516	finally
    //   135	146	516	finally
    //   159	211	516	finally
    //   211	331	516	finally
    //   336	343	516	finally
    //   359	390	516	finally
    //   394	397	516	finally
    //   461	513	516	finally
    //   527	552	516	finally
    //   558	563	516	finally
    //   563	597	516	finally
    //   602	668	516	finally
    //   668	736	516	finally
    //   736	793	516	finally
    //   793	800	516	finally
    //   803	843	516	finally
    //   22	30	863	finally
    //   404	450	873	finally
    //   846	852	873	finally
    //   22	30	884	java/lang/Exception
  }
  
  protected final void d()
  {
    a(false, false);
  }
  
  protected final void e()
  {
    a(false, true);
  }
  
  protected final void e(int paramInt)
  {
    if (this.r == 0) {}
    int i1;
    label60:
    label496:
    label1270:
    do
    {
      int i3;
      int i4;
      String str4;
      Object localObject1;
      Object localObject2;
      do
      {
        return;
        i1 = cn.jpush.android.c.a.a(this.s);
        new StringBuilder(bb[6]).append(i1).toString();
        r.c();
        if ((i1 != 3) && (i1 != 9)) {
          break;
        }
        int i2;
        String str5;
        String str6;
        int i12;
        int i14;
        int i15;
        if (i1 == 9)
        {
          i2 = 1;
          new StringBuilder(bb[9]).append(paramInt).toString();
          r.b();
          i3 = u.b(this.s, 10, 1);
          i4 = u.b(this.s, 11, 4);
          new StringBuilder(bb[7]).append(i3).append(bb[18]).append(i4).toString();
          r.b();
          if (i2 == 0) {
            break label564;
          }
          int i7 = u.b(this.s, 15, 2);
          str5 = u.c(this.s, 17, i7);
          int i8 = i7 + 17;
          int i9 = u.b(this.s, i8, 2);
          int i10 = i8 + 2;
          str6 = u.c(this.s, i10, i9);
          int i11 = i10 + i9;
          i12 = u.b(this.s, i11, 1);
          new StringBuilder(bb[21]).append(i12).toString();
          r.c();
          int i13 = i11 + 1;
          i14 = u.b(this.s, i13, 2);
          i15 = i13 + 2;
          if (i12 != 1) {
            break label496;
          }
          str4 = u.a(this.s, i15, i14);
          localObject1 = str6;
          localObject2 = str5;
        }
        for (;;)
        {
          new StringBuilder(bb[25]).append((String)localObject2).append(bb[24]).append((String)localObject1).append(bb[23]).append(str4).toString();
          r.b();
          switch (i3)
          {
          case 1: 
          case 7: 
          case 8: 
          case 10: 
          case 11: 
          case 12: 
          case 13: 
          case 16: 
          case 17: 
          case 18: 
          case 19: 
          default: 
            new StringBuilder(bb[13]).append(i3).toString();
            r.b();
            return;
            i2 = 0;
            break label60;
            if (i12 == 0)
            {
              str4 = u.c(this.s, i15, i14);
              localObject1 = str6;
              localObject2 = str5;
            }
            else
            {
              new StringBuilder(bb[15]).append(i12).toString();
              r.e();
              localObject1 = str6;
              localObject2 = str5;
              str4 = null;
              continue;
              int i5 = u.b(this.s, 15, 2);
              String str1 = u.c(this.s, 17, i5);
              LineNumberReader localLineNumberReader = new LineNumberReader(new StringReader(str1));
              String str2;
              try
              {
                str2 = localLineNumberReader.readLine();
                if (str2 == null)
                {
                  r.e();
                  return;
                }
              }
              catch (IOException localIOException)
              {
                r.i();
                return;
              }
              String str3 = localLineNumberReader.readLine();
              if (str3 == null)
              {
                r.e();
                return;
              }
              int i6 = 2 + (str2.length() + str3.length());
              if (str1.length() > i6 + 1)
              {
                str4 = str1.substring(i6);
                localObject1 = str3;
                localObject2 = str2;
              }
              else
              {
                r.b();
                str4 = "";
                localObject1 = str3;
                localObject2 = str2;
              }
            }
            break;
          }
        }
      } while (paramInt <= 6);
      try
      {
        if (ServiceInterface.k(getApplicationContext()))
        {
          r.c();
          return;
        }
      }
      catch (Exception localException)
      {
        r.i();
        return;
      }
      if (!cn.jpush.android.c.a.o(getApplicationContext()))
      {
        if (this.r != 0) {
          PushProtocol.MsgResponse(this.r, 0, o, (byte)i3, i4);
        }
        cn.jpush.android.a.a locala2 = cn.jpush.android.a.l.a(getApplicationContext(), str4, (String)localObject2, (String)localObject1);
        if (locala2 == null) {}
        for (;;)
        {
          r.c();
          return;
          ServiceInterface.a(locala2.c, 1030, cn.jpush.android.a.d);
        }
      }
      ad localad;
      cn.jpush.android.a.a locala1;
      if (this.r == 0)
      {
        a(i3, i4);
        new StringBuilder(bb[14]).append(i4).toString();
        r.e();
        localad = new ad(bb[4], bb[20]);
        if ((TextUtils.isEmpty((CharSequence)localObject2)) || (TextUtils.isEmpty((CharSequence)localObject1))) {
          break label1270;
        }
        if (TextUtils.isEmpty(str4)) {
          break label1264;
        }
        r.b();
        locala1 = cn.jpush.android.a.l.a(getApplicationContext(), str4, (String)localObject2, (String)localObject1);
        if (locala1 != null) {
          break label985;
        }
      }
      for (;;)
      {
        localad.a();
        return;
        if (PushProtocol.MsgResponse(this.r, 0, o, (byte)i3, i4) != 0)
        {
          a(i3, i4);
          break;
        }
        new StringBuilder(bb[22]).append(i4).toString();
        r.a();
        break;
        e locale = locala1.h();
        if (aa.contains(locale))
        {
          new StringBuilder(bb[16]).append(locale).toString();
          r.e();
        }
        else
        {
          if (aa.size() >= 200) {
            aa.poll();
          }
          aa.offer(locale);
          if (((String)localObject1).equalsIgnoreCase(bb[5]))
          {
            cn.jpush.android.a.l.a(getApplicationContext(), locala1);
          }
          else if (locala1.e)
          {
            locala1.g = true;
            Intent localIntent = new Intent(bb[19]);
            localIntent.putExtra(bb[17], (String)localObject1);
            localIntent.putExtra(bb[26], (String)localObject2);
            localIntent.putExtra(bb[10], str4);
            localIntent.addCategory((String)localObject2);
            sendOrderedBroadcast(localIntent, (String)localObject2 + bb[11]);
          }
          else
          {
            locala1.l = ((String)localObject2);
            locala1.m = ((String)localObject1);
            if (!locala1.f())
            {
              cn.jpush.android.c.a.a(getApplicationContext(), locala1);
            }
            else
            {
              new Thread(new g(this, cn.jpush.android.a.a.a(locala1))).start();
              continue;
              r.e();
              continue;
              r.d();
            }
          }
        }
      }
      o(str4);
      return;
      ServiceInterface.g(getApplicationContext());
      return;
      l(str4);
      return;
      k(str4);
      return;
      a(getApplicationContext(), J);
      return;
      a((String)localObject2, J);
      return;
      a(str4, 0);
      return;
      j(str4);
      return;
      if (i1 == 6)
      {
        n(bb[27]);
        return;
      }
      if (i1 == 7)
      {
        i(bb[12]);
        return;
      }
      if (i1 == 11)
      {
        i(bb[3]);
        return;
      }
      if (i1 == 14)
      {
        n(bb[2]);
        return;
      }
      if (i1 == 16)
      {
        m(bb[27]);
        return;
      }
      if (i1 == 17)
      {
        m(bb[2]);
        return;
      }
    } while (i1 == 10);
    label564:
    label985:
    label1264:
    if (i1 == 19)
    {
      u();
      return;
    }
    new StringBuilder(bb[8]).append(i1).toString();
    r.b();
  }
  
  protected final void f()
  {
    r.b();
    this.W = 0;
    for (;;)
    {
      String str1 = (String)this.t.poll();
      if (str1 == null) {
        break;
      }
      new StringBuilder(bb['µ']).append(str1).toString();
      r.b();
      if (str1.startsWith(bb[126]))
      {
        String[] arrayOfString6 = str1.split(",");
        String str2 = str1.substring(1 + str1.indexOf(",", 1 + str1.indexOf(",")));
        if (str2 != null)
        {
          int i9 = PushProtocol.RepPush(this.r, o, Integer.valueOf(arrayOfString6[1]).byteValue(), str2);
          if (i9 >= 0)
          {
            new StringBuilder(bb['']).append(str2).toString();
            r.a();
          }
          else
          {
            new StringBuilder(bb['·']).append(i9).toString();
            r.a();
          }
        }
      }
      else if (str1.startsWith(bb['¶']))
      {
        String[] arrayOfString5 = str1.split(bb[91]);
        if (arrayOfString5.length > 3)
        {
          try
          {
            int i8 = Integer.valueOf(arrayOfString5[3]).intValue();
            i6 = i8;
          }
          catch (Exception localException2)
          {
            int i6;
            int i7;
            for (;;)
            {
              i6 = 0;
            }
            a(arrayOfString5[2], J, i6);
            r.c(bb[4], bb['²'] + i7);
          }
          i7 = a(this.r, o, arrayOfString5[1], arrayOfString5[2], i6);
          if (i7 >= 0) {
            r.c(bb[4], bb[''] + arrayOfString5[2]);
          }
        }
        else
        {
          new StringBuilder(bb['­']).append(str1).toString();
          r.e();
        }
      }
      else if (str1.startsWith(bb['¬']))
      {
        String[] arrayOfString4 = str1.split(",");
        if (arrayOfString4.length > 2)
        {
          int i5 = PushProtocol.EnChannel(this.r, o, arrayOfString4[1], arrayOfString4[2]);
          if (i5 >= 0)
          {
            new StringBuilder(bb['°']).append(arrayOfString4[1]).append(bb['¯']).append(arrayOfString4[2]).toString();
            r.a();
          }
          else
          {
            new StringBuilder(bb['«']).append(i5).toString();
            r.a();
          }
        }
        else
        {
          new StringBuilder(bb['±']).append(str1).toString();
          r.e();
        }
      }
      else if (str1.startsWith(bb['ª']))
      {
        String[] arrayOfString3 = str1.split(",");
        if (arrayOfString3.length > 2)
        {
          int i4 = PushProtocol.UnChnelId(this.r, o, arrayOfString3[1], arrayOfString3[2]);
          if (i4 >= 0)
          {
            new StringBuilder(bb['¹']).append(arrayOfString3[1]).append(bb['¯']).append(arrayOfString3[2]).toString();
            r.a();
          }
          else
          {
            new StringBuilder(bb['¸']).append(i4).toString();
            r.a();
          }
        }
        else
        {
          new StringBuilder(bb['®']).append(str1).toString();
          r.e();
        }
      }
      else if (str1.startsWith(bb['¦']))
      {
        String[] arrayOfString2 = str1.split(bb[91]);
        if (arrayOfString2.length > 2)
        {
          int i3 = PushProtocol.PushTime(this.r, o, arrayOfString2[1], arrayOfString2[2]);
          if (i3 >= 0)
          {
            new StringBuilder(bb['¥']).append(arrayOfString2[1]).append(bb['¯']).append(arrayOfString2[2]).toString();
            r.a();
          }
          else
          {
            new StringBuilder(bb['¤']).append(i3).toString();
            r.a();
          }
        }
        else
        {
          new StringBuilder(bb['³']).append(str1).toString();
          r.e();
        }
      }
      else if (str1.startsWith(bb['¨']))
      {
        String[] arrayOfString1 = str1.split(bb[91]);
        if (arrayOfString1.length > 2)
        {
          int i2;
          try
          {
            int i1 = Integer.parseInt(arrayOfString1[1]);
            i2 = Integer.parseInt(arrayOfString1[2]);
            if (PushProtocol.MsgResponse(this.r, 0, o, (byte)i1, i2) == 0) {
              break label960;
            }
            a(i1, i2);
          }
          catch (Exception localException1)
          {
            localException1.getMessage();
            r.e();
          }
          continue;
          label960:
          new StringBuilder(bb[22]).append(i2).toString();
          r.a();
        }
        else
        {
          new StringBuilder(bb['´']).append(str1).toString();
          r.e();
        }
      }
    }
    w();
    B();
    JSONObject localJSONObject;
    if (z.a(getApplicationContext(), bb[44], bb[46]).equals(bb[47])) {
      if (this.r != 0)
      {
        r.c();
        localJSONObject = new JSONObject();
      }
    }
    try
    {
      localJSONObject.put(bb['º'], getPackageName());
      localJSONObject.put(bb['©'], J);
      label1104:
      if (ServiceInterface.k(getApplicationContext())) {
        PushProtocol.RepPush(this.r, o, (byte)4, localJSONObject.toString());
      }
      for (;;)
      {
        p();
        if (A) {
          ServiceInterface.g(getApplicationContext());
        }
        if (Q)
        {
          r.b();
          this.ae.sendEmptyMessageDelayed(1002, 0L);
        }
        if (I <= 0)
        {
          I = 1 + I;
          z.b(getApplicationContext(), bb['§'], I);
        }
        return;
        PushProtocol.RepPush(this.r, o, (byte)5, localJSONObject.toString());
      }
    }
    catch (JSONException localJSONException)
    {
      break label1104;
    }
  }
  
  protected final void f(int paramInt)
  {
    r.b(bb[4], bb['¢']);
    if (paramInt == -991) {
      return;
    }
    ab.b = 1 + ab.b;
    if ((!ServiceInterface.k(getApplicationContext())) && (cn.jpush.android.c.a.b(getApplicationContext()))) {
      if (h != 86401) {
        break label252;
      }
    }
    label252:
    for (int i1 = 1;; i1 = 0)
    {
      if (i1 == 0)
      {
        int i2 = cn.jpush.android.c.a.h(getApplicationContext());
        if ((cn.jpush.android.c.a.g(getApplicationContext())) || (i2 > 0))
        {
          int i3 = (int)(1000.0D * (3.0D * Math.pow(2.0D, this.W)));
          this.W = (1 + this.W);
          if (i3 > 500 * h) {
            i3 = 500 * h;
          }
          if (((this.W <= 5) || (i2 == 1)) && (!this.ae.hasMessages(1005)) && (!this.ae.hasMessages(1004)))
          {
            new StringBuilder(bb['£']).append(i3).toString();
            r.b();
            this.ae.sendEmptyMessageDelayed(1005, i3);
          }
        }
      }
      this.V = 0;
      this.Z = (1 + this.Z);
      if (!Q) {
        break;
      }
      this.ae.removeMessages(1002);
      return;
    }
  }
  
  public IBinder onBind(Intent paramIntent)
  {
    return null;
  }
  
  /* Error */
  public void onCreate()
  {
    // Byte code:
    //   0: aload_0
    //   1: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   4: invokestatic 1405	cn/jpush/android/service/ServiceInterface:k	(Landroid/content/Context;)Z
    //   7: ifeq +4 -> 11
    //   10: return
    //   11: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   14: invokestatic 1547	java/lang/Thread:currentThread	()Ljava/lang/Thread;
    //   17: invokevirtual 1548	java/lang/Thread:getId	()J
    //   20: putstatic 1550	cn/jpush/android/service/PushService:a	J
    //   23: aload_0
    //   24: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   27: invokestatic 1552	cn/jpush/android/a:a	(Landroid/content/Context;)Z
    //   30: ifeq -20 -> 10
    //   33: aload_0
    //   34: aload_0
    //   35: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   38: invokestatic 1554	cn/jpush/android/c/a:q	(Landroid/content/Context;)Z
    //   41: putfield 633	cn/jpush/android/service/PushService:O	Z
    //   44: aload_0
    //   45: getfield 633	cn/jpush/android/service/PushService:O	Z
    //   48: ifeq -38 -> 10
    //   51: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   54: getstatic 1065	cn/jpush/android/a:f	Ljava/lang/String;
    //   57: invokestatic 917	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   60: ifne +9 -> 69
    //   63: getstatic 1065	cn/jpush/android/a:f	Ljava/lang/String;
    //   66: putstatic 553	cn/jpush/android/service/PushService:J	Ljava/lang/String;
    //   69: aload_0
    //   70: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   73: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   76: bipush 72
    //   78: aaload
    //   79: ldc_w 559
    //   82: invokestatic 1174	cn/jpush/android/c/z:a	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   85: astore_1
    //   86: aload_1
    //   87: invokestatic 917	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   90: ifne +17 -> 107
    //   93: aload_1
    //   94: getstatic 553	cn/jpush/android/service/PushService:J	Ljava/lang/String;
    //   97: invokevirtual 1123	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   100: ifne +7 -> 107
    //   103: aload_0
    //   104: invokespecial 1556	cn/jpush/android/service/PushService:r	()V
    //   107: aload_0
    //   108: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   111: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   114: bipush 72
    //   116: aaload
    //   117: getstatic 553	cn/jpush/android/service/PushService:J	Ljava/lang/String;
    //   120: invokestatic 1059	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   123: aload_0
    //   124: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   127: invokestatic 1557	cn/jpush/android/c/z:a	(Landroid/content/Context;)V
    //   130: aload_0
    //   131: iconst_0
    //   132: putfield 1559	cn/jpush/android/service/PushService:L	Z
    //   135: aload_0
    //   136: iconst_0
    //   137: putfield 1561	cn/jpush/android/service/PushService:M	Z
    //   140: getstatic 1423	cn/jpush/android/a:d	Landroid/content/Context;
    //   143: astore_2
    //   144: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   147: aconst_null
    //   148: astore_3
    //   149: aload_2
    //   150: invokestatic 1564	cn/jpush/android/a/n:b	(Landroid/content/Context;)Landroid/database/Cursor;
    //   153: astore 9
    //   155: aload 9
    //   157: astore_3
    //   158: aload_3
    //   159: ifnull +230 -> 389
    //   162: aload_3
    //   163: invokeinterface 1569 1 0
    //   168: ifle +221 -> 389
    //   171: new 585	java/lang/StringBuilder
    //   174: dup
    //   175: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   178: sipush 158
    //   181: aaload
    //   182: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   185: aload_3
    //   186: invokeinterface 1569 1 0
    //   191: invokevirtual 699	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   194: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   197: pop
    //   198: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   201: aload_3
    //   202: invokeinterface 1572 1 0
    //   207: pop
    //   208: aload_3
    //   209: invokeinterface 1575 1 0
    //   214: ifne +175 -> 389
    //   217: aload_3
    //   218: aload_3
    //   219: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   222: sipush 159
    //   225: aaload
    //   226: invokeinterface 1578 2 0
    //   231: invokeinterface 1581 2 0
    //   236: istore 12
    //   238: aload_3
    //   239: aload_3
    //   240: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   243: sipush 157
    //   246: aaload
    //   247: invokeinterface 1578 2 0
    //   252: invokeinterface 1584 2 0
    //   257: astore 13
    //   259: aload_0
    //   260: getfield 624	cn/jpush/android/service/PushService:t	Ljava/util/Queue;
    //   263: aload 13
    //   265: invokeinterface 707 2 0
    //   270: ifeq +39 -> 309
    //   273: new 585	java/lang/StringBuilder
    //   276: dup
    //   277: getstatic 489	cn/jpush/android/service/PushService:bb	[Ljava/lang/String;
    //   280: sipush 160
    //   283: aaload
    //   284: invokespecial 604	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   287: aload 13
    //   289: invokevirtual 590	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   292: invokevirtual 595	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   295: pop
    //   296: invokestatic 889	cn/jpush/android/c/r:c	()V
    //   299: aload_0
    //   300: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   303: iload 12
    //   305: invokestatic 1587	cn/jpush/android/a/n:b	(Landroid/content/Context;I)Z
    //   308: pop
    //   309: aload_3
    //   310: invokeinterface 1590 1 0
    //   315: pop
    //   316: goto -108 -> 208
    //   319: astore 7
    //   321: invokestatic 1222	cn/jpush/android/c/r:i	()V
    //   324: aload_3
    //   325: ifnull +9 -> 334
    //   328: aload_3
    //   329: invokeinterface 1591 1 0
    //   334: aload_0
    //   335: getfield 1559	cn/jpush/android/service/PushService:L	Z
    //   338: ifeq +88 -> 426
    //   341: aload_0
    //   342: iconst_1
    //   343: putfield 631	cn/jpush/android/service/PushService:N	Z
    //   346: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   349: aload_0
    //   350: iconst_1
    //   351: putfield 631	cn/jpush/android/service/PushService:N	Z
    //   354: invokestatic 644	cn/jpush/android/c/r:b	()V
    //   357: aload_0
    //   358: getfield 631	cn/jpush/android/service/PushService:N	Z
    //   361: ifeq -351 -> 10
    //   364: getstatic 565	cn/jpush/android/service/PushService:Q	Z
    //   367: ifeq +13 -> 380
    //   370: aload_0
    //   371: invokevirtual 819	cn/jpush/android/service/PushService:getApplicationContext	()Landroid/content/Context;
    //   374: invokestatic 1525	cn/jpush/android/c/a:b	(Landroid/content/Context;)Z
    //   377: ifeq +7 -> 384
    //   380: aload_0
    //   381: invokespecial 801	cn/jpush/android/service/PushService:x	()V
    //   384: aload_0
    //   385: invokespecial 882	cn/jpush/android/service/PushService:z	()V
    //   388: return
    //   389: aload_3
    //   390: ifnull -56 -> 334
    //   393: aload_3
    //   394: invokeinterface 1591 1 0
    //   399: goto -65 -> 334
    //   402: astore 4
    //   404: aconst_null
    //   405: astore 5
    //   407: aload 4
    //   409: astore 6
    //   411: aload 5
    //   413: ifnull +10 -> 423
    //   416: aload 5
    //   418: invokeinterface 1591 1 0
    //   423: aload 6
    //   425: athrow
    //   426: aload_0
    //   427: getfield 1561	cn/jpush/android/service/PushService:M	Z
    //   430: ifne -84 -> 346
    //   433: aload_0
    //   434: iconst_1
    //   435: putfield 631	cn/jpush/android/service/PushService:N	Z
    //   438: goto -92 -> 346
    //   441: astore 8
    //   443: aload_3
    //   444: astore 5
    //   446: aload 8
    //   448: astore 6
    //   450: goto -39 -> 411
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	453	0	this	PushService
    //   85	9	1	str1	String
    //   143	7	2	localContext	Context
    //   148	296	3	localObject1	Object
    //   402	6	4	localObject2	Object
    //   405	40	5	localObject3	Object
    //   409	40	6	localObject4	Object
    //   319	1	7	localException	Exception
    //   441	6	8	localObject5	Object
    //   153	3	9	localCursor	android.database.Cursor
    //   236	68	12	i1	int
    //   257	31	13	str2	String
    // Exception table:
    //   from	to	target	type
    //   149	155	319	java/lang/Exception
    //   162	208	319	java/lang/Exception
    //   208	309	319	java/lang/Exception
    //   309	316	319	java/lang/Exception
    //   149	155	402	finally
    //   162	208	441	finally
    //   208	309	441	finally
    //   309	316	441	finally
    //   321	324	441	finally
  }
  
  public void onDestroy()
  {
    new StringBuilder(bb['']).append(Process.myPid()).toString();
    r.b();
    y();
    super.onDestroy();
    v();
    this.ae.removeCallbacksAndMessages(null);
    cn.jpush.android.c.a.r(getApplicationContext());
  }
  
  public int onStartCommand(Intent paramIntent, int paramInt1, int paramInt2)
  {
    new StringBuilder(bb[120]).append(paramInt2).append(bb[117]).append(paramIntent).toString();
    r.a();
    if (!this.O)
    {
      this.ae.sendEmptyMessageDelayed(1003, 100L);
      return 1;
    }
    if ((Q) && (!cn.jpush.android.c.a.b(getApplicationContext())))
    {
      r.a();
      this.ae.sendEmptyMessageDelayed(1003, 100L);
      return 1;
    }
    Bundle localBundle;
    String str1;
    if (paramIntent != null)
    {
      String str14 = paramIntent.getAction();
      localBundle = paramIntent.getExtras();
      str1 = str14;
      label115:
      if ((str1 != null) && (localBundle != null))
      {
        if (!bb[108].equals(str1)) {
          break label543;
        }
        String str13 = localBundle.getString(bb[72]);
        localBundle.getString(bb[113]);
        if (str13 != null) {
          J = str13;
        }
        if ((this.r != 0) && (this.K != null) && (this.K.isAlive())) {
          break label526;
        }
        new StringBuilder(bb[101]).append(this.r).toString();
        r.b();
        x();
      }
    }
    for (;;)
    {
      label229:
      int i1;
      if (localBundle != null)
      {
        new StringBuilder(bb[125]).append(localBundle.toString()).toString();
        r.a();
        String str2 = localBundle.getString(bb[41]);
        i1 = localBundle.getInt(bb[122], 0);
        if (str2 != null)
        {
          if (i1 != 0) {
            break label1673;
          }
          this.ae.removeMessages(1005);
          if (!this.ae.hasMessages(1004)) {
            this.ae.sendEmptyMessage(1005);
          }
        }
      }
      for (;;)
      {
        for (;;)
        {
          label769:
          label1673:
          for (;;)
          {
            for (;;)
            {
              String str3 = localBundle.getString(bb[121]);
              if (str3 != null)
              {
                new StringBuilder(bb[109]).append(str3).toString();
                r.a();
                a(this, str3, localBundle.getBoolean(bb[124], false), localBundle.getBoolean(bb[127], false)).f();
              }
              boolean bool1 = z.a(getApplicationContext(), bb[44], bb[46]).equals(bb[47]);
              if ((Q) || (!this.N) || (bool1)) {
                p();
              }
              if ((str1 == null) || (localBundle != null) || (!bb[100].equals(str1))) {
                break;
              }
              z();
              this.ae.removeMessages(1005);
              this.ae.removeMessages(1004);
              this.ae.sendEmptyMessageDelayed(1004, 500L);
              return 1;
              label526:
              r.b(bb[4], bb[103]);
              break label229;
              label543:
              if (!bb[12].equals(str1)) {
                break label769;
              }
              if (this.N)
              {
                String str11 = localBundle.getString(bb[113]);
                String str12 = J;
                try
                {
                  if ((ac.a(str11)) || (ac.a(str12)))
                  {
                    String.format(bb[118], new Object[] { str11, str12 });
                    r.e();
                    A();
                    stopSelf();
                    break label229;
                  }
                  if (this.r == 0)
                  {
                    r.b();
                    b(str11, str12);
                    x();
                  }
                  for (;;)
                  {
                    A();
                    stopSelf();
                    break;
                    i3 = PushProtocol.UnChnelId(this.r, o, str11, str12);
                    if (i3 >= 0) {
                      break label718;
                    }
                    b(str11, str12);
                    x();
                  }
                }
                catch (Exception localException2)
                {
                  for (;;)
                  {
                    int i3;
                    A();
                    stopSelf();
                    break;
                    label718:
                    new StringBuilder(bb[111]).append(i3).toString();
                    r.c();
                  }
                }
                finally
                {
                  A();
                  stopSelf();
                }
              }
            }
            r.b();
            break label229;
            if (bb[104].equals(str1))
            {
              String str10 = localBundle.getString(bb[126]);
              if (str10 == null) {
                break label229;
              }
              if (this.N)
              {
                new StringBuilder(bb[105]).append(str10).toString();
                r.c();
                if (this.r == 0)
                {
                  f(Integer.toString(3), str10);
                  break label229;
                }
                if (PushProtocol.RepPush(this.r, o, (byte)3, str10) < 0)
                {
                  f(Integer.toString(3), str10);
                  break label229;
                }
                new StringBuilder(bb['']).append(str10).toString();
                r.a();
                break label229;
              }
              r.b();
              break label229;
            }
            if (bb[106].equals(str1))
            {
              if (localBundle.getInt(bb[115], -1) == -1) {
                break label229;
              }
              r.b();
              break label229;
            }
            String str7;
            String str8;
            int i2;
            JSONObject localJSONObject2;
            if (bb[96].equals(str1))
            {
              str7 = localBundle.getString(bb[0]);
              str8 = localBundle.getString(bb[1]);
              i2 = localBundle.getInt(bb[98], 0);
              if ((str7 == null) && (str8 == null)) {
                break label229;
              }
              localJSONObject2 = new JSONObject();
              if (str7 == null) {}
            }
            boolean bool2;
            String str4;
            String str5;
            label1336:
            JSONObject localJSONObject1;
            String str6;
            label1652:
            try
            {
              localJSONObject2.put(bb[0], str7);
              if (str8 != null) {
                localJSONObject2.put(bb[1], str8);
              }
              String str9 = localJSONObject2.toString();
              if (localJSONObject2.length() <= 0) {
                break label229;
              }
              if (this.N)
              {
                a(str9, i2);
                break label229;
              }
              new StringBuilder(bb[102]).append(str1).toString();
              r.b();
            }
            catch (JSONException localJSONException2) {}
          }
          if (bb[3].equals(str1))
          {
            if (this.N)
            {
              a(localBundle.getString(bb[113]), J);
              break label229;
            }
            new StringBuilder(bb[102]).append(str1).toString();
            r.b();
            break label229;
          }
          if (!bb[114].equals(str1)) {
            break label1652;
          }
          if (this.N)
          {
            bool2 = localBundle.getBoolean(bb[112], true);
            str4 = localBundle.getString(bb[99]);
            if (bool2) {}
            for (str5 = "0";; str5 = "1")
            {
              if ((!z.a(getApplicationContext(), bb[112], "0").equals(str5)) || (!str4.equals(z.a(getApplicationContext(), bb[99], "")))) {
                break label1336;
              }
              r.b(bb[4], bb[97] + str4);
              break;
            }
            localJSONObject1 = new JSONObject();
          }
          try
          {
            for (;;)
            {
              localJSONObject1.put(bb[112], str5);
              if (!ac.a(str4)) {
                localJSONObject1.put(bb[99], str4.replaceAll(bb[123], bb[110]));
              }
              str6 = localJSONObject1.toString();
              try
              {
                z.b(getApplicationContext(), bb[112], localJSONObject1.getString(bb[112]));
                z.b(getApplicationContext(), bb[99], str4);
                if ((this.r == 0) || (o == 0L))
                {
                  r.b();
                  this.t.offer(bb[116] + J + bb[57] + str6);
                  x();
                }
              }
              catch (Exception localException1)
              {
                for (;;)
                {
                  r.i();
                }
                if (PushProtocol.PushTime(this.r, o, J, str6) < 0)
                {
                  this.t.offer(bb[116] + J + bb[57] + str6);
                  x();
                  break;
                }
                r.c(bb[4], bb[119] + str6);
              }
            }
          }
          catch (JSONException localJSONException1) {}
        }
        new StringBuilder(bb[102]).append(str1).toString();
        r.b();
        break label229;
        if (!bb[107].equals(str1)) {
          break label229;
        }
        v();
        break label229;
        g(i1);
      }
      continue;
      str1 = null;
      localBundle = null;
      break label115;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.PushService
 * JD-Core Version:    0.7.1
 */