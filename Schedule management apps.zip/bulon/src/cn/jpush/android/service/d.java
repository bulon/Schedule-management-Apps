package cn.jpush.android.service;

import android.app.NotificationManager;
import android.os.Handler;
import cn.jpush.android.a.h;
import cn.jpush.android.a.l;
import java.util.concurrent.ConcurrentLinkedQueue;

final class d
  implements c
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[3];
    String str1 = "! Dq%";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 31;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "}eSuk0)\035";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        j = 2;
        arrayOfString2 = arrayOfString1;
        str1 = "}eCuh?)H{{4!\035";
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 81;
        break label96;
        i3 = 69;
        break label96;
        i3 = 39;
        break label96;
        i3 = 26;
        break label96;
        m = 0;
      }
    }
  }
  
  d(DownloadService paramDownloadService, boolean paramBoolean, int paramInt) {}
  
  public final void a(int paramInt)
  {
    DownloadService.c(this.c).cancel(this.b);
    if (a.a(paramInt))
    {
      DownloadService.a(this.c).K = true;
      ServiceInterface.a(DownloadService.a(this.c).c, 1011, this.c);
    }
    try
    {
      str = ((h)DownloadService.a(this.c)).ab;
      ServiceInterface.a(DownloadService.a(this.c).c, 1022, cn.jpush.android.c.a.b(this.c, str), this.c);
      DownloadService.a(this.c).L = true;
      DownloadService.a(this.c, this.b, DownloadService.a(this.c), paramInt);
      return;
    }
    catch (Exception localException)
    {
      for (;;)
      {
        String str = "";
      }
    }
  }
  
  public final void a(long paramLong1, long paramLong2)
  {
    int i = (int)(100.0F * ((float)paramLong1 / (float)paramLong2));
    new StringBuilder(z[0]).append(i).append(z[2]).append(paramLong1).append(z[1]).append(paramLong2).toString();
    cn.jpush.android.c.r.b();
    if (!this.a) {
      DownloadService.a(this.c, DownloadService.a(this.c), this.b, paramLong1, paramLong2);
    }
  }
  
  public final void a(String paramString, boolean paramBoolean)
  {
    DownloadService.a(this.c).M = true;
    DownloadService.a.remove(DownloadService.a(this.c));
    int i = 1001;
    if (DownloadService.a(this.c).a())
    {
      h localh = (h)DownloadService.a(this.c);
      localh.ag = paramString;
      localh.ah = false;
      if (l.a(localh.X, localh.Y, this.c))
      {
        i = 1003;
        localh.ah = true;
      }
    }
    for (;;)
    {
      for (int j = i;; j = 1004)
      {
        if (paramBoolean) {
          j = 1013;
        }
        ServiceInterface.a(DownloadService.a(this.c).c, j, this.c);
        if (!DownloadService.a(this.c).f()) {
          DownloadService.b(this.c).sendEmptyMessageDelayed(this.b, 500L);
        }
        DownloadService.a(this.c).L = true;
        DownloadService.a(this.c, DownloadService.a(this.c));
        return;
        if (!DownloadService.a(this.c).b()) {
          break;
        }
        ((cn.jpush.android.a.r)DownloadService.a(this.c)).Z = paramString;
      }
      if (DownloadService.a(this.c).f()) {
        DownloadService.a(this.c).T = paramString;
      }
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.d
 * JD-Core Version:    0.7.1
 */