package cn.jpush.android.service;

import android.os.PowerManager.WakeLock;

public final class n
{
  private static n a = null;
  private PowerManager.WakeLock b = null;
  
  public static n a()
  {
    if (a == null) {
      a = new n();
    }
    return a;
  }
  
  public final void a(PowerManager.WakeLock paramWakeLock)
  {
    this.b = paramWakeLock;
  }
  
  public final PowerManager.WakeLock b()
  {
    return this.b;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.n
 * JD-Core Version:    0.7.1
 */