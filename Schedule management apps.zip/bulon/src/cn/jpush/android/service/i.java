package cn.jpush.android.service;

import android.os.Handler;
import android.os.Message;
import cn.jpush.android.api.TagAliasCallback;
import cn.jpush.android.api.b;
import cn.jpush.android.api.d;
import cn.jpush.android.c.r;

final class i
  extends Handler
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[3];
    String str1 = "d\017J~TY\017^\037YS\005\rYYY\002H[\026\020\035HNqTN\020\037";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 56;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        j = 2;
        arrayOfString2 = arrayOfString1;
        str1 = "G\006LK\030\rN";
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 48;
        break label96;
        i3 = 110;
        break label96;
        i3 = 45;
        break label96;
        i3 = 63;
        break label96;
        m = 0;
      }
    }
  }
  
  i(PushService paramPushService) {}
  
  public final void handleMessage(Message paramMessage)
  {
    super.handleMessage(paramMessage);
    switch (paramMessage.what)
    {
    default: 
      new StringBuilder(z[1]).append(paramMessage.what).toString();
      r.a();
    }
    do
    {
      do
      {
        do
        {
          return;
          r.b();
          PushService.b(this.a);
          this.a.stopSelf();
          return;
          this.a.stopSelf();
          return;
        } while ((PushService.c(this.a) == null) || (!PushService.c(this.a).isAlive()));
        PushService.d(this.a);
        return;
        PushService.a(this.a, true);
        return;
        PushService.a(this.a, false);
        return;
        r.e();
        PushService.e(this.a);
        return;
        try
        {
          int m = ((Integer)paramMessage.obj).intValue();
          k = m;
        }
        catch (Exception localException2)
        {
          for (;;)
          {
            int k = 0;
          }
        }
      } while (!PushService.c(this.a, k));
      new StringBuilder(z[0]).append(k).append(z[2]).append(paramMessage.what).toString();
      r.e();
      PushService.e(this.a);
      return;
      try
      {
        int j = ((Integer)paramMessage.obj).intValue();
        i = j;
      }
      catch (Exception localException1)
      {
        for (;;)
        {
          b localb;
          TagAliasCallback localTagAliasCallback;
          int i = 0;
        }
      }
    } while (i == 0);
    localb = ServiceInterface.a(i);
    if (localb != null)
    {
      localTagAliasCallback = localb.c;
      if (localTagAliasCallback != null) {
        localTagAliasCallback.gotResult(d.b, localb.a, localb.b);
      }
    }
    ServiceInterface.b(i);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.i
 * JD-Core Version:    0.7.1
 */