package cn.jpush.android.service;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.NetworkInfo;
import android.net.NetworkInfo.State;
import android.net.Uri;
import android.text.SpannableStringBuilder;
import android.text.TextUtils;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import cn.jpush.android.a.c;
import cn.jpush.android.a.d;
import cn.jpush.android.a.h;
import cn.jpush.android.c.ab;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.c.z;
import java.io.File;

public class PushReceiver
  extends BroadcastReceiver
{
  public static d a;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[42];
    int i = 0;
    String str1 = "d(杉揨祉厄圊彥叩戠卫犔恤丳冉珞\016厴帻戠卫丯使凂珃@";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 115;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "\036C\006S\022\tG_";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "\017A\021Q\005\007V\034";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "$r\020K\033N廘诋雾扣Nq!sS斘劂乯继诒亍砣亀诼佃揆連攭枤ぱN(o棸洸剞圊o";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "d皦oW\035<G\026M\036\013\nL2";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "d皦oW\035>C\020K\026F\013o";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = " MEy0:k*v, m1q5'a$l:!l:w#+l |S\nG\003Q\035\013FEQ\035NO\004V\032\bG\026L_NM\025]\035NV\r]S\nG\003Y\006\002VEU\022\007LEY\020\032K\023Q\007\027";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "\001L7]\020\013K\023]SC\002";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "\032M\004K\007:G\035L";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "\003G\026K\022\tG";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "旗泷么沙杺豭甊";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "\035G\013\\\026\034k\001";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "\017R\025";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "\017R\025q\027";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "\fM\001A";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "\032[\025]";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "\nG\007M\0241L\nL\032\bK\006Y\007\007M\013";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = "";
        j = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i] = str2;
        i = 32;
        str1 = "";
        j = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i] = str2;
        i = 33;
        str1 = "";
        j = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i] = str2;
        i = 34;
        str1 = "";
        j = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i] = str2;
        i = 35;
        str1 = "";
        j = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i] = str2;
        i = 36;
        str1 = "";
        j = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i] = str2;
        i = 37;
        str1 = "";
        j = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i] = str2;
        i = 38;
        str1 = "";
        j = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i] = str2;
        i = 39;
        str1 = "=G\013\\S\fP\nY\027\rC\026LS\032MEY\003\036\030E";
        j = 38;
        localObject1 = localObject2;
        break;
      case 38: 
        localObject1[i] = str2;
        i = 40;
        str1 = "";
        j = 39;
        localObject1 = localObject2;
        break;
      case 39: 
        localObject1[i] = str2;
        i = 41;
        str1 = "";
        j = 40;
        localObject1 = localObject2;
        break;
      case 40: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        a = null;
        return;
        i3 = 110;
        continue;
        i3 = 34;
        continue;
        i3 = 101;
        continue;
        i3 = 56;
      }
    }
  }
  
  public void onReceive(Context paramContext, Intent paramIntent)
  {
    String str1 = paramIntent.getAction();
    new StringBuilder(z[15]).append(str1).toString();
    r.b();
    if (!cn.jpush.android.a.a(paramContext.getApplicationContext()))
    {
      break label39;
      break label39;
      break label39;
      break label39;
      break label39;
      break label39;
      break label39;
    }
    label39:
    while (str1 == null) {
      return;
    }
    if (str1.equals(z[32]))
    {
      z.a(paramContext);
      cn.jpush.android.c.k.d(paramContext);
      if (PushService.a())
      {
        ServiceInterface.a(paramContext, 500);
        return;
      }
      r.c();
      return;
    }
    String str12;
    String str13;
    if (str1.equals(z[35]))
    {
      str12 = paramIntent.getDataString().replace(z[3], "");
      str13 = c.a(paramContext, str12);
      ServiceInterface.a(paramContext, l.a(str12));
    }
    for (;;)
    {
      String str14;
      try
      {
        if (TextUtils.isEmpty(str13)) {
          break label39;
        }
        String[] arrayOfString = str13.split(",");
        if (arrayOfString.length <= 0) {
          break label39;
        }
        str14 = arrayOfString[0];
        ServiceInterface.a(str14, 1002, paramContext);
        if (arrayOfString.length < 2) {
          break label1503;
        }
        str15 = arrayOfString[1];
        str16 = "";
        if (arrayOfString.length >= 3) {
          str16 = arrayOfString[2];
        }
        r.e();
        if ((!str15.equals(z[1])) && (!cn.jpush.android.c.a.a(paramContext, str12, str15)))
        {
          r.b();
          ServiceInterface.a(str14, 1100, paramContext);
        }
        if (ac.a(str16)) {
          break label1496;
        }
        cn.jpush.android.api.k.a(paramContext, str16);
        return;
      }
      catch (Exception localException)
      {
        localException.getMessage();
        r.e();
        return;
      }
      if (str1.equals(z[25]))
      {
        ServiceInterface.a(paramContext, l.b(paramIntent.getDataString().replace(z[3], "")));
        return;
      }
      if (str1.equals(z[33]))
      {
        if ((!PushService.m) || (!PushService.a())) {
          break;
        }
        ServiceInterface.e(paramContext);
        return;
      }
      if (str1.equals(z[40]))
      {
        d locald = (d)paramIntent.getSerializableExtra(z[22]);
        if ((locald == null) || (!locald.a())) {
          break;
        }
        ServiceInterface.a(locald.c, 1015, paramContext);
        h localh = (h)locald;
        Intent localIntent2 = new Intent();
        localIntent2.addFlags(268435456);
        localIntent2.setAction(z[11]);
        localIntent2.setDataAndType(Uri.fromFile(new File(localh.ag)), z[6]);
        paramContext.startActivity(localIntent2);
        return;
      }
      if (str1.startsWith(z[28]))
      {
        if (ServiceInterface.k(paramContext))
        {
          r.c();
          return;
        }
        if (!cn.jpush.android.c.a.o(paramContext))
        {
          r.c();
          return;
        }
        String str10 = paramIntent.getStringExtra(z[17]);
        if (ac.a(str10)) {
          break;
        }
        String str11 = paramIntent.getStringExtra(z[19]);
        cn.jpush.android.a.a locala = cn.jpush.android.a.l.a(paramContext, str10, paramIntent.getStringExtra(z[21]), str11);
        if (locala == null) {
          break;
        }
        if (locala.e)
        {
          locala.g = true;
          cn.jpush.android.a.l.a(paramContext, locala);
        }
        abortBroadcast();
        return;
      }
      if (str1.startsWith(z[14]))
      {
        if (paramIntent.getBooleanExtra(z[29], false))
        {
          String str4 = paramIntent.getStringExtra(z[5]);
          int i = paramIntent.getIntExtra(z[24], -1);
          if (i == -1)
          {
            String str9 = paramIntent.getStringExtra(z[16]);
            Toast localToast2 = Toast.makeText(paramContext, str4, 1);
            View localView3 = localToast2.getView();
            if ((localView3 instanceof LinearLayout))
            {
              View localView4 = ((LinearLayout)localView3).getChildAt(0);
              if ((localView4 instanceof TextView))
              {
                TextView localTextView2 = (TextView)localView4;
                if (!ac.a(str9)) {
                  localTextView2.setText(str9);
                }
                localTextView2.setTextSize(13.0F);
              }
            }
            localToast2.show();
            return;
          }
          if (ac.a(str4)) {
            break;
          }
          String str5 = z[8];
          String str6 = z[9];
          String str7 = z[18];
          String str8 = z[38];
          switch (i)
          {
          }
          for (;;)
          {
            StringBuilder localStringBuilder = new StringBuilder();
            localStringBuilder.append(str5).append(str4).append(str6).append(str7).append(str8).append(z[0]);
            SpannableStringBuilder localSpannableStringBuilder = new SpannableStringBuilder(localStringBuilder);
            int j = str5.length();
            int k = j + str4.length();
            localSpannableStringBuilder.setSpan(new ForegroundColorSpan(-13527041), j, k, 33);
            int m = k + 2;
            int n = -2 + (m + str6.length());
            localSpannableStringBuilder.setSpan(new ForegroundColorSpan(-13527041), m, n, 33);
            int i1 = n + str7.length();
            int i2 = i1 + str8.length();
            localSpannableStringBuilder.setSpan(new ForegroundColorSpan(-13527041), i1, i2, 33);
            Toast localToast1 = Toast.makeText(paramContext, str4, 1);
            View localView1 = localToast1.getView();
            if ((localView1 instanceof LinearLayout))
            {
              View localView2 = ((LinearLayout)localView1).getChildAt(0);
              if ((localView2 instanceof TextView))
              {
                TextView localTextView1 = (TextView)localView2;
                if (localSpannableStringBuilder != null) {
                  localTextView1.setText(localSpannableStringBuilder);
                }
                localTextView1.setTextSize(13.0F);
              }
            }
            localToast1.show();
            return;
            str6 = z[10];
            str7 = z[18];
            str8 = z[7];
            continue;
            str6 = z[30];
            str7 = z[18];
            str8 = z[36];
          }
        }
        String str2 = paramIntent.getStringExtra(z[26]);
        if (!ac.a(str2)) {
          ServiceInterface.a(str2, 1000, paramContext);
        }
        if (!cn.jpush.android.c.a.a(paramContext, z[37], true))
        {
          r.b(z[2], z[12]);
          cn.jpush.android.c.a.f(paramContext);
          return;
        }
        Intent localIntent1 = new Intent(z[37]);
        localIntent1.putExtras(paramIntent.getExtras());
        String str3 = paramIntent.getStringExtra(z[20]);
        if (ac.a(str3)) {
          str3 = paramContext.getPackageName();
        }
        localIntent1.addCategory(str3);
        new StringBuilder(z[39]).append(str3).toString();
        r.c();
        paramContext.sendBroadcast(localIntent1, str3 + z[34]);
        return;
      }
      if (!str1.equalsIgnoreCase(z[13])) {
        break;
      }
      NetworkInfo localNetworkInfo = (NetworkInfo)paramIntent.getParcelableExtra(z[27]);
      if (localNetworkInfo == null) {
        break;
      }
      new StringBuilder(z[4]).append(localNetworkInfo.toString()).toString();
      r.a();
      if (paramIntent.getBooleanExtra(z[41], false))
      {
        ab.d = 1 + ab.d;
        r.a();
        a.b = false;
        ServiceInterface.c(paramContext);
        return;
      }
      if (NetworkInfo.State.CONNECTED == localNetworkInfo.getState())
      {
        ServiceInterface.h(paramContext);
        r.a();
        a.b = true;
        if (DownloadService.a()) {
          DownloadService.a(paramContext);
        }
        if (PushService.n)
        {
          ab.e = 1 + ab.e;
          ServiceInterface.a(paramContext, 3000);
        }
        if (a == null) {
          break;
        }
        cn.jpush.android.api.k.b(paramContext, a);
        return;
      }
      if (NetworkInfo.State.DISCONNECTED == localNetworkInfo.getState())
      {
        r.a();
        a.b = false;
        ab.d = 1 + ab.d;
        ServiceInterface.c(paramContext);
        return;
      }
      new StringBuilder(z[23]).append(localNetworkInfo.getState()).append(z[31]).toString();
      r.a();
      return;
      label1496:
      String str16 = str14;
      continue;
      label1503:
      String str15 = "";
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.PushReceiver
 * JD-Core Version:    0.7.1
 */