package cn.jpush.android.service;

import android.text.TextUtils;
import cn.jpush.android.c.r;
import java.util.HashMap;
import org.json.JSONException;
import org.json.JSONObject;

public final class l
{
  private static final HashMap<Integer, String> a;
  private static final HashMap<Integer, String> b;
  private static long c = 0L;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[8];
    int i = 0;
    String str1 = "`A}f\007eURK\013w";
    int j = -1;
    Object localObject2 = localObject1;
    int i10;
    label133:
    String str2;
    for (;;)
    {
      Object localObject3 = str1.toCharArray();
      int k = localObject3.length;
      int m = 0;
      if (k <= 1) {}
      while (k > m)
      {
        Object localObject7 = localObject3;
        int i7 = m;
        int i8 = k;
        Object localObject8 = localObject3;
        for (;;)
        {
          int i9 = localObject8[m];
          switch (i7 % 5)
          {
          default: 
            i10 = 102;
            localObject8[m] = ((char)(i10 ^ i9));
            m = i7 + 1;
            if (i8 != 0) {
              break label133;
            }
            localObject8 = localObject7;
            i7 = m;
            m = i8;
          }
        }
        k = i8;
        localObject3 = localObject7;
      }
      str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "`RyP\to";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "`A}P\002";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "`Ui";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "uH}\\";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "T_fW\tv_-\\\024s^\031\005nUh\031K!";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "T_fW\tv_-K\003q^MFb^i\\F,\021";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "s\\{";
        j = 6;
        localObject1 = localObject2;
      }
    }
    localObject1[i] = str2;
    z = (String[])localObject2;
    HashMap localHashMap = new HashMap();
    a = localHashMap;
    Integer localInteger = Integer.valueOf(0);
    String str3 = "Nz";
    int n = -1;
    label407:
    label543:
    String str4;
    for (;;)
    {
      Object localObject4 = str3.toCharArray();
      int i1 = localObject4.length;
      int i2 = 0;
      if (i1 <= 1) {}
      while (i1 > i2)
      {
        Object localObject5 = localObject4;
        int i3 = i2;
        int i4 = i1;
        Object localObject6 = localObject4;
        int i5 = localObject6[i2];
        int i6;
        switch (i3 % 5)
        {
        default: 
          i6 = 102;
        }
        for (;;)
        {
          localObject6[i2] = ((char)(i6 ^ i5));
          i2 = i3 + 1;
          if (i4 != 0) {
            break label543;
          }
          localObject6 = localObject5;
          i3 = i2;
          i2 = i4;
          break label407;
          i10 = 1;
          break;
          i10 = 49;
          break;
          i10 = 13;
          break;
          i10 = 57;
          break;
          i6 = 1;
          continue;
          i6 = 49;
          continue;
          i6 = 13;
          continue;
          i6 = 57;
        }
        i1 = i4;
        localObject4 = localObject5;
      }
      str4 = new String((char[])localObject4).intern();
      switch (n)
      {
      default: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-1001);
        str3 = "";
        n = 0;
        break;
      case 0: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-1000);
        str3 = "B^cW\003bEdV\b!WlP\ndU#\0316mTlJ\003!Re\\\005j\021tV\023s\021nV\boTnM\017n_-X\be\021\\\022sH-U\007uT\030";
        n = 1;
        break;
      case 1: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-998);
        str3 = "RTc]\017oV-_\007h]h]FnC-M\017lTbL\022/\021]U\003`Bh\0314dE@FmPy\\\024 ";
        n = 2;
        break;
      case 2: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-997);
        str3 = "STn\\\017wXc^FgPdU\003e\021bKFuX`\\\ttE#\0316mTlJ\003!chM\024x\021aX\022dC,";
        n = 3;
        break;
      case 3: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-996);
        str3 = "B^cW\003bEdV\b!X~\031\005m^~\\\002/\021]U\003`Bh\0314dE@FmPy\\\024 ";
        n = 4;
        break;
      case 4: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-994);
        str3 = "ST~I\toBh\031\022h\\hV\023u\037-i\ndP~\\FSTyK\037!]lM\003s\020";
        n = 5;
        break;
      case 5: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(-993);
        str3 = "H_{X\nhU-J\tbZhMH!aa\\\007rT-k\003uCt\031\n`EhKG";
        n = 6;
        break;
      case 6: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(11);
        str3 = "GPdU\003e\021yVFsTjP\025uT\030";
        n = 7;
        break;
      case 7: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(1005);
        str3 = "X^xKF`A}r\003x\021lW\002!Pc]\024nXi\031\026`RfX\001d\021cX\013d\021lK\003!_bMFlPyZ\016dU#\0316mTlJ\003!UbL\004mT-Z\016dRf\031\022iT`\031\007bRbK\002h_j\031\022n\021LI\026mXnX\022h^c\031\037nD-Z\024dPy\\\002!^c\0316nCyX\n/";
        n = 8;
        break;
      case 8: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(1006);
        str3 = "X^x\031\007oUV\017e\021}X\005jPj\\FoP`\\FhB-W\tu\021hA\017rE!\0316mTlJ\003!Ch^\017rEhKFx^xKFqPnX\rfT-W\007lT-P\b!abK\022`]#";
        n = 9;
        break;
      case 9: 
        localHashMap.put(localInteger, str4);
        localHashMap = a;
        localInteger = Integer.valueOf(1007);
        str3 = "H_{X\nhU-p\013dX!\0314dVdJ\022dC-X\001`Xc\027";
        n = 10;
        break;
      case 10: 
        localHashMap.put(localInteger, str4);
        localHashMap = new HashMap();
        b = localHashMap;
        localInteger = Integer.valueOf(995);
        str3 = "LT~J\007fT-s5N-I\007sBdW\001!BxZ\005dTi";
        n = 11;
        break;
      case 11: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(996);
        str3 = "LT~J\007fT-s5N-I\007sBdW\001!WlP\ndU";
        n = 12;
        break;
      case 12: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(997);
        str3 = "LT~J\007fT-X\nsTl]\037!ChZ\003hGh]J!VdO\003!D}";
        n = 13;
        break;
      case 13: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(998);
        str3 = "LT~J\007fT-X\nsTl]\037!ChZ\003hGh]J!ByP\nm\021}K\tbT~J";
        n = 14;
        break;
      case 14: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1000);
        str3 = "TBhKFb]dZ\rdU-X\be\021bI\003oTi\031\022iT-t\003rBl^\003";
        n = 15;
        break;
      case 15: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1001);
        str3 = "LT~J\007fT-]\tv_aV\007e\021~L\005bTh]";
        n = 16;
        break;
      case 16: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1002);
        str3 = "LT~J\007fT-K\003bTdO\003e\021~L\005bTh]";
        n = 17;
        break;
      case 17: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1003);
        str3 = "LT~J\007fT-J\017mTcZ\003!UbN\bm^l]FrDnZ\003dU";
        n = 18;
        break;
      case 18: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1004);
        str3 = "WXi\\\t!BdU\003oRh\031\002nFcU\007nU-J\023bRh\\\002";
        n = 19;
        break;
      case 19: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1005);
        str3 = "TBhKFb]dZ\rdU-O\017eTb\031\007oU-S\023lAh]Fu^-L\024m\021@\\\025rPj\\F)SV\021rT\020";
        n = 20;
        break;
      case 20: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1008);
        str3 = "";
        n = 21;
        break;
      case 21: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1007);
        str3 = "TBhKFb]dZ\rdU-\036)J\026";
        n = 22;
        break;
      case 22: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1006);
        str3 = "TBhKFb]dZ\rdU-\036%`_n\\\n&";
        n = 23;
        break;
      case 23: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1011);
        str3 = "";
        n = 24;
        break;
      case 24: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1012);
        str3 = "TBhKFb]dZ\rdU-M\t!UbN\bm^l]F`VlP\b";
        n = 25;
        break;
      case 25: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1013);
        str3 = "";
        n = 26;
        break;
      case 26: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1100);
        str3 = "H_{X\nhU-I\007sP`\031\ts\021xW\003yAhZ\022dU-K\003rDaMH";
        n = 27;
        break;
      case 27: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1014);
        str3 = "GPdU\003e\021yVFqChU\t`U-K\003pDdK\003e\021\\\025nDZ\003";
        n = 28;
        break;
      case 28: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1015);
        str3 = "";
        n = 29;
        break;
      case 29: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1016);
        str3 = "TBhKFb]dZ\rdU-M\016d\021z\\\004wXhNAr\021xK\n";
        n = 30;
        break;
      case 30: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1017);
        str3 = "TBhKFb]dZ\rdU-Z\007m]-X\005uXbW";
        n = 31;
        break;
      case 31: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1018);
        str3 = "UYh\031+dB~X\001d\021~Q\tv\021dWFuYh\031\025uPyL\025!SlK";
        n = 32;
        break;
      case 32: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1019);
        str3 = "B]dZ\r!P}I\nhBy\031\007oU-J\016nF-M\016d\021@\\\025rPj\\";
        n = 33;
        break;
      case 33: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1020);
        str3 = "E^zWFh\\l^\003!WlP\ndU";
        n = 34;
        break;
      case 34: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1021);
        str3 = "E^zWFiE`UFgPdU\003e";
        n = 35;
        break;
      case 35: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1022);
        str3 = "E^zWFLT~J\007fT-_\007h]h]";
        n = 36;
        break;
      case 36: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1030);
        str3 = "EX~Z\007sU-M\016d\021`\\\025rPj\\FcTnX\023rT-P\022!X~\031\bnE-P\b!Ee\\FqD~QFuX`\\";
        n = 37;
        break;
      case 37: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1031);
        str3 = "REbIFqD~QFrTO\017bT";
        n = 38;
        break;
      case 38: 
        localHashMap.put(localInteger, str4);
        localHashMap = b;
        localInteger = Integer.valueOf(1032);
        str3 = "ST~L\013d\021}L\025i\021~\\\024wXn\\";
        n = 39;
      }
    }
    localHashMap.put(localInteger, str4);
  }
  
  public static String a(int paramInt)
  {
    if (!a.containsKey(Integer.valueOf(paramInt)))
    {
      new StringBuilder(z[5]).append(paramInt).toString();
      r.b();
      return null;
    }
    return (String)a.get(Integer.valueOf(paramInt));
  }
  
  public static JSONObject a(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return null;
    }
    try
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put(z[1], z[3]);
      localJSONObject.put(z[2], paramString);
      localJSONObject.put(z[4], z[0]);
      return localJSONObject;
    }
    catch (JSONException localJSONException) {}
    return null;
  }
  
  public static String b(int paramInt)
  {
    if (!b.containsKey(Integer.valueOf(paramInt)))
    {
      new StringBuilder(z[6]).append(paramInt).toString();
      r.b();
      return "";
    }
    return (String)b.get(Integer.valueOf(paramInt));
  }
  
  public static JSONObject b(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      return null;
    }
    try
    {
      JSONObject localJSONObject = new JSONObject();
      localJSONObject.put(z[1], z[7]);
      localJSONObject.put(z[2], paramString);
      localJSONObject.put(z[4], z[0]);
      return localJSONObject;
    }
    catch (JSONException localJSONException) {}
    return null;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.service.l
 * JD-Core Version:    0.7.1
 */