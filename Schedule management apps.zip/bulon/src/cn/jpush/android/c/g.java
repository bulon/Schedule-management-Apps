package cn.jpush.android.c;

import java.io.File;

public final class g
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[5];
    String str1 = "W%<O\023Ta}\007\037\032\"e\006\037Nao\006\026_{)";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 122;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "N)lO\027^t)\t\bU,)\034\037H7l\035ZS23O";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "\032%fO\024U5)\001\037_%)\f\022_\"bO7~t)\f\025^$%O\b_5|\035\024\0325{\032\037";
        j = 2;
        arrayOfString2 = arrayOfString1;
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        str1 = "";
        j = 3;
        arrayOfString2 = arrayOfString1;
        i = 2;
        break;
      case 2: 
        arrayOfString2[j] = str2;
        j = 4;
        arrayOfString2 = arrayOfString1;
        str1 = "w\005<";
        i = 3;
        break;
      case 3: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 58;
        break label96;
        i3 = 65;
        break label96;
        i3 = 9;
        break label96;
        i3 = 111;
        break label96;
        m = 0;
      }
    }
  }
  
  public static boolean a(String paramString, File paramFile)
  {
    new StringBuilder(z[3]).append(paramString).toString();
    r.b();
    if ((paramString == null) || ("".equals(paramString)))
    {
      new StringBuilder(z[1]).append(paramString).append(z[2]).toString();
      r.b();
      return true;
    }
    if ((!paramFile.exists()) || (paramFile.length() == 0L)) {
      return false;
    }
    String str = b(paramFile);
    new StringBuilder(z[0]).append(str).toString();
    r.b();
    if ((str != null) && (!"".equals(str)) && (str.equals(paramString)))
    {
      r.b();
      return true;
    }
    r.b();
    return false;
  }
  
  /* Error */
  private static byte[] a(File paramFile)
  {
    // Byte code:
    //   0: new 79	java/io/FileInputStream
    //   3: dup
    //   4: aload_0
    //   5: invokespecial 82	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   8: astore_1
    //   9: sipush 1024
    //   12: newarray 慢⁤污潬慣楴湯
    //   15: lconst_0
    //   16: getstatic 34	cn/jpush/android/c/g:z	[Ljava/lang/String;
    //   19: iconst_4
    //   20: aaload
    //   21: invokestatic 88	java/security/MessageDigest:getInstance	(Ljava/lang/String;)Ljava/security/MessageDigest;
    //   24: astore 10
    //   26: aload_1
    //   27: aload 9
    //   29: invokevirtual 94	java/io/InputStream:read	([B)I
    //   32: istore 11
    //   34: iload 11
    //   36: ifle +13 -> 49
    //   39: aload 10
    //   41: aload 9
    //   43: iconst_0
    //   44: iload 11
    //   46: invokevirtual 98	java/security/MessageDigest:update	([BII)V
    //   49: iload 11
    //   51: iconst_m1
    //   52: if_icmpne -26 -> 26
    //   55: aload_1
    //   56: ifnull +7 -> 63
    //   59: aload_1
    //   60: invokevirtual 101	java/io/InputStream:close	()V
    //   63: aload 10
    //   65: invokevirtual 105	java/security/MessageDigest:digest	()[B
    //   68: astore 7
    //   70: aload 7
    //   72: areturn
    //   73: astore 12
    //   75: invokestatic 108	cn/jpush/android/c/r:g	()V
    //   78: aconst_null
    //   79: areturn
    //   80: astore 13
    //   82: aconst_null
    //   83: astore_1
    //   84: invokestatic 108	cn/jpush/android/c/r:g	()V
    //   87: aconst_null
    //   88: astore 7
    //   90: aload_1
    //   91: ifnull -21 -> 70
    //   94: aload_1
    //   95: invokevirtual 101	java/io/InputStream:close	()V
    //   98: aconst_null
    //   99: areturn
    //   100: astore 8
    //   102: invokestatic 108	cn/jpush/android/c/r:g	()V
    //   105: aconst_null
    //   106: areturn
    //   107: astore 5
    //   109: aconst_null
    //   110: astore 4
    //   112: aload 4
    //   114: ifnull +8 -> 122
    //   117: aload 4
    //   119: invokevirtual 101	java/io/InputStream:close	()V
    //   122: aload 5
    //   124: athrow
    //   125: astore 6
    //   127: invokestatic 108	cn/jpush/android/c/r:g	()V
    //   130: aconst_null
    //   131: areturn
    //   132: astore_3
    //   133: aload_1
    //   134: astore 4
    //   136: aload_3
    //   137: astore 5
    //   139: goto -27 -> 112
    //   142: astore_2
    //   143: goto -59 -> 84
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	146	0	paramFile	File
    //   8	126	1	localFileInputStream1	java.io.FileInputStream
    //   142	1	2	localException1	Exception
    //   132	5	3	localObject1	Object
    //   110	25	4	localFileInputStream2	java.io.FileInputStream
    //   107	16	5	localObject2	Object
    //   137	1	5	localObject3	Object
    //   125	1	6	localIOException1	java.io.IOException
    //   68	21	7	arrayOfByte1	byte[]
    //   100	1	8	localIOException2	java.io.IOException
    //   14	28	9	arrayOfByte2	byte[]
    //   24	40	10	localMessageDigest	java.security.MessageDigest
    //   32	21	11	i	int
    //   73	1	12	localIOException3	java.io.IOException
    //   80	1	13	localException2	Exception
    // Exception table:
    //   from	to	target	type
    //   59	63	73	java/io/IOException
    //   0	9	80	java/lang/Exception
    //   94	98	100	java/io/IOException
    //   0	9	107	finally
    //   117	122	125	java/io/IOException
    //   9	26	132	finally
    //   26	34	132	finally
    //   39	49	132	finally
    //   84	87	132	finally
    //   9	26	142	java/lang/Exception
    //   26	34	142	java/lang/Exception
    //   39	49	142	java/lang/Exception
  }
  
  private static String b(File paramFile)
  {
    byte[] arrayOfByte = a(paramFile);
    String str = "";
    if ((arrayOfByte != null) && (arrayOfByte.length > 0)) {
      for (int i = 0; i < arrayOfByte.length; i++) {
        str = str + Integer.toString(256 + (0xFF & arrayOfByte[i]), 16).substring(1);
      }
    }
    return str;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.g
 * JD-Core Version:    0.7.1
 */