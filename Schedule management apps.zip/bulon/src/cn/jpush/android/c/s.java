package cn.jpush.android.c;

final class s
{
  String a = "";
  String b = "";
  String c = "";
  int d = 0;
  
  public final String toString()
  {
    return this.a + "," + this.b + "," + this.c + "," + this.d;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.s
 * JD-Core Version:    0.7.1
 */