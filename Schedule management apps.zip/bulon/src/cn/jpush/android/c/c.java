package cn.jpush.android.c;

import java.io.UnsupportedEncodingException;

public class c
{
  private static final String z;
  
  static
  {
    Object localObject1 = "".toCharArray();
    int i = localObject1.length;
    int j;
    int i1;
    if (i <= 1)
    {
      j = 0;
      Object localObject2 = localObject1;
      int k = j;
      int m = i;
      Object localObject3 = localObject1;
      for (;;)
      {
        int n = localObject3[j];
        switch (k % 5)
        {
        default: 
          i1 = 17;
          label72:
          localObject3[j] = ((char)(i1 ^ n));
          j = k + 1;
          if (m != 0) {
            break label105;
          }
          localObject3 = localObject2;
          k = j;
          j = m;
        }
      }
      label105:
      i = m;
      localObject1 = localObject2;
    }
    while (i <= j)
    {
      z = new String((char[])localObject1).intern();
      boolean bool1 = c.class.desiredAssertionStatus();
      boolean bool2 = false;
      if (!bool1) {
        bool2 = true;
      }
      a = bool2;
      return;
      i1 = 3;
      break label72;
      i1 = 6;
      break label72;
      i1 = 45;
      break label72;
      i1 = 117;
      break label72;
      j = 0;
    }
  }
  
  public static String a(byte[] paramArrayOfByte, int paramInt)
  {
    int i = 1;
    for (;;)
    {
      int j;
      e locale;
      int k;
      int m;
      int n;
      try
      {
        j = paramArrayOfByte.length;
        locale = new e(10, null);
        k = 4 * (j / 3);
        if (!locale.d) {
          break label135;
        }
        if (j % 3 > 0) {
          k += 4;
        }
        if ((!locale.e) || (j <= 0)) {
          break label184;
        }
        m = 1 + (j - 1) / 57;
        if (!locale.f) {
          break label191;
        }
        i = 2;
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException)
      {
        throw new AssertionError(localUnsupportedEncodingException);
      }
      locale.a = new byte[n];
      locale.a(paramArrayOfByte, 0, j, true);
      if ((!a) && (locale.b != n)) {
        throw new AssertionError();
      }
      label135:
      switch (j % 3)
      {
      case 0: 
        String str = new String(locale.a, z);
        return str;
        n = k;
        continue;
        n = k + i * m;
        break;
      default: 
        break;
      case 1: 
        k += 2;
        break;
      case 2: 
        label184:
        label191:
        k += 3;
      }
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.c
 * JD-Core Version:    0.7.1
 */