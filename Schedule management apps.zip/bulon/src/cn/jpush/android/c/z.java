package cn.jpush.android.c;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import cn.jpush.android.a;
import cn.jpush.android.service.PushService;
import cn.jpush.android.service.ServiceInterface;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.json.JSONObject;

public final class z
{
  private static SharedPreferences a;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[49];
    int i = 0;
    String str1 = "\002pbc\023\024m$'\020\004l:l\021\002q\"o\n\006";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 99;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "\fD%y6\005n\005Y";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "\f]9{\021\004p8Z\n\022N#z";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "\rq/]\032\021{";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "\bm\013l\027&q#n\017\004_(m\021\004m?";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "\fW\"}\006\023h-e";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "\022{8)'#Yl}\f[>";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "\fM8h\021\025Q\"\\\020\004l\034{\006\022{\"}";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "\023l }";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "\022p/";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "\fV#z\027";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "\fW\034";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "\004l>f\021\022";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "\tj8y<\023{<f\021\025A?`\020>k>e";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "\022{8)\0162j-{\027.p\031z\006\023N>l\020\004p8)\027\016$l";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "%\\\013";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "\fN#{\027";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "\022{8)\n\022R#j\002\025w#g&\017.e\006\005>8fYA";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "\fD%y6\005n\034f\021\025";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "\025l9l";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "\bm\036l\020\025>}1\025}";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "\fX%{\020\025R#n\004\004z\005g";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = "\bm\037l\017\007U%e\017\004z\001f\007\004";
        j = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i] = str2;
        i = 32;
        str1 = "";
        j = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i] = str2;
        i = 33;
        str1 = "\007 z\006";
        j = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i] = str2;
        i = 34;
        str1 = "";
        j = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i] = str2;
        i = 35;
        str1 = "IE}$T<e}%T\0347\023!K";
        j = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i] = str2;
        i = 36;
        str1 = "Hbd";
        j = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i] = str2;
        i = 37;
        str1 = "\bm\rg\020\026{>";
        j = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i] = str2;
        i = 38;
        str1 = "";
        j = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i] = str2;
        i = 39;
        str1 = "(p:h\017\bzlo\f\023s-}OAn9z\0135w!lY";
        j = 38;
        localObject1 = localObject2;
        break;
      case 38: 
        localObject1[i] = str2;
        i = 40;
        str1 = "\025w!lR[>";
        j = 39;
        localObject1 = localObject2;
        break;
      case 39: 
        localObject1[i] = str2;
        i = 41;
        str1 = "\021k?a7\bs)E\f\002 ";
        j = 40;
        localObject1 = localObject2;
        break;
      case 40: 
        localObject1[i] = str2;
        i = 42;
        str1 = "L7g!";
        j = 41;
        localObject1 = localObject2;
        break;
      case 41: 
        localObject1[i] = str2;
        i = 43;
        str1 = "=@";
        j = 42;
        localObject1 = localObject2;
        break;
      case 42: 
        localObject1[i] = str2;
        i = 44;
        str1 = "IE|$Z<b}RSL'\021uQ:.a:>HB\022!8Q3uT\037PE|$Z<b~RSL-\021 ";
        j = 43;
        localObject1 = localObject2;
        break;
      case 43: 
        localObject1[i] = str2;
        i = 45;
        str1 = "\002r#z\006\021k?a";
        j = 44;
        localObject1 = localObject2;
        break;
      case 44: 
        localObject1[i] = str2;
        i = 46;
        str1 = "H7";
        j = 45;
        localObject1 = localObject2;
        break;
      case 45: 
        localObject1[i] = str2;
        i = 47;
        str1 = "\tq9{YA";
        j = 46;
        localObject1 = localObject2;
        break;
      case 46: 
        localObject1[i] = str2;
        i = 48;
        str1 = "\022{=V\n\005";
        j = 47;
        localObject1 = localObject2;
        break;
      case 47: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        a = null;
        return;
        i3 = 97;
        continue;
        i3 = 30;
        continue;
        i3 = 76;
        continue;
        i3 = 9;
      }
    }
  }
  
  public static int a(Context paramContext, String paramString, int paramInt)
  {
    c(paramContext);
    return a.getInt(paramString, paramInt);
  }
  
  public static long a(Context paramContext, String paramString, long paramLong)
  {
    c(paramContext);
    return a.getLong(paramString, 0L);
  }
  
  public static String a(Context paramContext, String paramString1, String paramString2)
  {
    c(paramContext);
    return a.getString(paramString1, paramString2);
  }
  
  private static void a()
  {
    r.c();
    String str1 = a.getString(z[20], z[15]);
    String str2;
    label135:
    String str3;
    label189:
    String str4;
    label267:
    int i;
    label324:
    String str5;
    label406:
    String str7;
    label495:
    String str8;
    label552:
    String str14;
    if (!str1.equals(z[15]))
    {
      if (str1.toLowerCase().equals(z[27]))
      {
        PushService.b = true;
        new StringBuilder(z[8]).append(str1).toString();
        r.b();
      }
    }
    else
    {
      str2 = a.getString(z[6], z[15]);
      if (!str2.equals(z[15]))
      {
        if (!str2.toLowerCase().equals(z[27])) {
          break label1217;
        }
        PushService.y = true;
      }
      str3 = a.getString(z[16], z[15]);
      if (!str3.equals(z[15]))
      {
        if (!str3.toLowerCase().equals(z[27])) {
          break label1240;
        }
        PushService.d(true);
        new StringBuilder(z[24]).append(str3).toString();
        r.b();
      }
      str4 = a.getString(z[10], z[15]);
      if (!str4.equals(z[15]))
      {
        if (!str4.toLowerCase().equals(z[27])) {
          break label1263;
        }
        PushService.m = true;
        new StringBuilder(z[19]).append(str4).toString();
        r.b();
      }
      i = a.getInt(z[12], -1);
      if (i != -1)
      {
        if (i != 1) {
          break label1286;
        }
        PushService.n = true;
        new StringBuilder(z[22]).append(PushService.n).toString();
        r.b();
      }
      str5 = a.getString(z[1], z[15]);
      if (!str5.equals(z[15]))
      {
        if (!str5.toLowerCase().equals(z[27])) {
          break label1298;
        }
        PushService.x = true;
      }
      String str6 = a.getString(z[18], "");
      if (!ac.a(str6)) {
        w.a(str6);
      }
      str7 = a.getString(z[31], z[15]);
      if (!str7.equals(z[15]))
      {
        if (!str7.toLowerCase().equals(z[27])) {
          break label1322;
        }
        PushService.c(true);
      }
      str8 = a.getString(z[29], z[15]);
      if (!str8.equals(z[15]))
      {
        if (!str8.toLowerCase().equals(z[27])) {
          break label1346;
        }
        PushService.b(true);
      }
      int j = a.getInt(z[3], -1);
      if (j != -1) {
        PushService.d(j);
      }
      int k = a.getInt(z[7], -1);
      if (k != -1)
      {
        PushService.h = k;
        ServiceInterface.f(a.d);
      }
      int m = a.getInt(z[21], -1);
      if (m != -1)
      {
        PushService.l = m;
        PushService.a(m);
      }
      String str9 = a.getString(z[14], z[15]);
      if (!str9.equals(z[15]))
      {
        PushService.k = str9;
        PushService.a(str9);
      }
      String str10 = a.getString(z[28], z[15]);
      if (!str10.equals(z[15])) {
        PushService.d(str10);
      }
      String str11 = a.getString(z[17], z[15]);
      if (!str11.equals(z[15])) {
        PushService.c(str11);
      }
      int n = a.getInt(z[32], -1);
      if (n != -1) {
        PushService.d = n;
      }
      String str12 = a.getString(z[13], z[15]);
      if (!str12.equals(z[15])) {
        PushService.b(str12);
      }
      int i1 = a.getInt(z[23], -1);
      if (i1 != -1) {
        PushService.b(i1);
      }
      String str13 = a.getString(z[5], z[15]);
      if (!str13.equals(z[15])) {
        PushService.w = str13;
      }
      str14 = a.getString(z[25], z[15]);
      if (!str14.equals(z[15]))
      {
        if (!str14.toLowerCase().equals(z[27])) {
          break label1370;
        }
        PushService.a(true);
      }
    }
    for (;;)
    {
      int i2 = a.getInt(z[30], -1);
      if (i2 != -1) {
        PushService.c(i2);
      }
      int i3 = a.getInt(z[4], -1);
      if (i3 != -1) {
        PushService.z = i3;
      }
      int i4 = a.getInt(z[34], -1);
      if (i4 != -1) {
        ServiceInterface.c(i4);
      }
      int i5 = a.getInt(z[26], -1);
      if (i5 != -1) {
        ServiceInterface.d(i5);
      }
      String str15 = a.getString(z[9], z[15]);
      if (!str15.equals(z[15])) {
        ServiceInterface.a(str15);
      }
      String str16 = a.getString(z[2], z[15]);
      if (!str16.equals(z[15])) {
        ServiceInterface.b(str16);
      }
      long l = a.getLong(z[11], -1L);
      if (-1L != l) {
        PushService.e = l;
      }
      return;
      if (!str1.toLowerCase().equals(z[33])) {
        break;
      }
      PushService.b = false;
      break;
      label1217:
      if (!str2.toLowerCase().equals(z[33])) {
        break label135;
      }
      PushService.y = false;
      break label135;
      label1240:
      if (!str3.toLowerCase().equals(z[33])) {
        break label189;
      }
      PushService.d(false);
      break label189;
      label1263:
      if (!str4.toLowerCase().equals(z[33])) {
        break label267;
      }
      PushService.m = false;
      break label267;
      label1286:
      if (i != 0) {
        break label324;
      }
      PushService.n = false;
      break label324;
      label1298:
      if (!str5.toLowerCase().equals(z[33])) {
        break label406;
      }
      PushService.x = false;
      break label406;
      label1322:
      if (!str7.toLowerCase().equals(z[33])) {
        break label495;
      }
      PushService.c(false);
      break label495;
      label1346:
      if (!str8.toLowerCase().equals(z[33])) {
        break label552;
      }
      PushService.b(false);
      break label552;
      label1370:
      if (str14.toLowerCase().equals(z[33])) {
        PushService.a(false);
      }
    }
  }
  
  public static void a(Context paramContext)
  {
    try
    {
      c(paramContext);
      a();
      return;
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
    }
  }
  
  public static void a(Context paramContext, JSONObject paramJSONObject)
  {
    int i = 1;
    SharedPreferences.Editor localEditor = c(paramContext).edit();
    String str1 = paramJSONObject.optString(z[20], z[15]);
    if (!str1.equals(z[15])) {
      localEditor.putString(z[20], str1);
    }
    String str2 = paramJSONObject.optString(z[25], z[15]);
    if (!str2.equals(z[15])) {
      localEditor.putString(z[25], str2);
    }
    int j = paramJSONObject.optInt(z[7], -1);
    if (j != -1) {
      localEditor.putInt(z[7], j);
    }
    int k = paramJSONObject.optInt(z[12], -1);
    if (k != -1) {
      localEditor.putInt(z[12], k);
    }
    int m = paramJSONObject.optInt(z[3], -1);
    if (m != -1) {
      localEditor.putInt(z[3], m);
    }
    String str3 = paramJSONObject.optString(z[29], z[15]);
    if (!str3.equals(z[15])) {
      localEditor.putString(z[29], str3);
    }
    String str4 = paramJSONObject.optString(z[14], z[15]);
    if (!str4.equals(z[15])) {
      localEditor.putString(z[14], str4);
    }
    String str5 = paramJSONObject.optString(z[28], z[15]);
    if (!str5.equals(z[15])) {
      localEditor.putString(z[28], str5);
    }
    String str6 = paramJSONObject.optString(z[13], z[15]);
    if (!str6.equals(z[15])) {
      localEditor.putString(z[13], str6);
    }
    int n = paramJSONObject.optInt(z[21], -1);
    if (n != -1) {
      localEditor.putInt(z[21], n);
    }
    String str7 = paramJSONObject.optString(z[17], z[15]);
    if (!str7.equals(z[15])) {
      localEditor.putString(z[17], str7);
    }
    String str8 = paramJSONObject.optString(z[10], z[15]);
    if (!str8.equals(z[15])) {
      localEditor.putString(z[10], str8);
    }
    String str9 = paramJSONObject.optString(z[16], z[15]);
    if (!str9.equals(z[15])) {
      localEditor.putString(z[16], str9);
    }
    String str10 = paramJSONObject.optString(z[31], z[15]);
    if (!str10.equals(z[15])) {
      localEditor.putString(z[31], str10);
    }
    String str11 = paramJSONObject.optString(z[5], z[15]);
    if (!str11.equals(z[15])) {
      localEditor.putString(z[5], str11);
    }
    String str12 = paramJSONObject.optString(z[i], z[15]);
    if (!str12.equals(z[15])) {
      localEditor.putString(z[i], str12);
    }
    String str13 = paramJSONObject.optString(z[6], z[15]);
    if (!str13.equals(z[15])) {
      localEditor.putString(z[6], str13);
    }
    int i1 = paramJSONObject.optInt(z[23], -1);
    if (i1 != -1) {
      localEditor.putInt(z[23], i1);
    }
    int i2 = paramJSONObject.optInt(z[34], -1);
    if (i2 != -1) {
      localEditor.putInt(z[34], i2);
    }
    int i3 = paramJSONObject.optInt(z[26], -1);
    if (i3 != -1) {
      localEditor.putInt(z[26], i3);
    }
    String str14 = paramJSONObject.optString(z[9], z[15]);
    if (!str14.equals(z[15])) {
      localEditor.putString(z[9], str14);
    }
    String str15 = paramJSONObject.optString(z[2], z[15]);
    if (!str15.equals(z[15])) {
      localEditor.putString(z[2], str15);
    }
    int i4 = paramJSONObject.optInt(z[32], -1);
    if (i4 != -1) {
      localEditor.putInt(z[32], i4);
    }
    String str16 = paramJSONObject.optString(z[37], z[15]);
    if (!str16.equals(z[15])) {
      localEditor.putString(z[37], str16);
    }
    String str17 = paramJSONObject.optString(z[45], z[15]);
    if (!str17.equals(z[15])) {
      localEditor.putString(z[45], str17);
    }
    String str18 = paramJSONObject.optString(z[41], z[15]);
    String[] arrayOfString1;
    ArrayList localArrayList;
    int i6;
    String[] arrayOfString3;
    if (!str18.equals(z[15]))
    {
      String str19 = z[44];
      if (!Pattern.compile(z[35] + str19 + z[36] + str19 + z[42] + str19 + z[46]).matcher(str18).matches()) {
        break label1650;
      }
      arrayOfString1 = str18.split("_");
      String str20 = arrayOfString1[i];
      new StringBuilder(z[40]).append(str20).toString();
      r.a();
      String[] arrayOfString2 = str20.split("-");
      localArrayList = new ArrayList();
      int i5 = arrayOfString2.length;
      i6 = 0;
      if (i6 < i5)
      {
        String str22 = arrayOfString2[i6];
        new StringBuilder(z[47]).append(str22).toString();
        r.a();
        arrayOfString3 = str22.split(z[43]);
      }
    }
    for (;;)
    {
      int i7;
      try
      {
        Integer localInteger1 = Integer.valueOf(Integer.parseInt(arrayOfString3[0]));
        Integer localInteger2 = Integer.valueOf(Integer.parseInt(arrayOfString3[1]));
        if (localInteger2.intValue() > localInteger1.intValue())
        {
          i7 = localInteger1.intValue();
          if (i7 <= localInteger2.intValue())
          {
            if (localArrayList.contains(Integer.valueOf(i7))) {
              break label1678;
            }
            localArrayList.add(String.valueOf(i7));
            break label1678;
          }
        }
        else
        {
          new StringBuilder(z[39]).append(str18).toString();
          r.e();
          i = 0;
        }
        i6++;
      }
      catch (Exception localException)
      {
        new StringBuilder(z[39]).append(str18).toString();
        r.i();
        i = 0;
        continue;
      }
      break;
      if (i != 0)
      {
        StringBuilder localStringBuilder = new StringBuilder();
        localStringBuilder.append(arrayOfString1[0] + "_");
        Iterator localIterator = localArrayList.iterator();
        while (localIterator.hasNext())
        {
          localStringBuilder.append((String)localIterator.next());
          localStringBuilder.append("-");
        }
        localStringBuilder.deleteCharAt(-1 + localStringBuilder.length());
        String str21 = localStringBuilder.toString();
        localEditor.putString(z[41], str21);
        new StringBuilder(z[38]).append(str21).toString();
        r.b();
      }
      for (;;)
      {
        long l = paramJSONObject.optLong(z[11], -1L);
        if (l != -1L) {
          localEditor.putLong(z[11], l);
        }
        localEditor.commit();
        a();
        return;
        label1650:
        new StringBuilder(z[39]).append(str18).toString();
        r.e();
      }
      label1678:
      i7++;
    }
  }
  
  public static short b(Context paramContext)
  {
    SharedPreferences.Editor localEditor = c(paramContext).edit();
    short s = (short)((1 + a.getInt(z[48], 100)) % 32767);
    localEditor.putInt(z[48], s);
    localEditor.commit();
    return s;
  }
  
  public static void b(Context paramContext, String paramString, int paramInt)
  {
    SharedPreferences.Editor localEditor = c(paramContext).edit();
    localEditor.putInt(paramString, paramInt);
    localEditor.commit();
  }
  
  public static void b(Context paramContext, String paramString, long paramLong)
  {
    SharedPreferences.Editor localEditor = c(paramContext).edit();
    localEditor.putLong(paramString, paramLong);
    localEditor.commit();
  }
  
  public static void b(Context paramContext, String paramString1, String paramString2)
  {
    SharedPreferences.Editor localEditor = c(paramContext).edit();
    localEditor.putString(paramString1, paramString2);
    localEditor.commit();
  }
  
  private static SharedPreferences c(Context paramContext)
  {
    if (a == null) {
      a = paramContext.getSharedPreferences(z[0], 0);
    }
    return a;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.z
 * JD-Core Version:    0.7.1
 */