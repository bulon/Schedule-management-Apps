package cn.jpush.android.c;

import android.content.Context;
import android.content.pm.PackageManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.text.TextUtils;
import android.webkit.URLUtil;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.zip.GZIPOutputStream;
import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.HttpVersion;
import org.apache.http.StatusLine;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.AbstractHttpEntity;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.params.BasicHttpParams;
import org.apache.http.params.HttpConnectionParams;
import org.apache.http.params.HttpParams;
import org.apache.http.params.HttpProtocolParams;
import org.apache.http.util.EntityUtils;
import org.json.JSONObject;

public final class n
{
  public static boolean a;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[39];
    int i = 0;
    String str1 = "J\027?)M";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 117;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "U\023,W=2\020=O";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "~ \rm\032qy\035k\002q/\026e\021V.\030c\020?nYq\007sy";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "M&\bq\020l7Yt\024k+Y`\032z0Yj\032kc\034|\034l7C$A/wY)U";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "3c\fv\031%";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "\\/\026w\020";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "P7\021a\007?4\013k\033xc\013a\006o,\027w\020?0\re\001j0Y)U";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "\\,\027p\020q7TH\020q$\rl";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "l&\013r\020mc\013a\006o,\027w\020?%\030m\031j1\034$X?";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "\\,\027j\020|7\020k\033";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "~ \rm\032qy\021p\001o\004\034pU2c";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "~ \rm\032qy\021p\001o\020\020i\005s&>a\001?nY";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "L&\013r\020mc\034v\007p1Y)U";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "L&\013r\020mc\013a\006o,\027w\020?%\030m\031j1\034>A/sY)U";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "#\037e\034s&\035:K";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "M&\bq\020l7Yj\032kc\030q\001w,\013m\017z'C0E.cT$";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "#\034v\007p1G:";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "|,\027b\031v \r>A/zY)U";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "m&\bq\020l7Yp\034r&\026q\001%wI<U2c";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "#\037e\034s&\035[\002v7\021[\007z7\013m\020l}G";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "q,\r$\024| \034t\001~!\025aO+sO$X?";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "^6\rl\032m*\003e\001v,\027";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "^ \032a\005k";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = ".sW4[/mH3G";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "|.\016e\005";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "w7\rt[m,\fp\0201'\034b\024j/\r)\005m,\001}";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "\\/\020a\033k\023\013k\001p \026h0g \034t\001v,\027>";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "~3\th\034|\"\rm\032ql\023w\032q";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "|,\027j\020|7\020r\034k:";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = ",$\016e\005";
        j = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i] = str2;
        i = 32;
        str1 = "V\f<|\026z3\rm\032qy\035a\027j$";
        j = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i] = str2;
        i = 33;
        str1 = "\\,\027p\020q7TA\033|,\035m\033x";
        j = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i] = str2;
        i = 34;
        str1 = "]\"\nm\026?";
        j = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i] = str2;
        i = 35;
        str1 = "Gn8t\0052\b\034}";
        j = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i] = str2;
        i = 36;
        str1 = "j-\020s\024o";
        j = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i] = str2;
        i = 37;
        str1 = "x9\020t";
        j = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i] = str2;
        i = 38;
        str1 = "#\027a\001h,\013o\020m1\026vK!";
        j = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        a = false;
        return;
        i3 = 31;
        continue;
        i3 = 67;
        continue;
        i3 = 121;
        continue;
        i3 = 4;
      }
    }
  }
  
  public static int a(Context paramContext, JSONObject paramJSONObject, boolean paramBoolean)
  {
    int i = 0;
    String str1 = w.b();
    if (!URLUtil.isHttpUrl(str1))
    {
      r.e();
      return -1;
    }
    HttpPost localHttpPost = new HttpPost(str1);
    BasicHttpParams localBasicHttpParams = new BasicHttpParams();
    HttpConnectionParams.setConnectionTimeout(localBasicHttpParams, 30000);
    HttpConnectionParams.setSoTimeout(localBasicHttpParams, 30000);
    DefaultHttpClient localDefaultHttpClient = new DefaultHttpClient(localBasicHttpParams);
    if (paramContext.getPackageManager().checkPermission(z[23], paramContext.getPackageName()) == 0)
    {
      NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService(z[30])).getActiveNetworkInfo();
      if ((localNetworkInfo != null) && (localNetworkInfo.getType() != 1))
      {
        String str5 = localNetworkInfo.getExtraInfo();
        if ((str5 != null) && ((str5.equals(z[25])) || (str5.equals(z[31])) || (str5.equals(z[36])))) {
          localDefaultHttpClient.getParams().setParameter(z[26], new HttpHost(z[24], 80));
        }
      }
    }
    String str2 = "";
    if (paramJSONObject != null) {
      str2 = paramJSONObject.toString();
    }
    if (ac.a(str2))
    {
      r.b();
      return -2;
    }
    localHttpPost.addHeader(z[22], z[29]);
    localHttpPost.addHeader(z[33], z[37]);
    localHttpPost.addHeader(z[35], a.v(paramContext));
    String str3 = w.a(paramContext, str2);
    if (ac.a(str3)) {
      r.b();
    }
    while (i == 0)
    {
      r.b();
      return -3;
      String str4 = w.b(str3);
      if (ac.a(str4))
      {
        r.b();
        i = 0;
      }
      else
      {
        localHttpPost.addHeader(z[21], z[34] + str4);
        i = 1;
      }
    }
    try
    {
      byte[] arrayOfByte1 = str2.getBytes(z[0]);
      ByteArrayOutputStream localByteArrayOutputStream = new ByteArrayOutputStream();
      GZIPOutputStream localGZIPOutputStream = new GZIPOutputStream(localByteArrayOutputStream);
      localGZIPOutputStream.write(arrayOfByte1);
      localGZIPOutputStream.close();
      byte[] arrayOfByte2 = localByteArrayOutputStream.toByteArray();
      localByteArrayOutputStream.close();
      ByteArrayEntity localByteArrayEntity = new ByteArrayEntity(arrayOfByte2);
      localByteArrayEntity.setContentEncoding(z[37]);
      localHttpPost.setEntity(localByteArrayEntity);
      try
      {
        int j = localDefaultHttpClient.execute(localHttpPost).getStatusLine().getStatusCode();
        new StringBuilder(z[27]).append(j).toString();
        r.b();
        switch (j)
        {
        default: 
          if (j / 100 == 5) {
            return 500;
          }
        case 401: 
          r.d();
          return 401;
        case 404: 
          return 404;
        case 429: 
          return 429;
          return -5;
        }
      }
      catch (ClientProtocolException localClientProtocolException)
      {
        new StringBuilder(z[28]).append(localClientProtocolException.getMessage()).toString();
        r.e();
        return -1;
      }
      catch (IOException localIOException2)
      {
        for (;;)
        {
          new StringBuilder(z[32]).append(localIOException2.getMessage()).toString();
          r.e();
        }
      }
      return 200;
    }
    catch (UnsupportedEncodingException localUnsupportedEncodingException)
    {
      return -4;
    }
    catch (IOException localIOException1)
    {
      return -4;
    }
  }
  
  public static String a(String paramString, int paramInt, long paramLong)
  {
    int i = 0;
    new StringBuilder(z[11]).append(paramString).toString();
    r.b();
    if ((paramLong < 200L) || (paramLong > 60000L)) {
      paramLong = 2000L;
    }
    HttpGet localHttpGet = new HttpGet(paramString);
    localHttpGet.addHeader(z[9], z[5]);
    HttpEntity localHttpEntity = null;
    int j;
    label302:
    label313:
    do
    {
      for (;;)
      {
        try
        {
          a = true;
          localHttpResponse = a().execute(localHttpGet);
          if (localHttpResponse != null)
          {
            StatusLine localStatusLine = localHttpResponse.getStatusLine();
            if (localStatusLine != null)
            {
              j = localHttpResponse.getStatusLine().getStatusCode();
              if ((j < 200) || (j >= 300)) {
                break label313;
              }
            }
          }
        }
        catch (Exception localException1)
        {
          for (;;)
          {
            try
            {
              localHttpEntity = localHttpResponse.getEntity();
              str = EntityUtils.toString(localHttpEntity, z[0]);
              if (str == null)
              {
                r.g();
                str = z[16];
              }
            }
            catch (Exception localException2)
            {
              r.f();
              str = z[16];
              if ((localHttpResponse == null) || (localHttpEntity == null)) {
                continue;
              }
              try
              {
                localHttpEntity.consumeContent();
                return str;
              }
              catch (IOException localIOException2)
              {
                r.h();
                return str;
              }
            }
            finally
            {
              HttpResponse localHttpResponse;
              if ((localHttpResponse == null) || (localHttpEntity == null)) {
                break label302;
              }
            }
            try
            {
              localHttpEntity.consumeContent();
              return str;
            }
            catch (IOException localIOException3)
            {
              r.h();
              return str;
            }
          }
          localException1 = localException1;
          r.g();
          i++;
          if (i >= 5)
          {
            localHttpGet.abort();
            return z[19];
          }
          try
          {
            Thread.sleep(paramLong);
          }
          catch (InterruptedException localInterruptedException) {}
        }
      }
      try
      {
        localHttpEntity.consumeContent();
        throw ((Throwable)localObject);
      }
      catch (IOException localIOException1)
      {
        for (;;)
        {
          r.h();
        }
      }
      if ((j < 400) || (j >= 500)) {
        break;
      }
      if (400 == j)
      {
        new StringBuilder(z[13]).append(paramString).toString();
        r.b();
        return z[14];
      }
      if (401 == j)
      {
        new StringBuilder(z[15]).append(paramString).toString();
        r.b();
        return z[16];
      }
      if (404 == j)
      {
        new StringBuilder(z[3]).append(paramString).toString();
        r.b();
        return z[16];
      }
      if (406 == j)
      {
        new StringBuilder(z[20]).append(paramString).toString();
        r.b();
        return z[16];
      }
      if (408 == j)
      {
        new StringBuilder(z[18]).append(paramString).toString();
        r.b();
        return z[16];
      }
      String str = null;
    } while (409 != j);
    new StringBuilder(z[17]).append(paramString).toString();
    r.b();
    return z[16];
    if ((j >= 500) && (j < 600))
    {
      new StringBuilder(z[12]).append(j).append(z[4]).append(paramString).toString();
      r.b();
      return z[16];
    }
    new StringBuilder(z[6]).append(j).append(z[4]).append(paramString).toString();
    r.b();
    return z[16];
  }
  
  public static DefaultHttpClient a()
  {
    BasicHttpParams localBasicHttpParams = new BasicHttpParams();
    HttpProtocolParams.setVersion(localBasicHttpParams, HttpVersion.HTTP_1_1);
    HttpProtocolParams.setContentCharset(localBasicHttpParams, z[0]);
    HttpProtocolParams.setUserAgent(localBasicHttpParams, z[1]);
    HttpConnectionParams.setTcpNoDelay(localBasicHttpParams, true);
    HttpConnectionParams.setConnectionTimeout(localBasicHttpParams, 30000);
    HttpConnectionParams.setSoTimeout(localBasicHttpParams, 30000);
    return new DefaultHttpClient(localBasicHttpParams);
  }
  
  /* Error */
  public static void a(String paramString1, String paramString2, p paramp)
  {
    // Byte code:
    //   0: ldc 2
    //   2: monitorenter
    //   3: new 236	java/lang/StringBuilder
    //   6: dup
    //   7: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   10: iconst_2
    //   11: aaload
    //   12: invokespecial 237	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   15: aload_0
    //   16: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   19: invokevirtual 242	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   22: pop
    //   23: invokestatic 382	cn/jpush/android/c/r:a	()V
    //   26: aload_0
    //   27: invokestatic 388	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   30: ifne +7 -> 37
    //   33: aload_1
    //   34: ifnonnull +16 -> 50
    //   37: aload_2
    //   38: iconst_0
    //   39: ldc 207
    //   41: invokeinterface 393 3 0
    //   46: ldc 2
    //   48: monitorexit
    //   49: return
    //   50: new 346	java/lang/Thread
    //   53: dup
    //   54: new 395	cn/jpush/android/c/o
    //   57: dup
    //   58: aload_0
    //   59: invokevirtual 398	java/lang/String:trim	()Ljava/lang/String;
    //   62: aload_1
    //   63: aload_2
    //   64: invokespecial 400	cn/jpush/android/c/o:<init>	(Ljava/lang/String;Ljava/lang/String;Lcn/jpush/android/c/p;)V
    //   67: invokespecial 403	java/lang/Thread:<init>	(Ljava/lang/Runnable;)V
    //   70: invokevirtual 406	java/lang/Thread:start	()V
    //   73: goto -27 -> 46
    //   76: astore_3
    //   77: ldc 2
    //   79: monitorexit
    //   80: aload_3
    //   81: athrow
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	82	0	paramString1	String
    //   0	82	1	paramString2	String
    //   0	82	2	paramp	p
    //   76	5	3	localObject	Object
    // Exception table:
    //   from	to	target	type
    //   3	33	76	finally
    //   37	46	76	finally
    //   50	73	76	finally
  }
  
  public static boolean a(String paramString)
  {
    return (TextUtils.isEmpty(paramString)) || (paramString.equals(z[16])) || (paramString.equals(z[14])) || (paramString.equals(z[19])) || (paramString.equals(z[38]));
  }
  
  public static byte[] a(String paramString, int paramInt1, long paramLong, int paramInt2)
  {
    byte[] arrayOfByte = null;
    for (int i = 0; i < 4; i++)
    {
      arrayOfByte = b(paramString, 5, 5000L);
      if (arrayOfByte != null) {
        break;
      }
    }
    return arrayOfByte;
  }
  
  /* Error */
  private static byte[] b(String paramString, int paramInt, long paramLong)
  {
    // Byte code:
    //   0: iload_1
    //   1: ifle +9 -> 10
    //   4: iload_1
    //   5: bipush 10
    //   7: if_icmple +5 -> 12
    //   10: iconst_1
    //   11: istore_1
    //   12: lload_2
    //   13: ldc2_w 312
    //   16: lcmp
    //   17: iflt +11 -> 28
    //   20: lload_2
    //   21: ldc2_w 314
    //   24: lcmp
    //   25: ifle +7 -> 32
    //   28: ldc2_w 316
    //   31: lstore_2
    //   32: new 236	java/lang/StringBuilder
    //   35: dup
    //   36: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   39: bipush 10
    //   41: aaload
    //   42: invokespecial 237	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   45: aload_0
    //   46: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   49: invokevirtual 242	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   52: pop
    //   53: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   56: new 319	org/apache/http/client/methods/HttpGet
    //   59: dup
    //   60: aload_0
    //   61: invokespecial 320	org/apache/http/client/methods/HttpGet:<init>	(Ljava/lang/String;)V
    //   64: astore 5
    //   66: aload 5
    //   68: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   71: bipush 9
    //   73: aaload
    //   74: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   77: iconst_5
    //   78: aaload
    //   79: invokevirtual 321	org/apache/http/client/methods/HttpGet:addHeader	(Ljava/lang/String;Ljava/lang/String;)V
    //   82: iconst_0
    //   83: istore 6
    //   85: iconst_1
    //   86: putstatic 106	cn/jpush/android/c/n:a	Z
    //   89: invokestatic 324	cn/jpush/android/c/n:a	()Lorg/apache/http/impl/client/DefaultHttpClient;
    //   92: aload 5
    //   94: invokevirtual 285	org/apache/http/impl/client/DefaultHttpClient:execute	(Lorg/apache/http/client/methods/HttpUriRequest;)Lorg/apache/http/HttpResponse;
    //   97: astore 11
    //   99: aload 11
    //   101: ifnull +65 -> 166
    //   104: aload 11
    //   106: invokeinterface 291 1 0
    //   111: invokeinterface 296 1 0
    //   116: istore 12
    //   118: sipush 200
    //   121: iload 12
    //   123: if_icmpne +296 -> 419
    //   126: aload 11
    //   128: invokeinterface 328 1 0
    //   133: astore 23
    //   135: aload 23
    //   137: astore 17
    //   139: aload 17
    //   141: ifnonnull +68 -> 209
    //   144: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   147: aload 17
    //   149: ifnull +10 -> 159
    //   152: aload 17
    //   154: invokeinterface 341 1 0
    //   159: aconst_null
    //   160: areturn
    //   161: astore 7
    //   163: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   166: iinc 6 1
    //   169: iload 6
    //   171: iload_1
    //   172: if_icmplt +10 -> 182
    //   175: aload 5
    //   177: invokevirtual 344	org/apache/http/client/methods/HttpGet:abort	()V
    //   180: aconst_null
    //   181: areturn
    //   182: lload_2
    //   183: iload 6
    //   185: i2l
    //   186: lmul
    //   187: lstore 8
    //   189: lload 8
    //   191: invokestatic 350	java/lang/Thread:sleep	(J)V
    //   194: goto -109 -> 85
    //   197: astore 10
    //   199: goto -114 -> 85
    //   202: astore 32
    //   204: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   207: aconst_null
    //   208: areturn
    //   209: aload 11
    //   211: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   214: bipush 7
    //   216: aaload
    //   217: invokeinterface 416 2 0
    //   222: astore 25
    //   224: aload 25
    //   226: ifnull +65 -> 291
    //   229: aload 25
    //   231: invokeinterface 421 1 0
    //   236: astore 26
    //   238: aload 26
    //   240: ifnull +57 -> 297
    //   243: aload 26
    //   245: invokestatic 427	java/lang/Integer:parseInt	(Ljava/lang/String;)I
    //   248: istore 27
    //   250: aload 11
    //   252: invokeinterface 328 1 0
    //   257: invokestatic 430	org/apache/http/util/EntityUtils:toByteArray	(Lorg/apache/http/HttpEntity;)[B
    //   260: astore 28
    //   262: iload 27
    //   264: ifne +39 -> 303
    //   267: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   270: aload 17
    //   272: ifnull -113 -> 159
    //   275: aload 17
    //   277: invokeinterface 341 1 0
    //   282: aconst_null
    //   283: areturn
    //   284: astore 29
    //   286: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   289: aconst_null
    //   290: areturn
    //   291: aconst_null
    //   292: astore 26
    //   294: goto -56 -> 238
    //   297: iconst_0
    //   298: istore 27
    //   300: goto -50 -> 250
    //   303: aload 28
    //   305: arraylength
    //   306: iload 27
    //   308: if_icmpge +27 -> 335
    //   311: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   314: aload 17
    //   316: ifnull -157 -> 159
    //   319: aload 17
    //   321: invokeinterface 341 1 0
    //   326: aconst_null
    //   327: areturn
    //   328: astore 31
    //   330: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   333: aconst_null
    //   334: areturn
    //   335: aload 17
    //   337: ifnull +10 -> 347
    //   340: aload 17
    //   342: invokeinterface 341 1 0
    //   347: aload 28
    //   349: areturn
    //   350: astore 30
    //   352: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   355: goto -8 -> 347
    //   358: astore 20
    //   360: aconst_null
    //   361: astore 21
    //   363: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   366: aload 21
    //   368: ifnull -209 -> 159
    //   371: aload 21
    //   373: invokeinterface 341 1 0
    //   378: aconst_null
    //   379: areturn
    //   380: astore 22
    //   382: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   385: aconst_null
    //   386: areturn
    //   387: astore 16
    //   389: aconst_null
    //   390: astore 17
    //   392: aload 16
    //   394: astore 18
    //   396: aload 17
    //   398: ifnull +10 -> 408
    //   401: aload 17
    //   403: invokeinterface 341 1 0
    //   408: aload 18
    //   410: athrow
    //   411: astore 19
    //   413: invokestatic 336	cn/jpush/android/c/r:g	()V
    //   416: goto -8 -> 408
    //   419: sipush 400
    //   422: iload 12
    //   424: if_icmpne +29 -> 453
    //   427: new 236	java/lang/StringBuilder
    //   430: dup
    //   431: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   434: bipush 8
    //   436: aaload
    //   437: invokespecial 237	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   440: aload_0
    //   441: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   444: invokevirtual 242	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   447: pop
    //   448: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   451: aconst_null
    //   452: areturn
    //   453: sipush 404
    //   456: iload 12
    //   458: if_icmpne +28 -> 486
    //   461: new 236	java/lang/StringBuilder
    //   464: dup
    //   465: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   468: iconst_3
    //   469: aaload
    //   470: invokespecial 237	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   473: aload_0
    //   474: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   477: invokevirtual 242	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   480: pop
    //   481: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   484: aconst_null
    //   485: areturn
    //   486: new 236	java/lang/StringBuilder
    //   489: dup
    //   490: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   493: bipush 6
    //   495: aaload
    //   496: invokespecial 237	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   499: iload 12
    //   501: invokevirtual 299	java/lang/StringBuilder:append	(I)Ljava/lang/StringBuilder;
    //   504: getstatic 104	cn/jpush/android/c/n:z	[Ljava/lang/String;
    //   507: iconst_4
    //   508: aaload
    //   509: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   512: aload_0
    //   513: invokevirtual 241	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   516: invokevirtual 242	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   519: pop
    //   520: invokestatic 218	cn/jpush/android/c/r:b	()V
    //   523: aconst_null
    //   524: areturn
    //   525: astore 18
    //   527: goto -131 -> 396
    //   530: astore 18
    //   532: aload 21
    //   534: astore 17
    //   536: goto -140 -> 396
    //   539: astore 24
    //   541: aload 17
    //   543: astore 21
    //   545: goto -182 -> 363
    //   548: astore 33
    //   550: aconst_null
    //   551: areturn
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	552	0	paramString	String
    //   0	552	1	paramInt	int
    //   0	552	2	paramLong	long
    //   64	112	5	localHttpGet	HttpGet
    //   83	101	6	i	int
    //   161	1	7	localException1	Exception
    //   187	3	8	l	long
    //   197	1	10	localInterruptedException	InterruptedException
    //   97	154	11	localHttpResponse	HttpResponse
    //   116	384	12	j	int
    //   387	6	16	localObject1	Object
    //   137	405	17	localObject2	Object
    //   394	15	18	localObject3	Object
    //   525	1	18	localObject4	Object
    //   530	1	18	localObject5	Object
    //   411	1	19	localIOException1	IOException
    //   358	1	20	localException2	Exception
    //   361	183	21	localObject6	Object
    //   380	1	22	localIOException2	IOException
    //   133	3	23	localHttpEntity	HttpEntity
    //   539	1	24	localException3	Exception
    //   222	8	25	localHeader	org.apache.http.Header
    //   236	57	26	str	String
    //   248	61	27	k	int
    //   260	88	28	arrayOfByte	byte[]
    //   284	1	29	localIOException3	IOException
    //   350	1	30	localIOException4	IOException
    //   328	1	31	localIOException5	IOException
    //   202	1	32	localIOException6	IOException
    //   548	1	33	localException4	Exception
    // Exception table:
    //   from	to	target	type
    //   85	99	161	java/lang/Exception
    //   189	194	197	java/lang/InterruptedException
    //   152	159	202	java/io/IOException
    //   275	282	284	java/io/IOException
    //   319	326	328	java/io/IOException
    //   340	347	350	java/io/IOException
    //   126	135	358	java/lang/Exception
    //   371	378	380	java/io/IOException
    //   126	135	387	finally
    //   401	408	411	java/io/IOException
    //   144	147	525	finally
    //   209	224	525	finally
    //   229	238	525	finally
    //   243	250	525	finally
    //   250	262	525	finally
    //   267	270	525	finally
    //   303	314	525	finally
    //   363	366	530	finally
    //   144	147	539	java/lang/Exception
    //   209	224	539	java/lang/Exception
    //   229	238	539	java/lang/Exception
    //   243	250	539	java/lang/Exception
    //   250	262	539	java/lang/Exception
    //   267	270	539	java/lang/Exception
    //   303	314	539	java/lang/Exception
    //   56	66	548	java/lang/Exception
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.n
 * JD-Core Version:    0.7.1
 */