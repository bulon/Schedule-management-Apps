package cn.jpush.android.c;

import java.io.File;
import java.util.Comparator;

final class l
  implements Comparator<File>
{}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.l
 * JD-Core Version:    0.7.1
 */