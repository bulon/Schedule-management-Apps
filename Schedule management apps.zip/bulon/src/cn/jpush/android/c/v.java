package cn.jpush.android.c;

public final class v
  extends f
{
  private static final String z;
  
  static
  {
    Object localObject1 = "".toCharArray();
    int i = localObject1.length;
    int j = 0;
    Object localObject2;
    int k;
    int m;
    Object localObject3;
    label27:
    int n;
    int i1;
    if (i <= 1)
    {
      localObject2 = localObject1;
      k = j;
      m = i;
      localObject3 = localObject1;
      n = localObject3[j];
      switch (k % 5)
      {
      default: 
        i1 = 60;
      }
    }
    for (;;)
    {
      localObject3[j] = ((char)(i1 ^ n));
      j = k + 1;
      if (m == 0)
      {
        localObject3 = localObject2;
        k = j;
        j = m;
        break label27;
      }
      i = m;
      localObject1 = localObject2;
      if (i > j) {
        break;
      }
      z = new String((char[])localObject1).intern();
      return;
      i1 = 85;
      continue;
      i1 = 109;
      continue;
      i1 = 126;
      continue;
      i1 = 9;
    }
  }
  
  public static String a(String paramString)
  {
    return b(z + paramString, "");
  }
  
  public static void c(String paramString1, String paramString2)
  {
    a(z + paramString1, paramString2);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.v
 * JD-Core Version:    0.7.1
 */