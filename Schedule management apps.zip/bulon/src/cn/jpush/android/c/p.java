package cn.jpush.android.c;

public abstract interface p
{
  public abstract void a(boolean paramBoolean, String paramString);
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.p
 * JD-Core Version:    0.7.1
 */