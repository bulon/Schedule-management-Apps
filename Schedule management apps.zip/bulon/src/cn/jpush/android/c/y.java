package cn.jpush.android.c;

import android.content.Context;
import org.json.JSONArray;

final class y
  implements Runnable
{
  Context a;
  JSONArray b;
  x c;
  
  public y(Context paramContext, JSONArray paramJSONArray, x paramx)
  {
    this.a = paramContext;
    this.b = paramJSONArray;
    this.c = paramx;
  }
  
  public final void run()
  {
    w.b(this.a, this.b, this.c);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.y
 * JD-Core Version:    0.7.1
 */