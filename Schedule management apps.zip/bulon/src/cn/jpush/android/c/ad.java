package cn.jpush.android.c;

import cn.jpush.android.service.PushService;

public final class ad
{
  private static final String[] z;
  private String a;
  private String b;
  private boolean c = false;
  private long d;
  
  static
  {
    String[] arrayOfString1 = new String[3];
    String str1 = ";/\f?XoD?{wvBwid\"Gp~6%";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 12;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "18\001";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "{q";
        j = 2;
        arrayOfString2 = arrayOfString1;
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 22;
        break label96;
        i3 = 2;
        break label96;
        i3 = 33;
        break label96;
        i3 = 31;
        break label96;
        m = 0;
      }
    }
  }
  
  public ad(String paramString1, String paramString2)
  {
    if (PushService.b)
    {
      this.a = paramString1;
      this.b = paramString2;
      this.d = System.currentTimeMillis();
    }
  }
  
  public final void a()
  {
    if (PushService.b)
    {
      new StringBuilder(z[0]).append(this.b).append(z[1]).append(System.currentTimeMillis() - this.d).append(z[2]).toString();
      r.b();
      if (!this.c) {
        this.d = System.currentTimeMillis();
      }
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.ad
 * JD-Core Version:    0.7.1
 */