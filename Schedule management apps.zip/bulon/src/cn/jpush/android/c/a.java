package cn.jpush.android.c;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ActivityInfo;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.content.pm.ResolveInfo;
import android.content.pm.Signature;
import android.content.res.Resources;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Build.VERSION;
import android.os.Bundle;
import android.os.Environment;
import android.os.PowerManager;
import android.os.PowerManager.WakeLock;
import android.provider.Settings.Secure;
import android.provider.Settings.System;
import android.telephony.TelephonyManager;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import cn.jpush.android.a.d;
import cn.jpush.android.api.InstrumentedActivity;
import cn.jpush.android.api.InstrumentedListActivity;
import cn.jpush.android.service.AlarmReceiver;
import cn.jpush.android.service.DownloadService;
import cn.jpush.android.service.PushReceiver;
import cn.jpush.android.service.PushService;
import cn.jpush.android.service.ServiceInterface;
import cn.jpush.android.service.n;
import cn.jpush.android.ui.PushActivity;
import java.io.BufferedReader;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.cert.CertificateFactory;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.UUID;
import javax.security.auth.x500.X500Principal;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class a
{
  public static int a;
  private static List<String> b;
  private static final X500Principal c;
  private static final String d;
  private static final String e;
  private static final ArrayList<String> f;
  private static final ArrayList<String> g;
  private static final ArrayList<String> h;
  private static PushReceiver i;
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[118];
    int j = 0;
    String[] arrayOfString2 = arrayOfString1;
    String str1 = "32\022";
    int k = -1;
    String str2;
    for (;;)
    {
      str2 = z(z(str1));
      switch (k)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "bvFI\037j|\fK\025quKH\003jwL\025'QQv~/F@v~\"MYnd#WWpz7F";
        j = 1;
        arrayOfString2 = arrayOfString1;
        k = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "IHWH\030\\\\GM\031`}k_";
        j = 2;
        arrayOfString2 = arrayOfString1;
        k = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        str1 = "bvFI\037j|\fK\025quKH\003jwL\025'QQv~/P]vo9M_q";
        j = 3;
        arrayOfString2 = arrayOfString1;
        k = 2;
        break;
      case 2: 
        arrayOfString2[j] = str2;
        j = 4;
        arrayOfString2 = arrayOfString1;
        str1 = "D}L^\002blG\0334fnKX\025J|\002H\005`{GH\003#";
        k = 3;
        break;
      case 3: 
        arrayOfString2[j] = str2;
        j = 5;
        str1 = "`wLU\025`lKM\031wa";
        k = 4;
        arrayOfString2 = arrayOfString1;
        break;
      case 4: 
        arrayOfString2[j] = str2;
        j = 6;
        str1 = "fuRO\t#hCI\021nk";
        k = 5;
        arrayOfString2 = arrayOfString1;
        break;
      case 5: 
        arrayOfString2[j] = str2;
        j = 7;
        str1 = ":/\025\017\0246.F\rH1}\027\017I`";
        k = 6;
        arrayOfString2 = arrayOfString1;
        break;
      case 6: 
        arrayOfString2[j] = str2;
        j = 8;
        str1 = "棃浓划雽扠#KfpP朩淣劂绤译仠砙〠炂冋柦眓评惾";
        k = 7;
        arrayOfString2 = arrayOfString1;
        break;
      case 7: 
        arrayOfString2[j] = str2;
        j = 9;
        str1 = "IHWH\030揓礢Ｘ缁屡络讹仁砺";
        k = 8;
        arrayOfString2 = arrayOfString1;
        break;
      case 8: 
        arrayOfString2[j] = str2;
        j = 10;
        str1 = "waR^";
        k = 9;
        arrayOfString2 = arrayOfString1;
        break;
      case 9: 
        arrayOfString2[j] = str2;
        j = 11;
        str1 = "";
        k = 10;
        arrayOfString2 = arrayOfString1;
        break;
      case 10: 
        arrayOfString2[j] = str2;
        j = 12;
        str1 = "b{VR\006jl[";
        k = 11;
        arrayOfString2 = arrayOfString1;
        break;
      case 11: 
        arrayOfString2[j] = str2;
        j = 13;
        str1 = "g}@N\027\\vMO\031eqAZ\004jwL";
        k = 12;
        arrayOfString2 = arrayOfString1;
        break;
      case 12: 
        arrayOfString2[j] = str2;
        j = 14;
        str1 = "mwVR\026j{CO\031lv";
        k = 13;
        arrayOfString2 = arrayOfString1;
        break;
      case 13: 
        arrayOfString2[j] = str2;
        j = 15;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6oz9M";
        k = 14;
        arrayOfString2 = arrayOfString1;
        break;
      case 14: 
        arrayOfString2[j] = str2;
        j = 16;
        str1 = "bvFI\037j|\fR\036w}LO^`yV^\027lj[\025<BMlx8FJ";
        k = 15;
        arrayOfString2 = arrayOfString1;
        break;
      case 15: 
        arrayOfString2[j] = str2;
        j = 17;
        str1 = "jkwK\024blGm\025qkKT\036";
        k = 16;
        arrayOfString2 = arrayOfString1;
        break;
      case 16: 
        arrayOfString2[j] = str2;
        j = 18;
        str1 = "";
        k = 17;
        arrayOfString2 = arrayOfString1;
        break;
      case 17: 
        arrayOfString2[j] = str2;
        j = 19;
        str1 = "awFB";
        k = 18;
        arrayOfString2 = arrayOfString1;
        break;
      case 18: 
        arrayOfString2[j] = str2;
        j = 20;
        str1 = "swU^\002";
        k = 19;
        arrayOfString2 = arrayOfString1;
        break;
      case 19: 
        arrayOfString2[j] = str2;
        j = 21;
        str1 = "N\\\027";
        k = 20;
        arrayOfString2 = arrayOfString1;
        break;
      case 20: 
        arrayOfString2[j] = str2;
        j = 22;
        str1 = "vlD\026H";
        k = 21;
        arrayOfString2 = arrayOfString1;
        break;
      case 21: 
        arrayOfString2[j] = str2;
        j = 23;
        str1 = "";
        k = 22;
        arrayOfString2 = arrayOfString1;
        break;
      case 22: 
        arrayOfString2[j] = str2;
        j = 24;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6tr5T";
        k = 23;
        arrayOfString2 = arrayOfString1;
        break;
      case 23: 
        arrayOfString2[j] = str2;
        j = 25;
        str1 = "IHwh8\\Yrk;FA";
        k = 24;
        arrayOfString2 = arrayOfString1;
        break;
      case 24: 
        arrayOfString2[j] = str2;
        j = 26;
        str1 = "JUgr";
        k = 25;
        arrayOfString2 = arrayOfString1;
        break;
      case 25: 
        arrayOfString2[j] = str2;
        j = 27;
        str1 = "";
        k = 26;
        arrayOfString2 = arrayOfString1;
        break;
      case 26: 
        arrayOfString2[j] = str2;
        j = 28;
        str1 = "BvFI\037j|oZ\036j~GH\004-`OWPnqQH\031m\002I\025rmKI\025g8KU\004fvV\033\026jtV^\002#\"\002X\036-rRN\003k6CU\024qwK_^jvV^\036w6p~ LJv";
        k = 27;
        arrayOfString2 = arrayOfString1;
        break;
      case 27: 
        arrayOfString2[j] = str2;
        j = 29;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6`t?WGat=STgo5G";
        k = 28;
        arrayOfString2 = arrayOfString1;
        break;
      case 28: 
        arrayOfString2[j] = str2;
        j = 30;
        str1 = "T}\002I\025`wOV\025m|\002B\037v8C_\024#lJ^Ps}PV\031pkKT\036#5\002";
        k = 29;
        arrayOfString2 = arrayOfString1;
        break;
      case 29: 
        arrayOfString2[j] = str2;
        j = 31;
        str1 = "";
        k = 30;
        arrayOfString2 = arrayOfString1;
        break;
      case 30: 
        arrayOfString2[j] = str2;
        j = 32;
        str1 = "BvFI\037j|oZ\036j~GH\004-`OWPnqQH\031m\002I\025rmKI\025g8P^\023fqT^\00298";
        k = 31;
        arrayOfString2 = arrayOfString1;
        break;
      case 31: 
        arrayOfString2[j] = str2;
        j = 33;
        str1 = "BvFI\037j|oZ\036j~GH\004-`OWPnqQH\031m\002I\025rmKI\025g8KU\004fvV\033\026jtV^\002#~MIPSmQS#fjTR\023f\"\002X\036-rRN\003k6CU\024qwK_^jvV^\036w6p~7JKv~\"";
        k = 32;
        arrayOfString2 = arrayOfString1;
        break;
      case 32: 
        arrayOfString2[j] = str2;
        j = 34;
        str1 = "";
        k = 33;
        arrayOfString2 = arrayOfString1;
        break;
      case 33: 
        arrayOfString2[j] = str2;
        j = 35;
        str1 = "BvFI\037j|wO\031o";
        k = 34;
        arrayOfString2 = arrayOfString1;
        break;
      case 34: 
        arrayOfString2[j] = str2;
        j = 36;
        str1 = "G}T^\034lhGIPppMN\034g8Q^\004#YRK;fa\002R\036#YL_\002lqFv\021mqD^\003w6ZV\034";
        k = 35;
        arrayOfString2 = arrayOfString1;
        break;
      case 35: 
        arrayOfString2[j] = str2;
        j = 37;
        str1 = "BvFI\037j|oZ\036j~GH\004-`OWPnqQH\031m\002I\025rmKI\025g8Q^\002uqA^J#";
        k = 36;
        arrayOfString2 = arrayOfString1;
        break;
      case 36: 
        arrayOfString2[j] = str2;
        j = 38;
        str1 = "-hGI\035jkQR\037m6hk%PP}v5PKc|5";
        k = 37;
        arrayOfString2 = arrayOfString1;
        break;
      case 37: 
        arrayOfString2[j] = str2;
        j = 39;
        str1 = "BvFI\037j|oZ\036j~GH\004-`OWPnqQH\031m\002I\025rmKI\025g8KU\004fvV\033\026jtV^\002#~MIPSmQS\"f{GR\006fj\030\033\023m6HK\005pp\fZ\036gjMR\024-qLO\025ml\fu?WQdr3BLkt>\\Jgx5JNg/SJmc)";
        k = 38;
        arrayOfString2 = arrayOfString1;
        break;
      case 38: 
        arrayOfString2[j] = str2;
        j = 40;
        str1 = "ZwW\033\003kwWW\024#uCP\025#uCR\036#yAO\031uqVBPf`V^\036gk\002r\036plPN\035fvV^\024B{VR\006jl[\033XIHWH\030*4\002T\004k}PL\031p}\002B\037v8UR\034o8LT\004#kG^PvkGIP`tKX\033#yL_PvkGIPb{VR\006f8VR\035f8QO\021ql\002T\036#jGK\037ql\002R\036#HMI\004bt\f\033";
        k = 39;
        arrayOfString2 = arrayOfString1;
        break;
      case 39: 
        arrayOfString2[j] = str2;
        j = 41;
        str1 = "b{VR\037m\"AS\025`stZ\034j|oZ\036j~GH\004";
        k = 40;
        arrayOfString2 = arrayOfString1;
        break;
      case 40: 
        arrayOfString2[j] = str2;
        j = 42;
        str1 = "";
        k = 41;
        arrayOfString2 = arrayOfString1;
        break;
      case 41: 
        arrayOfString2[j] = str2;
        j = 43;
        str1 = "SmQS\"f{GR\006fj\002H\030lmN_PmwV\033\030bnG\033\031mlGU\004#~KW\004fj\002\026]#yL_\002lqF\025\031mlGU\004-yAO\031lv\fy?LL}x?NHn~$F\\\016\033 o}CH\025#jGV\037u}\002O\030f8KU\004fvV\033\026jtV^\002#qL\0331m|PT\031gUCU\031e}QO^{uN";
        k = 42;
        arrayOfString2 = arrayOfString1;
        break;
      case 42: 
        arrayOfString2[j] = str2;
        j = 44;
        str1 = "";
        k = 43;
        arrayOfString2 = arrayOfString1;
        break;
      case 43: 
        arrayOfString2[j] = str2;
        j = 45;
        str1 = "";
        k = 44;
        arrayOfString2 = arrayOfString1;
        break;
      case 44: 
        arrayOfString2[j] = str2;
        j = 46;
        str1 = "/8MO\030fjUR\003f8[T\005#{CUPmwV\033\034l{CO\025#lJ^Pg}TR\023fk\f";
        k = 45;
        arrayOfString2 = arrayOfString1;
        break;
      case 45: 
        arrayOfString2[j] = str2;
        j = 47;
        str1 = "ssE";
        k = 46;
        arrayOfString2 = arrayOfString1;
        break;
      case 46: 
        arrayOfString2[j] = str2;
        j = 48;
        str1 = "myO^";
        k = 47;
        arrayOfString2 = arrayOfString1;
        break;
      case 47: 
        arrayOfString2[j] = str2;
        j = 49;
        str1 = "u}Pd\023l|G";
        k = 48;
        arrayOfString2 = arrayOfString1;
        break;
      case 48: 
        arrayOfString2[j] = str2;
        j = 50;
        str1 = "u}Pd\036buG";
        k = 49;
        arrayOfString2 = arrayOfString1;
        break;
      case 49: 
        arrayOfString2[j] = str2;
        j = 51;
        str1 = "bvFI\037j|}R\024";
        k = 50;
        arrayOfString2 = arrayOfString1;
        break;
      case 50: 
        arrayOfString2[j] = str2;
        j = 52;
        str1 = ",hPT\023,{RN\031m~M";
        k = 51;
        arrayOfString2 = arrayOfString1;
        break;
      case 51: 
        arrayOfString2[j] = str2;
        j = 53;
        str1 = "SjMX\025pkMI";
        k = 52;
        arrayOfString2 = arrayOfString1;
        break;
      case 52: 
        arrayOfString2[j] = str2;
        j = 54;
        str1 = "smQSPwqO^Pjk\002Ａ";
        k = 53;
        arrayOfString2 = arrayOfString1;
        break;
      case 53: 
        arrayOfString2[j] = str2;
        j = 55;
        str1 = "`tMH\025smQS";
        k = 54;
        arrayOfString2 = arrayOfString1;
        break;
      case 54: 
        arrayOfString2[j] = str2;
        j = 56;
        str1 = "_F";
        k = 55;
        arrayOfString2 = arrayOfString1;
        break;
      case 55: 
        arrayOfString2[j] = str2;
        j = 57;
        str1 = "smQS\004juG";
        k = 56;
        arrayOfString2 = arrayOfString1;
        break;
      case 56: 
        arrayOfString2[j] = str2;
        j = 58;
        str1 = "";
        k = 57;
        arrayOfString2 = arrayOfString1;
        break;
      case 57: 
        arrayOfString2[j] = str2;
        j = 59;
        str1 = "NyKUP`tCH\003#qQ\033";
        k = 58;
        arrayOfString2 = arrayOfString1;
        break;
      case 58: 
        arrayOfString2[j] = str2;
        j = 60;
        str1 = "SjG]\003EqN^";
        k = 59;
        arrayOfString2 = arrayOfString1;
        break;
      case 59: 
        arrayOfString2[j] = str2;
        j = 61;
        str1 = "h}[";
        k = 60;
        arrayOfString2 = arrayOfString1;
        break;
      case 60: 
        arrayOfString2[j] = str2;
        j = 62;
        str1 = "smQS/v|K_";
        k = 61;
        arrayOfString2 = arrayOfString1;
        break;
      case 61: 
        arrayOfString2[j] = str2;
        j = 63;
        str1 = "DwV\033\003g{CI\024#~KW\025#kCM\025g8W_\031g8\017\033";
        k = 62;
        arrayOfString2 = arrayOfString1;
        break;
      case 62: 
        arrayOfString2[j] = str2;
        j = 64;
        str1 = "spMU\025";
        k = 63;
        arrayOfString2 = arrayOfString1;
        break;
      case 63: 
        arrayOfString2[j] = str2;
        j = 65;
        str1 = "bvFI\037j|\fK\025quKH\003jwL\025\"FYfd KWl~/PLco5";
        k = 64;
        arrayOfString2 = arrayOfString1;
        break;
      case 64: 
        arrayOfString2[j] = str2;
        j = 66;
        str1 = "stW\\\027f|";
        k = 65;
        arrayOfString2 = arrayOfString1;
        break;
      case 65: 
        arrayOfString2[j] = str2;
        j = 67;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6`z$W]pb/@Pcu7F\\";
        k = 66;
        arrayOfString2 = arrayOfString1;
        break;
      case 66: 
        arrayOfString2[j] = str2;
        j = 68;
        str1 = "plCO\005p";
        k = 67;
        arrayOfString2 = arrayOfString1;
        break;
      case 67: 
        arrayOfString2[j] = str2;
        j = 69;
        str1 = "IHWH\030揓礢Ｘ匾命咏YRK;fa丯匂鄽";
        k = 68;
        arrayOfString2 = arrayOfString1;
        break;
      case 68: 
        arrayOfString2[j] = str2;
        j = 70;
        str1 = "";
        k = 69;
        arrayOfString2 = arrayOfString1;
        break;
      case 69: 
        arrayOfString2[j] = str2;
        j = 71;
        str1 = "wwCH\004W}ZO";
        k = 70;
        arrayOfString2 = arrayOfString1;
        break;
      case 70: 
        arrayOfString2[j] = str2;
        j = 72;
        str1 = "NYa\033\021g|P\033\031m~M\026].5\002";
        k = 71;
        arrayOfString2 = arrayOfString1;
        break;
      case 71: 
        arrayOfString2[j] = str2;
        j = 73;
        str1 = "tqDR";
        k = 72;
        arrayOfString2 = arrayOfString1;
        break;
      case 72: 
        arrayOfString2[j] = str2;
        j = 74;
        str1 = "bvFI\037j|\fK\025quKH\003jwL\0251@[gh#\\Ok}9\\Kvz$F";
        k = 73;
        arrayOfString2 = arrayOfString1;
        break;
      case 73: 
        arrayOfString2[j] = str2;
        j = 75;
        str1 = "juGR";
        k = 74;
        arrayOfString2 = arrayOfString1;
        break;
      case 74: 
        arrayOfString2[j] = str2;
        j = 76;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6rz3HYe~/B\\f~4";
        k = 75;
        arrayOfString2 = arrayOfString1;
        break;
      case 75: 
        arrayOfString2[j] = str2;
        j = 77;
        str1 = "syAP\021d}";
        k = 76;
        arrayOfString2 = arrayOfString1;
        break;
      case 76: 
        arrayOfString2[j] = str2;
        j = 78;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6rz3HYe~/Q]ot&F\\";
        k = 77;
        arrayOfString2 = arrayOfString1;
        break;
      case 77: 
        arrayOfString2[j] = str2;
        j = 79;
        str1 = "bvFI\037j|\fU\025w6AT\036m6at>M]ao9UQvb/@Pcu7F";
        k = 78;
        arrayOfString2 = arrayOfString1;
        break;
      case 78: 
        arrayOfString2[j] = str2;
        j = 80;
        str1 = "bvFI\037j|\fR\036w}LO^b{VR\037m6wh5QGri5P]lo";
        k = 79;
        arrayOfString2 = arrayOfString1;
        break;
      case 79: 
        arrayOfString2[j] = str2;
        j = 81;
        str1 = "vjN";
        k = 80;
        arrayOfString2 = arrayOfString1;
        break;
      case 80: 
        arrayOfString2[j] = str2;
        j = 82;
        str1 = "g}TR\023f";
        k = 81;
        arrayOfString2 = arrayOfString1;
        break;
      case 81: 
        arrayOfString2[j] = str2;
        j = 83;
        str1 = "bvFI\037j|q_\033U}PH\031lv";
        k = 82;
        arrayOfString2 = arrayOfString1;
        break;
      case 82: 
        arrayOfString2[j] = str2;
        j = 84;
        str1 = "ayQ^\022bvF";
        k = 83;
        arrayOfString2 = arrayOfString1;
        break;
      case 83: 
        arrayOfString2[j] = str2;
        j = 85;
        str1 = "dkO\025\006fjQR\037m6@Z\003fzCU\024";
        k = 84;
        arrayOfString2 = arrayOfString1;
        break;
      case 84: 
        arrayOfString2[j] = str2;
        j = 86;
        str1 = "`pCU\036ft";
        k = 85;
        arrayOfString2 = arrayOfString1;
        break;
      case 85: 
        arrayOfString2[j] = str2;
        j = 87;
        str1 = "m}VL\037qs";
        k = 86;
        arrayOfString2 = arrayOfString1;
        break;
      case 86: 
        arrayOfString2[j] = str2;
        j = 88;
        str1 = "nwF^\034";
        k = 87;
        arrayOfString2 = arrayOfString1;
        break;
      case 87: 
        arrayOfString2[j] = str2;
        j = 89;
        str1 = "plCI\004NqLH";
        k = 88;
        arrayOfString2 = arrayOfString1;
        break;
      case 88: 
        arrayOfString2[j] = str2;
        j = 90;
        str1 = "fvFO=jvQ";
        k = 89;
        arrayOfString2 = arrayOfString1;
        break;
      case 89: 
        arrayOfString2[j] = str2;
        j = 91;
        str1 = "pqN^\036`}rN\003kLKV\025";
        k = 90;
        arrayOfString2 = arrayOfString1;
        break;
      case 90: 
        arrayOfString2[j] = str2;
        j = 92;
        str1 = "fvFs\037vj";
        k = 91;
        arrayOfString2 = arrayOfString1;
        break;
      case 91: 
        arrayOfString2[j] = str2;
        j = 93;
        str1 = "plCI\004KwWI";
        k = 92;
        arrayOfString2 = arrayOfString1;
        break;
      case 92: 
        arrayOfString2[j] = str2;
        j = 94;
        str1 = "[6\027\013I";
        k = 93;
        arrayOfString2 = arrayOfString1;
        break;
      case 93: 
        arrayOfString2[j] = str2;
        j = 95;
        str1 = "SmQS";
        k = 94;
        arrayOfString2 = arrayOfString1;
        break;
      case 94: 
        arrayOfString2[j] = str2;
        j = 96;
        str1 = "MMnwP`wLO\025{l";
        k = 95;
        arrayOfString2 = arrayOfString1;
        break;
      case 95: 
        arrayOfString2[j] = str2;
        j = 97;
        str1 = "";
        k = 96;
        arrayOfString2 = arrayOfString1;
        break;
      case 96: 
        arrayOfString2[j] = str2;
        j = 98;
        str1 = "@mPI\025ml\002K\033#qLH\004btN^\024#hCO\03098";
        k = 97;
        arrayOfString2 = arrayOfString1;
        break;
      case 97: 
        arrayOfString2[j] = str2;
        j = 99;
        str1 = "'<";
        k = 98;
        arrayOfString2 = arrayOfString1;
        break;
      case 98: 
        arrayOfString2[j] = str2;
        j = 100;
        str1 = ",|CO\021,yRK_";
        k = 99;
        arrayOfString2 = arrayOfString1;
        break;
      case 99: 
        arrayOfString2[j] = str2;
        j = 101;
        str1 = "";
        k = 100;
        arrayOfString2 = arrayOfString1;
        break;
      case 100: 
        arrayOfString2[j] = str2;
        j = 102;
        str1 = "";
        k = 101;
        arrayOfString2 = arrayOfString1;
        break;
      case 101: 
        arrayOfString2[j] = str2;
        j = 103;
        str1 = "";
        k = 102;
        arrayOfString2 = arrayOfString1;
        break;
      case 102: 
        arrayOfString2[j] = str2;
        j = 104;
        str1 = "";
        k = 103;
        arrayOfString2 = arrayOfString1;
        break;
      case 103: 
        arrayOfString2[j] = str2;
        j = 105;
        str1 = "&k\fK\025quKH\003jwL\025:SMqs/N]qh1D]";
        k = 104;
        arrayOfString2 = arrayOfString1;
        break;
      case 104: 
        arrayOfString2[j] = str2;
        j = 106;
        str1 = "";
        k = 105;
        arrayOfString2 = arrayOfString1;
        break;
      case 105: 
        arrayOfString2[j] = str2;
        j = 107;
        str1 = "";
        k = 106;
        arrayOfString2 = arrayOfString1;
        break;
      case 106: 
        arrayOfString2[j] = str2;
        j = 108;
        str1 = "";
        k = 107;
        arrayOfString2 = arrayOfString1;
        break;
      case 107: 
        arrayOfString2[j] = str2;
        j = 109;
        str1 = "";
        k = 108;
        arrayOfString2 = arrayOfString1;
        break;
      case 108: 
        arrayOfString2[j] = str2;
        j = 110;
        str1 = "";
        k = 109;
        arrayOfString2 = arrayOfString1;
        break;
      case 109: 
        arrayOfString2[j] = str2;
        j = 111;
        str1 = "nwWU\004f|";
        k = 110;
        arrayOfString2 = arrayOfString1;
        break;
      case 110: 
        arrayOfString2[j] = str2;
        j = 112;
        str1 = "q}ER\003wjCO\031lv}R\024";
        k = 111;
        arrayOfString2 = arrayOfString1;
        break;
      case 111: 
        arrayOfString2[j] = str2;
        j = 113;
        str1 = "DwV\033\003g{CI\024#~KW\025#kCM\025g8F^\006j{Gr\024#5\002";
        k = 112;
        arrayOfString2 = arrayOfString1;
        break;
      case 112: 
        arrayOfString2[j] = str2;
        j = 114;
        str1 = "gyVZ";
        k = 113;
        arrayOfString2 = arrayOfString1;
        break;
      case 113: 
        arrayOfString2[j] = str2;
        j = 115;
        str1 = "jlKV\025";
        k = 114;
        arrayOfString2 = arrayOfString1;
        break;
      case 114: 
        arrayOfString2[j] = str2;
        j = 116;
        str1 = "VvIU\037tv";
        k = 115;
        arrayOfString2 = arrayOfString1;
        break;
      case 115: 
        arrayOfString2[j] = str2;
        j = 117;
        str1 = "@V\037z\036gjMR\024#\\GY\005d4m\0061m|PT\031g4a\006%P";
        k = 116;
        arrayOfString2 = arrayOfString1;
      }
    }
    arrayOfString2[j] = str2;
    z = arrayOfString1;
    ArrayList localArrayList1 = new ArrayList();
    b = localArrayList1;
    ArrayList localArrayList2 = localArrayList1;
    String str3 = "0-\032\rG0(\023\bG:-\032\002E";
    int m = -1;
    String str4;
    for (;;)
    {
      str4 = z(z(str3));
      switch (m)
      {
      default: 
        localArrayList2.add(str4);
        List localList = b;
        String str5 = "3(\026\002I:(\023\013F7(\022\013@";
        int n = -1;
        StringBuilder localStringBuilder;
        String str8;
        for (;;)
        {
          String str6 = z(z(str5));
          switch (n)
          {
          default: 
            localList.add(str6);
            localList = b;
            str5 = "3(\022\013@3(\022\013@3(\022\013";
            n = 0;
            break;
          case 1: 
            localList.add(str6);
            c = new X500Principal(z[117]);
            localStringBuilder = new StringBuilder().append(Environment.getExternalStorageDirectory().getPath());
            String str7 = ",|CO\021,6RN\003kGW_\031g";
            for (int i1 = -1;; i1 = 0)
            {
              str8 = z(z(str7));
              switch (i1)
              {
              default: 
                d = str8;
                localStringBuilder = new StringBuilder().append(Environment.getExternalStorageDirectory().getPath());
                str7 = ",|CO\021,6RN\003kGF^\006j{GR\024";
              }
            }
          case 0: 
            localList.add(str6);
            localList = b;
            str5 = "3(\022\013@3(\022\013@3(\022\013@";
            n = 1;
          }
        }
        e = str8;
        a = 1;
        f = new ArrayList();
        g = new ArrayList();
        localArrayList2 = f;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\0259MLgi>FL";
        m = 0;
        break;
      case 0: 
        localArrayList2.add(str4);
        localArrayList2 = f;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\025'BSgd<L[i";
        m = 1;
        break;
      case 1: 
        localArrayList2.add(str4);
        f.add(z[1]);
        localArrayList2 = f;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\0251@[gh#\\Vgo'LJid#WYv~";
        m = 2;
        break;
      case 2: 
        localArrayList2.add(str4);
        localArrayList2 = g;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\025&JZpz$F";
        m = 3;
        break;
      case 3: 
        localArrayList2.add(str4);
        localArrayList2 = g;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\0253KYl|5\\Ok}9\\Kvz$F";
        m = 4;
        break;
      case 4: 
        localArrayList2.add(str4);
        localArrayList2 = new ArrayList();
        h = localArrayList2;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\0251@[gh#\\^ku5\\Tmx1WQmu";
        m = 5;
        break;
      case 5: 
        localArrayList2.add(str4);
        localArrayList2 = h;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\0251@[gh#\\[mz\"P]}w?@Yvr?M";
        m = 6;
        break;
      case 6: 
        localArrayList2.add(str4);
        localArrayList2 = h;
        str3 = "bvFI\037j|\fK\025quKH\003jwL\0251@[gh#\\Tmx1WQmu/F@vi1\\[mv=BVfh";
        m = 7;
      }
    }
    localArrayList2.add(str4);
    h.add(z[74]);
  }
  
  private static String A(Context paramContext)
  {
    String str = k(paramContext);
    if ((!ac.a(str)) && (d(str))) {}
    label79:
    for (;;)
    {
      return str;
      if (Build.VERSION.SDK_INT >= 9) {}
      for (str = Build.SERIAL;; str = null)
      {
        if ((!ac.a(str)) && (d(str))) {
          break label79;
        }
        str = h(paramContext, " ");
        if ((!ac.a(str)) && (d(str))) {
          break;
        }
        return UUID.randomUUID().toString();
      }
    }
  }
  
  private static boolean B(Context paramContext)
  {
    try
    {
      String str = Settings.System.getString(paramContext.getContentResolver(), z[26]);
      if (TextUtils.isEmpty(str)) {
        str = h(paramContext, "");
      }
      Settings.System.putString(paramContext.getContentResolver(), z[26], str);
      r.c();
      return true;
    }
    catch (Exception localException)
    {
      r.e();
    }
    return false;
  }
  
  private static boolean C(Context paramContext)
  {
    try
    {
      Intent localIntent = new Intent(z[15]);
      localIntent.setPackage(paramContext.getPackageName());
      localIntent.addCategory(z[16]);
      ActivityInfo localActivityInfo = paramContext.getPackageManager().resolveActivity(localIntent, 0).activityInfo;
      if (localActivityInfo != null)
      {
        Class localClass = Class.forName(localActivityInfo.name);
        if (localClass == null) {
          return false;
        }
        if (!InstrumentedActivity.class.isAssignableFrom(localClass))
        {
          boolean bool = InstrumentedListActivity.class.isAssignableFrom(localClass);
          if (!bool) {}
        }
        else
        {
          return true;
        }
      }
    }
    catch (Exception localException) {}
    return false;
  }
  
  private static void D(Context paramContext)
  {
    
    if (i == null) {
      i = new PushReceiver();
    }
    paramContext.registerReceiver(i, new IntentFilter(z[80]));
    paramContext.registerReceiver(i, new IntentFilter(z[79]));
    try
    {
      IntentFilter localIntentFilter1 = new IntentFilter(z[76]);
      localIntentFilter1.addDataScheme(z[77]);
      IntentFilter localIntentFilter2 = new IntentFilter(z[78]);
      localIntentFilter2.addDataScheme(z[77]);
      IntentFilter localIntentFilter3 = new IntentFilter(z[44]);
      localIntentFilter3.setPriority(1000);
      localIntentFilter3.addCategory(paramContext.getPackageName());
      paramContext.registerReceiver(i, localIntentFilter1);
      paramContext.registerReceiver(i, localIntentFilter2);
      paramContext.registerReceiver(i, localIntentFilter3);
      return;
    }
    catch (Exception localException) {}
  }
  
  public static int a(byte paramByte)
  {
    return paramByte & 0xFF;
  }
  
  public static int a(Context paramContext, float paramFloat)
  {
    return (int)(paramFloat * paramContext.getResources().getDisplayMetrics().density);
  }
  
  public static int a(byte[] paramArrayOfByte)
  {
    if ((paramArrayOfByte == null) || (paramArrayOfByte.length < 6)) {
      return -1;
    }
    return 0xFF & paramArrayOfByte[3];
  }
  
  public static Intent a(Context paramContext, d paramd, boolean paramBoolean)
  {
    Intent localIntent = new Intent();
    localIntent.putExtra(z[17], paramBoolean);
    localIntent.putExtra(z[19], paramd);
    localIntent.setAction(z[18]);
    localIntent.addCategory(paramContext.getPackageName());
    localIntent.addFlags(268435456);
    return localIntent;
  }
  
  public static String a(Context paramContext)
  {
    DisplayMetrics localDisplayMetrics = paramContext.getResources().getDisplayMetrics();
    if (localDisplayMetrics == null) {
      return z[0];
    }
    int j = localDisplayMetrics.widthPixels;
    int k = localDisplayMetrics.heightPixels;
    return j + "*" + k;
  }
  
  public static String a(Context paramContext, String paramString)
  {
    String str1 = Build.VERSION.RELEASE + "," + Integer.toString(Build.VERSION.SDK_INT);
    String str2 = Build.MODEL;
    String str3 = cn.jpush.android.service.m.a(paramContext, z[85], z[84]);
    String str4 = Build.DEVICE;
    String str5;
    StringBuilder localStringBuilder;
    String str6;
    int j;
    if (ac.a(cn.jpush.android.a.e))
    {
      str5 = " ";
      localStringBuilder = new StringBuilder().append(str1).append(z[99]).append(str2).append(z[99]).append(str3).append(z[99]).append(str4).append(z[99]).append(str5).append(z[99]).append(paramString).append(z[99]);
      str6 = paramContext.getApplicationInfo().sourceDir;
      if (!ac.a(str6)) {
        break label229;
      }
      r.e();
      j = 0;
      label186:
      if (j == 0) {
        break label303;
      }
    }
    label303:
    for (int k = 1;; k = 0)
    {
      return k + z[99] + a(paramContext);
      str5 = cn.jpush.android.a.e;
      break;
      label229:
      new StringBuilder(z[98]).append(str6).toString();
      r.b();
      if (str6.startsWith(z[101]))
      {
        j = 1;
        break label186;
      }
      if (str6.startsWith(z[100]))
      {
        j = 0;
        break label186;
      }
      r.c();
      j = 0;
      break label186;
    }
  }
  
  public static String a(String paramString)
  {
    int j = 0;
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance(z[21]);
      char[] arrayOfChar = paramString.toCharArray();
      byte[] arrayOfByte1 = new byte[arrayOfChar.length];
      for (int k = 0; k < arrayOfChar.length; k++) {
        arrayOfByte1[k] = ((byte)arrayOfChar[k]);
      }
      byte[] arrayOfByte2 = localMessageDigest.digest(arrayOfByte1);
      StringBuffer localStringBuffer = new StringBuffer();
      while (j < arrayOfByte2.length)
      {
        int m = 0xFF & arrayOfByte2[j];
        if (m < 16) {
          localStringBuffer.append("0");
        }
        localStringBuffer.append(Integer.toHexString(m));
        j++;
      }
      String str = localStringBuffer.toString();
      return str;
    }
    catch (Exception localException)
    {
      r.b();
    }
    return "";
  }
  
  public static JSONObject a(String paramString, JSONArray paramJSONArray)
  {
    if ((paramJSONArray == null) || (paramJSONArray.length() == 0)) {
      return null;
    }
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put(z[114], paramJSONArray);
      localJSONObject.put(z[10], paramString);
      localJSONObject.put(z[115], System.currentTimeMillis() / 1000L);
      return localJSONObject;
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
    }
    return null;
  }
  
  public static void a(Context paramContext, d paramd)
  {
    try
    {
      Intent localIntent = new Intent(z[102]);
      localIntent.putExtra(z[109], paramd.m);
      localIntent.putExtra(z[104], paramd.h);
      localIntent.putExtra(z[110], paramd.i);
      localIntent.putExtra(z[106], paramd.j);
      localIntent.putExtra(z[58], paramd.k);
      localIntent.putExtra(z[103], paramd.c);
      if (paramd.f()) {
        localIntent.putExtra(z[107], paramd.T);
      }
      localIntent.addCategory(paramd.l);
      String str1 = z[105];
      Object[] arrayOfObject1 = new Object[1];
      arrayOfObject1[0] = paramd.l;
      paramContext.sendBroadcast(localIntent, String.format(str1, arrayOfObject1));
      StringBuilder localStringBuilder = new StringBuilder(z[108]);
      String str2 = z[105];
      Object[] arrayOfObject2 = new Object[1];
      arrayOfObject2[0] = paramd.l;
      localStringBuilder.append(String.format(str2, arrayOfObject2)).toString();
      r.c();
      ServiceInterface.a(paramd.c, 1018, paramContext);
      return;
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
    }
  }
  
  public static void a(Context paramContext, String paramString1, String paramString2, int paramInt)
  {
    Intent localIntent = new Intent(paramContext, PushReceiver.class);
    localIntent.setAction(z[11]);
    localIntent.putExtra(z[13], true);
    localIntent.putExtra(z[12], paramString2);
    localIntent.putExtra(z[10], paramInt);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent, 134217728);
    NotificationManager localNotificationManager = (NotificationManager)paramContext.getSystemService(z[14]);
    int j = -1;
    try
    {
      j = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 256).applicationInfo.icon;
      label116:
      if (j < 0) {
        j = 17301586;
      }
      String str1 = z[9];
      String str2 = z[8];
      Notification localNotification = new Notification(j, paramString1, System.currentTimeMillis());
      localNotification.flags = 34;
      localNotification.setLatestEventInfo(paramContext, str1, str2, localPendingIntent);
      localNotificationManager.notify(paramString1.hashCode(), localNotification);
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      break label116;
    }
  }
  
  public static boolean a()
  {
    boolean bool = Environment.getExternalStorageState().equals(z[111]);
    if (!bool) {
      r.b();
    }
    return bool;
  }
  
  public static boolean a(Context paramContext, String paramString1, String paramString2)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException(z[96]);
    }
    if (TextUtils.isEmpty(paramString1))
    {
      new StringBuilder(z[97]).append(paramString1).toString();
      r.d();
      return false;
    }
    Intent localIntent = m(paramContext, paramString1);
    if (localIntent == null)
    {
      try
      {
        if (TextUtils.isEmpty(paramString2))
        {
          r.b();
          return false;
        }
      }
      catch (Exception localException)
      {
        r.g();
        return false;
      }
      localIntent = new Intent();
      localIntent.setClassName(paramString1, paramString2);
      localIntent.addCategory(z[16]);
    }
    localIntent.setFlags(268435456);
    paramContext.startActivity(localIntent);
    return true;
  }
  
  public static boolean a(Context paramContext, String paramString, boolean paramBoolean)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    Intent localIntent = new Intent(paramString);
    localIntent.addCategory(paramContext.getPackageName());
    return !localPackageManager.queryBroadcastReceivers(localIntent, 0).isEmpty();
  }
  
  public static int b(byte[] paramArrayOfByte)
  {
    int j = 0;
    if (paramArrayOfByte != null)
    {
      int k = paramArrayOfByte.length;
      j = 0;
      if (k >= 6) {
        break label19;
      }
    }
    for (;;)
    {
      return j;
      label19:
      int m = 0;
      while (m < 2)
      {
        int n = (j << 8) + (0xFF & paramArrayOfByte[m]);
        m++;
        j = n;
      }
    }
  }
  
  public static String b(Context paramContext, String paramString)
  {
    String str1 = Build.VERSION.RELEASE + "," + Integer.toString(Build.VERSION.SDK_INT);
    String str2 = Build.MODEL;
    String str3 = cn.jpush.android.service.m.a(paramContext, z[85], z[84]);
    String str4 = Build.DEVICE;
    String str5;
    if (ac.a(cn.jpush.android.a.e)) {
      str5 = " ";
    }
    for (;;)
    {
      String str6 = d(paramContext);
      JSONObject localJSONObject = new JSONObject();
      try
      {
        localJSONObject.put(z[83], str1);
        localJSONObject.put(z[88], str2);
        localJSONObject.put(z[84], str3);
        localJSONObject.put(z[82], str4);
        localJSONObject.put(z[86], str5);
        localJSONObject.put(z[87], str6);
        localJSONObject.put(z[81], paramString);
        label183:
        return localJSONObject.toString();
        str5 = cn.jpush.android.a.e;
      }
      catch (JSONException localJSONException)
      {
        break label183;
      }
    }
  }
  
  public static String b(String paramString)
  {
    try
    {
      byte[] arrayOfByte = MessageDigest.getInstance(z[21]).digest(paramString.getBytes(z[22]));
      StringBuffer localStringBuffer = new StringBuffer();
      for (int j = 0; j < arrayOfByte.length; j++)
      {
        int k = 0xFF & arrayOfByte[j];
        if (k < 16) {
          localStringBuffer.append("0");
        }
        localStringBuffer.append(Integer.toHexString(k));
      }
      String str = localStringBuffer.toString();
      return str;
    }
    catch (Exception localException)
    {
      r.b();
    }
    return "";
  }
  
  public static void b()
  {
    PowerManager.WakeLock localWakeLock = n.a().b();
    if (localWakeLock != null)
    {
      if (localWakeLock.isHeld()) {
        localWakeLock.release();
      }
      r.b();
    }
  }
  
  public static void b(Context paramContext, String paramString1, String paramString2)
  {
    if (!i(paramContext)) {
      return;
    }
    r.b();
    Intent localIntent = new Intent(paramContext, PushReceiver.class);
    localIntent.setAction(z[11]);
    localIntent.putExtra(z[13], true);
    localIntent.putExtra(z[71], paramString2);
    PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent, 134217728);
    NotificationManager localNotificationManager = (NotificationManager)paramContext.getSystemService(z[14]);
    int j = -1;
    try
    {
      j = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 256).applicationInfo.icon;
      label109:
      if (j < 0) {
        j = 17301586;
      }
      String str1 = z[69];
      String str2 = z[70];
      Notification localNotification = new Notification(j, paramString1, System.currentTimeMillis());
      localNotification.flags = 34;
      localNotification.setLatestEventInfo(paramContext, str1, str2, localPendingIntent);
      localNotificationManager.notify(paramString1.hashCode(), localNotification);
      return;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      break label109;
    }
  }
  
  public static boolean b(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService(z[5])).getActiveNetworkInfo();
    return (localNetworkInfo != null) && (localNetworkInfo.isConnected());
  }
  
  private static boolean b(Context paramContext, String paramString, boolean paramBoolean)
  {
    return !paramContext.getPackageManager().queryIntentServices(new Intent(paramString), 0).isEmpty();
  }
  
  public static String c()
  {
    StringBuffer localStringBuffer = new StringBuffer();
    BufferedReader localBufferedReader;
    if (new File(z[52]).exists()) {
      try
      {
        localBufferedReader = new BufferedReader(new FileReader(new File(z[52])));
        for (;;)
        {
          String str = localBufferedReader.readLine();
          if (str == null) {
            break;
          }
          if (str.contains(z[53]))
          {
            int j = str.indexOf(":");
            if ((j >= 0) && (j < -1 + str.length())) {
              localStringBuffer.append(str.substring(j + 1).trim());
            }
          }
        }
        return localStringBuffer.toString();
      }
      catch (IOException localIOException) {}
    }
    for (;;)
    {
      localBufferedReader.close();
    }
  }
  
  public static short c(Context paramContext)
  {
    return z.b(paramContext);
  }
  
  public static void c(String paramString)
  {
    b.add(paramString);
  }
  
  public static boolean c(Context paramContext, String paramString)
  {
    if ((paramContext == null) || (TextUtils.isEmpty(paramString))) {
      throw new IllegalArgumentException(z[6]);
    }
    return paramContext.getPackageManager().checkPermission(paramString, paramContext.getPackageName()) == 0;
  }
  
  private static boolean c(Context paramContext, String paramString1, String paramString2)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    Intent localIntent = new Intent(paramString2);
    localIntent.setPackage(paramContext.getPackageName());
    Iterator localIterator = localPackageManager.queryBroadcastReceivers(localIntent, 0).iterator();
    while (localIterator.hasNext())
    {
      ActivityInfo localActivityInfo = ((ResolveInfo)localIterator.next()).activityInfo;
      if ((localActivityInfo != null) && (localActivityInfo.name.equals(paramString1))) {
        return true;
      }
    }
    return false;
  }
  
  public static String d(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService(z[5])).getActiveNetworkInfo();
    String str1;
    if (localNetworkInfo == null) {
      str1 = z[116];
    }
    String str2;
    do
    {
      return str1;
      str1 = localNetworkInfo.getTypeName();
      str2 = localNetworkInfo.getSubtypeName();
      if (str1 == null) {
        return z[116];
      }
    } while (str2 == null);
    return str1 + "," + str2;
  }
  
  public static boolean d(Context paramContext, String paramString)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    ComponentName localComponentName = new ComponentName(paramContext.getPackageName(), paramString);
    try
    {
      localPackageManager.getReceiverInfo(localComponentName, 128);
      return true;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return false;
  }
  
  private static boolean d(String paramString)
  {
    if (ac.a(paramString)) {}
    while (paramString.length() < 10) {
      return false;
    }
    for (int j = 0;; j++)
    {
      if (j >= b.size()) {
        break label73;
      }
      if ((paramString.equals(b.get(j))) || (paramString.startsWith((String)b.get(j)))) {
        break;
      }
    }
    label73:
    return true;
  }
  
  public static String e(Context paramContext)
  {
    NetworkInfo localNetworkInfo = ((ConnectivityManager)paramContext.getSystemService(z[5])).getActiveNetworkInfo();
    if (localNetworkInfo == null) {
      return "";
    }
    return localNetworkInfo.getTypeName().toUpperCase(Locale.getDefault());
  }
  
  public static void e(Context paramContext, String paramString)
  {
    Intent localIntent = new Intent();
    localIntent.addFlags(268435456);
    localIntent.setAction(z[24]);
    localIntent.setDataAndType(Uri.fromFile(new File(paramString)), z[23]);
    paramContext.startActivity(localIntent);
  }
  
  public static void f(Context paramContext)
  {
    Intent localIntent = new Intent(z[15]);
    String str = paramContext.getPackageName();
    localIntent.setPackage(str);
    if (!ac.a(null)) {
      localIntent.putExtra(z[58], null);
    }
    localIntent.addCategory(z[16]);
    ResolveInfo localResolveInfo = paramContext.getPackageManager().resolveActivity(localIntent, 0);
    new StringBuilder(z[59]).append(localResolveInfo.activityInfo.name).toString();
    r.c();
    localIntent.setClassName(str, localResolveInfo.activityInfo.name);
    localIntent.setFlags(268435456);
    paramContext.startActivity(localIntent);
  }
  
  public static boolean f(Context paramContext, String paramString)
  {
    try
    {
      paramContext.getPackageManager().getApplicationInfo(paramString, 0);
      return true;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return false;
  }
  
  public static String g(Context paramContext, String paramString)
  {
    if (!c(paramContext, z[74])) {}
    for (;;)
    {
      return paramString;
      try
      {
        String str = ((WifiManager)paramContext.getSystemService(z[73])).getConnectionInfo().getMacAddress();
        boolean bool = ac.a(str);
        if (!bool) {
          return str;
        }
      }
      catch (Exception localException)
      {
        r.i();
      }
    }
    return paramString;
  }
  
  public static boolean g(Context paramContext)
  {
    return ((PowerManager)paramContext.getSystemService(z[20])).isScreenOn();
  }
  
  public static int h(Context paramContext)
  {
    Intent localIntent = paramContext.registerReceiver(null, new IntentFilter(z[67]));
    int j = localIntent.getIntExtra(z[68], -1);
    if ((j == 2) || (j == 5)) {}
    for (int k = 1; k == 0; k = 0) {
      return -1;
    }
    return localIntent.getIntExtra(z[66], -1);
  }
  
  public static String h(Context paramContext, String paramString)
  {
    if (c(paramContext, z[65])) {
      paramString = ((TelephonyManager)paramContext.getSystemService(z[64])).getDeviceId();
    }
    return paramString;
  }
  
  public static void i(Context paramContext, String paramString)
  {
    if (!ac.a(paramString))
    {
      p(paramContext, paramString);
      n(paramContext, paramString);
      z.b(paramContext, z[2], paramString);
    }
  }
  
  public static boolean i(Context paramContext)
  {
    bool1 = false;
    try
    {
      Signature[] arrayOfSignature = paramContext.getPackageManager().getPackageInfo(paramContext.getPackageName(), 64).signatures;
      CertificateFactory localCertificateFactory = CertificateFactory.getInstance(z[94]);
      int j = 0;
      boolean bool2;
      for (;;)
      {
        if (j >= arrayOfSignature.length) {
          return bool1;
        }
        boolean bool3 = ((X509Certificate)localCertificateFactory.generateCertificate(new ByteArrayInputStream(arrayOfSignature[j].toByteArray()))).getSubjectX500Principal().equals(c);
        bool2 = bool3;
        if (bool2) {
          break;
        }
        j++;
        bool1 = bool2;
      }
      return bool1;
    }
    catch (Exception localException)
    {
      bool2 = bool1;
      return bool2;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      return bool1;
    }
  }
  
  public static String j(Context paramContext)
  {
    String str1 = z.a(paramContext, z[75], "");
    if ((!ac.a(str1)) && (d(str1))) {
      return str1;
    }
    String str2 = x(paramContext);
    z.b(paramContext, z[75], str2);
    return str2;
  }
  
  private static boolean j(Context paramContext, String paramString)
  {
    if ((paramContext == null) || (TextUtils.isEmpty(paramString))) {
      throw new IllegalArgumentException(z[6]);
    }
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      localPackageManager.getPermissionInfo(paramString, 128);
      return true;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return false;
  }
  
  public static String k(Context paramContext)
  {
    return Settings.Secure.getString(paramContext.getContentResolver(), z[51]);
  }
  
  private static boolean k(Context paramContext, String paramString)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    ComponentName localComponentName = new ComponentName(paramContext.getPackageName(), paramString);
    try
    {
      localPackageManager.getServiceInfo(localComponentName, 128);
      return true;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return false;
  }
  
  public static String l(Context paramContext)
  {
    String str1 = z.a(paramContext, z[2], null);
    if (!ac.a(str1))
    {
      a = b.d.ordinal();
      return str1;
    }
    String str2 = o(paramContext, str1);
    if (!ac.a(str2))
    {
      a = b.b.ordinal();
      n(paramContext, str2);
      z.b(paramContext, z[2], str2);
      return str2;
    }
    String str3 = z(paramContext);
    if (!ac.a(str3))
    {
      a = b.c.ordinal();
      p(paramContext, str3);
      z.b(paramContext, z[2], str3);
      return str3;
    }
    boolean bool1 = c(paramContext, z[3]);
    int j;
    boolean bool2;
    if ((c(paramContext, z[1])) && (a()))
    {
      j = 1;
      if (bool1) {
        break label178;
      }
      bool2 = false;
      if (j != 0) {
        break label178;
      }
    }
    for (;;)
    {
      if (bool2) {
        break label203;
      }
      a = b.e.ordinal();
      return A(paramContext);
      j = 0;
      break;
      label178:
      if ((j == 0) && (bool1)) {
        bool2 = B(paramContext);
      } else {
        bool2 = true;
      }
    }
    label203:
    String str4 = h(paramContext, str3);
    String str5 = k(paramContext);
    String str6 = g(paramContext, "");
    Object localObject = UUID.randomUUID().toString();
    String str7 = a(str4 + str5 + str6 + (String)localObject);
    if (ac.a(str7)) {}
    for (;;)
    {
      String str8 = p(paramContext, (String)localObject);
      if ((!ac.a(n(paramContext, (String)localObject))) || (!ac.a(str8)))
      {
        new StringBuilder(z[4]).append((String)localObject).toString();
        r.b();
        z.b(paramContext, z[2], (String)localObject);
        a = b.a.ordinal();
        return (String)localObject;
      }
      a = b.e.ordinal();
      r.b();
      return A(paramContext);
      localObject = str7;
    }
  }
  
  private static boolean l(Context paramContext, String paramString)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    ComponentName localComponentName = new ComponentName(paramContext.getPackageName(), paramString);
    try
    {
      localPackageManager.getActivityInfo(localComponentName, 128);
      return true;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return false;
  }
  
  private static Intent m(Context paramContext, String paramString)
  {
    try
    {
      PackageManager localPackageManager = paramContext.getPackageManager();
      if (localPackageManager.getPackageInfo(paramString, 256) != null)
      {
        Intent localIntent = localPackageManager.getLaunchIntentForPackage(paramString);
        return localIntent;
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return null;
  }
  
  public static void m(Context paramContext)
  {
    PowerManager.WakeLock localWakeLock = ((PowerManager)paramContext.getSystemService(z[20])).newWakeLock(536870913, z[95]);
    n.a().a(localWakeLock);
    if (!n.a().b().isHeld()) {
      n.a().b().acquire();
    }
    r.b();
  }
  
  /* Error */
  private static String n(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: invokestatic 1020	cn/jpush/android/c/a:a	()Z
    //   3: ifeq +15 -> 18
    //   6: aload_0
    //   7: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   10: iconst_1
    //   11: aaload
    //   12: invokestatic 919	cn/jpush/android/c/a:c	(Landroid/content/Context;Ljava/lang/String;)Z
    //   15: ifne +7 -> 22
    //   18: aconst_null
    //   19: astore_1
    //   20: aload_1
    //   21: areturn
    //   22: new 308	java/io/File
    //   25: dup
    //   26: getstatic 329	cn/jpush/android/c/a:e	Ljava/lang/String;
    //   29: invokespecial 813	java/io/File:<init>	(Ljava/lang/String;)V
    //   32: astore_2
    //   33: aload_2
    //   34: invokevirtual 816	java/io/File:exists	()Z
    //   37: ifeq +8 -> 45
    //   40: aload_2
    //   41: invokevirtual 1054	java/io/File:delete	()Z
    //   44: pop
    //   45: aload_2
    //   46: invokevirtual 1057	java/io/File:createNewFile	()Z
    //   49: pop
    //   50: new 1059	java/io/FileOutputStream
    //   53: dup
    //   54: aload_2
    //   55: invokespecial 1060	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   58: astore 5
    //   60: aload 5
    //   62: aload_1
    //   63: invokevirtual 1062	java/lang/String:getBytes	()[B
    //   66: invokevirtual 1065	java/io/FileOutputStream:write	([B)V
    //   69: aload 5
    //   71: invokevirtual 1068	java/io/FileOutputStream:flush	()V
    //   74: invokestatic 420	cn/jpush/android/c/r:c	()V
    //   77: aload 5
    //   79: ifnull -59 -> 20
    //   82: aload 5
    //   84: invokevirtual 1069	java/io/FileOutputStream:close	()V
    //   87: aload_1
    //   88: areturn
    //   89: astore 10
    //   91: aload_1
    //   92: areturn
    //   93: astore 13
    //   95: aconst_null
    //   96: areturn
    //   97: astore_3
    //   98: invokestatic 932	cn/jpush/android/c/r:i	()V
    //   101: aconst_null
    //   102: areturn
    //   103: astore 12
    //   105: aconst_null
    //   106: astore 5
    //   108: invokestatic 932	cn/jpush/android/c/r:i	()V
    //   111: aload 5
    //   113: ifnull +8 -> 121
    //   116: aload 5
    //   118: invokevirtual 1069	java/io/FileOutputStream:close	()V
    //   121: aconst_null
    //   122: areturn
    //   123: astore 11
    //   125: aconst_null
    //   126: astore 5
    //   128: aload 11
    //   130: astore 7
    //   132: aload 5
    //   134: ifnull +8 -> 142
    //   137: aload 5
    //   139: invokevirtual 1069	java/io/FileOutputStream:close	()V
    //   142: aload 7
    //   144: athrow
    //   145: astore 9
    //   147: goto -26 -> 121
    //   150: astore 8
    //   152: goto -10 -> 142
    //   155: astore 7
    //   157: goto -25 -> 132
    //   160: astore 6
    //   162: goto -54 -> 108
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	165	0	paramContext	Context
    //   0	165	1	paramString	String
    //   32	23	2	localFile	File
    //   97	1	3	localIOException1	IOException
    //   58	80	5	localFileOutputStream	java.io.FileOutputStream
    //   160	1	6	localIOException2	IOException
    //   130	13	7	localObject1	Object
    //   155	1	7	localObject2	Object
    //   150	1	8	localIOException3	IOException
    //   145	1	9	localIOException4	IOException
    //   89	1	10	localIOException5	IOException
    //   123	6	11	localObject3	Object
    //   103	1	12	localIOException6	IOException
    //   93	1	13	localSecurityException	SecurityException
    // Exception table:
    //   from	to	target	type
    //   82	87	89	java/io/IOException
    //   40	45	93	java/lang/SecurityException
    //   45	50	97	java/io/IOException
    //   50	60	103	java/io/IOException
    //   50	60	123	finally
    //   116	121	145	java/io/IOException
    //   137	142	150	java/io/IOException
    //   60	77	155	finally
    //   108	111	155	finally
    //   60	77	160	java/io/IOException
  }
  
  public static JSONArray n(Context paramContext)
  {
    ArrayList localArrayList = new ArrayList();
    List localList = paramContext.getPackageManager().getInstalledPackages(0);
    for (int j = 0; j < localList.size(); j++)
    {
      PackageInfo localPackageInfo = (PackageInfo)localList.get(j);
      s locals2 = new s();
      locals2.a = localPackageInfo.applicationInfo.loadLabel(paramContext.getPackageManager()).toString();
      locals2.b = localPackageInfo.packageName;
      locals2.c = localPackageInfo.versionName;
      locals2.d = localPackageInfo.versionCode;
      localArrayList.add(locals2);
    }
    localJSONArray = new JSONArray();
    try
    {
      Iterator localIterator = localArrayList.iterator();
      while (localIterator.hasNext())
      {
        s locals1 = (s)localIterator.next();
        JSONObject localJSONObject = new JSONObject();
        localJSONObject.put(z[48], locals1.a);
        localJSONObject.put(z[47], locals1.b);
        localJSONObject.put(z[50], locals1.c);
        localJSONObject.put(z[49], locals1.d);
        localJSONArray.put(localJSONObject);
      }
      return localJSONArray;
    }
    catch (JSONException localJSONException) {}
  }
  
  private static String o(Context paramContext, String paramString)
  {
    if (c(paramContext, z[3])) {}
    try
    {
      String str = Settings.System.getString(paramContext.getContentResolver(), z[2]);
      paramString = str;
      return paramString;
    }
    catch (Exception localException)
    {
      r.e();
    }
    return paramString;
  }
  
  public static boolean o(Context paramContext)
  {
    try
    {
      if (z.a(paramContext, z[55], "0").equals("1"))
      {
        r.c();
        return false;
      }
      String str1 = z.a(paramContext, z[57], "");
      if (ac.a(str1))
      {
        r.c();
        return true;
      }
      new StringBuilder(z[54]).append(str1).toString();
      r.c();
      String[] arrayOfString1 = str1.split("_");
      String str2 = arrayOfString1[0];
      String str3 = arrayOfString1[1];
      char[] arrayOfChar = str2.toCharArray();
      String[] arrayOfString2 = str3.split(z[56]);
      Calendar localCalendar = Calendar.getInstance();
      int j = localCalendar.get(7);
      int k = localCalendar.get(11);
      int m = arrayOfChar.length;
      boolean bool;
      for (int n = 0;; n++)
      {
        bool = false;
        if (n >= m) {
          break;
        }
        if (j == 1 + Integer.valueOf(String.valueOf(arrayOfChar[n])).intValue())
        {
          int i1 = Integer.valueOf(arrayOfString2[0]).intValue();
          int i2 = Integer.valueOf(arrayOfString2[1]).intValue();
          if ((k >= i1) && (k <= i2)) {
            return true;
          }
        }
      }
      return bool;
    }
    catch (Exception localException)
    {
      bool = true;
    }
  }
  
  private static String p(Context paramContext, String paramString)
  {
    if (c(paramContext, z[3])) {
      try
      {
        boolean bool = Settings.System.putString(paramContext.getContentResolver(), z[2], paramString);
        if (bool) {
          return paramString;
        }
      }
      catch (Exception localException)
      {
        r.e();
      }
    }
    return null;
  }
  
  public static boolean p(Context paramContext)
  {
    String str = z.a(paramContext, z[91], "");
    if (TextUtils.isEmpty(str)) {}
    for (;;)
    {
      return false;
      try
      {
        JSONObject localJSONObject = new JSONObject(str);
        int j = localJSONObject.optInt(z[93], -1);
        int k = localJSONObject.optInt(z[89], -1);
        int m = localJSONObject.optInt(z[92], -1);
        int n = localJSONObject.optInt(z[90], -1);
        if ((j >= 0) && (k >= 0) && (m >= 0) && (n >= 0) && (k <= 59) && (n <= 59) && (m <= 23) && (j <= 23))
        {
          Calendar localCalendar = Calendar.getInstance();
          int i1 = localCalendar.get(11);
          int i2 = localCalendar.get(12);
          if (j < m)
          {
            if (((i1 > j) && (i1 < m)) || ((i1 == j) && (i2 >= k)) || ((i1 == m) && (i2 <= n))) {
              return true;
            }
          }
          else if (j == m)
          {
            if ((i1 == j) && (i2 >= k) && (i2 <= n)) {
              return true;
            }
          }
          else if ((j > m) && (((i1 > j) && (i1 <= 23)) || ((i1 >= 0) && (i1 < m)) || ((i1 == j) && (i2 >= k)) || ((i1 == m) && (i2 <= n)))) {
            return true;
          }
        }
      }
      catch (JSONException localJSONException) {}
    }
    return false;
  }
  
  public static boolean q(Context paramContext)
  {
    r.b(z[35], z[41]);
    int j;
    if (!k(paramContext, PushService.class.getCanonicalName()))
    {
      r.e(z[35], z[37] + PushService.class.getCanonicalName());
      j = 0;
      if (ac.a(cn.jpush.android.a.f)) {
        break label799;
      }
    }
    for (int k = 1;; k = 0)
    {
      if ((!cn.jpush.android.a.i) && (!C(paramContext))) {
        r.d(z[35], z[40]);
      }
      if ((k == 0) || (j == 0)) {
        break label820;
      }
      return true;
      if (!b(paramContext, z[45], false))
      {
        r.e(z[35], z[33]);
        j = 0;
        break;
      }
      if (!b(paramContext, z[31], false))
      {
        r.e(z[35], z[28]);
        j = 0;
        break;
      }
      k(paramContext, DownloadService.class.getCanonicalName());
      if (!d(paramContext, PushReceiver.class.getCanonicalName()))
      {
        r.e(z[35], z[32] + PushReceiver.class.getCanonicalName());
        D(paramContext);
      }
      for (;;)
      {
        j = 1;
        break;
        if (c(paramContext, PushReceiver.class.getCanonicalName(), z[29])) {
          r.d(z[35], z[43]);
        }
        if (!a(paramContext, z[44], true))
        {
          r.e(z[35], z[39]);
          j = 0;
          break;
        }
        if (!d(paramContext, AlarmReceiver.class.getCanonicalName()))
        {
          r.e(z[35], z[32] + AlarmReceiver.class.getCanonicalName());
          j = 0;
          break;
        }
        l(paramContext, PushActivity.class.getCanonicalName());
        String str1 = z[18];
        PackageManager localPackageManager = paramContext.getPackageManager();
        Intent localIntent = new Intent(str1);
        localIntent.addCategory(paramContext.getPackageName());
        if (localPackageManager.queryIntentActivities(localIntent, 0).isEmpty()) {}
        String str2 = paramContext.getPackageName() + z[38];
        if (!j(paramContext, str2))
        {
          r.e(z[35], z[34] + str2);
          j = 0;
          break;
        }
        f.add(str2);
        Iterator localIterator1 = f.iterator();
        for (;;)
        {
          if (localIterator1.hasNext())
          {
            String str5 = (String)localIterator1.next();
            if (!c(paramContext.getApplicationContext(), str5))
            {
              r.e(z[35], z[42] + str5);
              j = 0;
              break;
            }
          }
        }
        if ((i(paramContext)) && (!c(paramContext.getApplicationContext(), z[3])))
        {
          r.e(z[35], z[27]);
          j = 0;
          break;
        }
        Iterator localIterator2 = g.iterator();
        while (localIterator2.hasNext())
        {
          String str4 = (String)localIterator2.next();
          if (!c(paramContext.getApplicationContext(), str4)) {
            r.d(z[35], z[30] + str4);
          }
        }
        Iterator localIterator3 = h.iterator();
        while (localIterator3.hasNext())
        {
          String str3 = (String)localIterator3.next();
          if (!c(paramContext.getApplicationContext(), str3)) {
            r.d(z[35], z[30] + str3 + z[46]);
          }
        }
      }
      label799:
      r.d(z[35], z[36]);
    }
    label820:
    return false;
  }
  
  public static void r(Context paramContext)
  {
    if ((i != null) && (!d(paramContext, PushReceiver.class.getCanonicalName()))) {}
    try
    {
      paramContext.unregisterReceiver(i);
      return;
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
    }
  }
  
  public static long s(Context paramContext)
  {
    return PushService.a(paramContext);
  }
  
  public static String t(Context paramContext)
  {
    return PushService.b(paramContext);
  }
  
  public static String u(Context paramContext)
  {
    return z.a(paramContext, z[112], "");
  }
  
  public static String v(Context paramContext)
  {
    Object localObject = cn.jpush.android.a.f;
    PackageManager localPackageManager;
    if (ac.a((String)localObject)) {
      localPackageManager = paramContext.getPackageManager();
    }
    try
    {
      ApplicationInfo localApplicationInfo = localPackageManager.getApplicationInfo(paramContext.getPackageName(), 128);
      if ((localApplicationInfo != null) && (localApplicationInfo.metaData != null))
      {
        String str = localApplicationInfo.metaData.getString(z[25]);
        localObject = str;
      }
      return (String)localObject;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException) {}
    return (String)localObject;
  }
  
  private static String w(Context paramContext)
  {
    if (!c(paramContext, z[74])) {
      return null;
    }
    try
    {
      String str1 = ((WifiManager)paramContext.getSystemService(z[73])).getConnectionInfo().getMacAddress();
      if ((str1 != null) && (!str1.equals("")))
      {
        new StringBuilder(z[72]).append(str1).toString();
        r.c();
        String str2 = a(str1 + Build.MODEL);
        return str2;
      }
    }
    catch (Exception localException)
    {
      r.i();
      return null;
    }
    return null;
  }
  
  private static String x(Context paramContext)
  {
    String str1;
    try
    {
      String str2 = h(paramContext, "");
      if (d(str2)) {
        return str2;
      }
      str1 = k(paramContext);
      if ((ac.a(str1)) || (!d(str1)) || (z[7].equals(str1.toLowerCase(Locale.getDefault()))))
      {
        str1 = w(paramContext);
        if ((ac.a(str1)) || (!d(str1)))
        {
          str1 = y(paramContext);
          if (str1 == null) {
            return " ";
          }
        }
      }
    }
    catch (Exception localException)
    {
      r.i();
      str1 = y(paramContext);
    }
    return str1;
  }
  
  /* Error */
  private static String y(Context paramContext)
  {
    // Byte code:
    //   0: invokestatic 579	cn/jpush/android/c/r:b	()V
    //   3: aload_0
    //   4: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   7: bipush 60
    //   9: aaload
    //   10: iconst_0
    //   11: invokevirtual 1221	android/content/Context:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   14: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   17: bipush 61
    //   19: aaload
    //   20: aconst_null
    //   21: invokeinterface 1226 3 0
    //   26: astore_1
    //   27: aload_1
    //   28: invokestatic 364	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   31: ifne +5 -> 36
    //   34: aload_1
    //   35: areturn
    //   36: invokestatic 1020	cn/jpush/android/c/a:a	()Z
    //   39: ifne +79 -> 118
    //   42: aload_0
    //   43: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   46: bipush 60
    //   48: aaload
    //   49: iconst_0
    //   50: invokevirtual 1221	android/content/Context:getSharedPreferences	(Ljava/lang/String;I)Landroid/content/SharedPreferences;
    //   53: astore 16
    //   55: aload 16
    //   57: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   60: bipush 61
    //   62: aaload
    //   63: aconst_null
    //   64: invokeinterface 1226 3 0
    //   69: astore_1
    //   70: aload_1
    //   71: ifnonnull -37 -> 34
    //   74: invokestatic 387	java/util/UUID:randomUUID	()Ljava/util/UUID;
    //   77: invokevirtual 388	java/util/UUID:toString	()Ljava/lang/String;
    //   80: astore 17
    //   82: aload 16
    //   84: invokeinterface 1230 1 0
    //   89: astore 18
    //   91: aload 18
    //   93: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   96: bipush 61
    //   98: aaload
    //   99: aload 17
    //   101: invokeinterface 1235 3 0
    //   106: pop
    //   107: aload 18
    //   109: invokeinterface 1238 1 0
    //   114: pop
    //   115: aload 17
    //   117: areturn
    //   118: aload_0
    //   119: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   122: bipush 62
    //   124: aaload
    //   125: aconst_null
    //   126: invokestatic 987	cn/jpush/android/c/z:a	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)Ljava/lang/String;
    //   129: astore_1
    //   130: aload_1
    //   131: ifnonnull -97 -> 34
    //   134: new 308	java/io/File
    //   137: dup
    //   138: getstatic 323	cn/jpush/android/c/a:d	Ljava/lang/String;
    //   141: invokespecial 813	java/io/File:<init>	(Ljava/lang/String;)V
    //   144: astore_2
    //   145: aload_2
    //   146: invokevirtual 816	java/io/File:exists	()Z
    //   149: ifeq +77 -> 226
    //   152: new 1240	java/io/FileInputStream
    //   155: dup
    //   156: aload_2
    //   157: invokespecial 1241	java/io/FileInputStream:<init>	(Ljava/io/File;)V
    //   160: invokestatic 1246	cn/jpush/android/c/m:a	(Ljava/io/InputStream;)Ljava/util/ArrayList;
    //   163: astore 13
    //   165: aload 13
    //   167: invokevirtual 1247	java/util/ArrayList:size	()I
    //   170: ifle +56 -> 226
    //   173: aload 13
    //   175: iconst_0
    //   176: invokevirtual 1248	java/util/ArrayList:get	(I)Ljava/lang/Object;
    //   179: checkcast 27	java/lang/String
    //   182: astore 14
    //   184: aload_0
    //   185: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   188: bipush 62
    //   190: aaload
    //   191: aload 14
    //   193: invokestatic 955	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   196: new 299	java/lang/StringBuilder
    //   199: dup
    //   200: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   203: bipush 63
    //   205: aaload
    //   206: invokespecial 577	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   209: aload 14
    //   211: invokevirtual 316	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   214: invokevirtual 321	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   217: pop
    //   218: invokestatic 420	cn/jpush/android/c/r:c	()V
    //   221: aload 14
    //   223: areturn
    //   224: astore 12
    //   226: new 299	java/lang/StringBuilder
    //   229: dup
    //   230: invokespecial 300	java/lang/StringBuilder:<init>	()V
    //   233: invokestatic 629	java/lang/System:currentTimeMillis	()J
    //   236: invokevirtual 1251	java/lang/StringBuilder:append	(J)Ljava/lang/StringBuilder;
    //   239: invokevirtual 321	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   242: invokevirtual 1062	java/lang/String:getBytes	()[B
    //   245: invokestatic 1255	java/util/UUID:nameUUIDFromBytes	([B)Ljava/util/UUID;
    //   248: invokevirtual 388	java/util/UUID:toString	()Ljava/lang/String;
    //   251: invokestatic 1257	cn/jpush/android/c/ac:b	(Ljava/lang/String;)Ljava/lang/String;
    //   254: astore_1
    //   255: aload_0
    //   256: getstatic 271	cn/jpush/android/c/a:z	[Ljava/lang/String;
    //   259: bipush 62
    //   261: aaload
    //   262: aload_1
    //   263: invokestatic 955	cn/jpush/android/c/z:b	(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V
    //   266: aload_2
    //   267: invokevirtual 1057	java/io/File:createNewFile	()Z
    //   270: pop
    //   271: new 1059	java/io/FileOutputStream
    //   274: dup
    //   275: aload_2
    //   276: invokespecial 1060	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   279: astore 5
    //   281: aload 5
    //   283: aload_1
    //   284: invokevirtual 1062	java/lang/String:getBytes	()[B
    //   287: invokevirtual 1065	java/io/FileOutputStream:write	([B)V
    //   290: aload 5
    //   292: invokevirtual 1068	java/io/FileOutputStream:flush	()V
    //   295: invokestatic 420	cn/jpush/android/c/r:c	()V
    //   298: aload 5
    //   300: ifnull -266 -> 34
    //   303: aload 5
    //   305: invokevirtual 1069	java/io/FileOutputStream:close	()V
    //   308: aload_1
    //   309: areturn
    //   310: astore 10
    //   312: aload_1
    //   313: areturn
    //   314: astore_3
    //   315: invokestatic 932	cn/jpush/android/c/r:i	()V
    //   318: aload_1
    //   319: areturn
    //   320: astore 11
    //   322: aconst_null
    //   323: astore 5
    //   325: invokestatic 932	cn/jpush/android/c/r:i	()V
    //   328: aload 5
    //   330: ifnull -296 -> 34
    //   333: aload 5
    //   335: invokevirtual 1069	java/io/FileOutputStream:close	()V
    //   338: aload_1
    //   339: areturn
    //   340: astore 9
    //   342: aload_1
    //   343: areturn
    //   344: astore 7
    //   346: aconst_null
    //   347: astore 5
    //   349: aload 5
    //   351: ifnull +8 -> 359
    //   354: aload 5
    //   356: invokevirtual 1069	java/io/FileOutputStream:close	()V
    //   359: aload 7
    //   361: athrow
    //   362: astore 8
    //   364: goto -5 -> 359
    //   367: astore 7
    //   369: goto -20 -> 349
    //   372: astore 6
    //   374: goto -49 -> 325
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	377	0	paramContext	Context
    //   26	317	1	str1	String
    //   144	132	2	localFile	File
    //   314	1	3	localIOException1	IOException
    //   279	76	5	localFileOutputStream	java.io.FileOutputStream
    //   372	1	6	localIOException2	IOException
    //   344	16	7	localObject1	Object
    //   367	1	7	localObject2	Object
    //   362	1	8	localIOException3	IOException
    //   340	1	9	localIOException4	IOException
    //   310	1	10	localIOException5	IOException
    //   320	1	11	localIOException6	IOException
    //   224	1	12	localFileNotFoundException	FileNotFoundException
    //   163	11	13	localArrayList	ArrayList
    //   182	40	14	str2	String
    //   53	30	16	localSharedPreferences	android.content.SharedPreferences
    //   80	36	17	str3	String
    //   89	19	18	localEditor	android.content.SharedPreferences.Editor
    // Exception table:
    //   from	to	target	type
    //   152	221	224	java/io/FileNotFoundException
    //   303	308	310	java/io/IOException
    //   266	271	314	java/io/IOException
    //   271	281	320	java/io/IOException
    //   333	338	340	java/io/IOException
    //   271	281	344	finally
    //   354	359	362	java/io/IOException
    //   281	298	367	finally
    //   325	328	367	finally
    //   281	298	372	java/io/IOException
  }
  
  private static String z(Context paramContext)
  {
    if ((!a()) || (!c(paramContext, z[1])))
    {
      r.e();
      return null;
    }
    File localFile = new File(e);
    if (localFile.exists()) {
      try
      {
        ArrayList localArrayList = m.a(new FileInputStream(localFile));
        if (localArrayList.size() > 0)
        {
          String str = (String)localArrayList.get(0);
          new StringBuilder(z[113]).append(str).toString();
          r.c();
          return str;
        }
      }
      catch (FileNotFoundException localFileNotFoundException)
      {
        return null;
      }
    }
    return null;
  }
  
  private static String z(char[] paramArrayOfChar)
  {
    int j = paramArrayOfChar.length;
    int k = 0;
    if (j <= 1) {}
    label115:
    while (j > k)
    {
      char[] arrayOfChar = paramArrayOfChar;
      int m = k;
      int n = paramArrayOfChar[k];
      int i1;
      switch (m % 5)
      {
      default: 
        i1 = 112;
      }
      for (;;)
      {
        paramArrayOfChar[k] = ((char)(i1 ^ n));
        k = m + 1;
        if (j != 0) {
          break label115;
        }
        paramArrayOfChar = arrayOfChar;
        m = k;
        k = j;
        break;
        i1 = 3;
        continue;
        i1 = 24;
        continue;
        i1 = 34;
        continue;
        i1 = 59;
      }
      paramArrayOfChar = arrayOfChar;
    }
    return new String(paramArrayOfChar).intern();
  }
  
  private static char[] z(String paramString)
  {
    Object localObject1 = paramString.toCharArray();
    Object localObject2 = localObject1;
    for (;;)
    {
      int j = localObject1.length;
      if (j < 2)
      {
        if (j != 0) {
          localObject2[0] = ((char)(0x70 ^ localObject2[0]));
        }
      }
      else {
        return (char[])localObject2;
      }
      localObject1 = localObject2;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.a
 * JD-Core Version:    0.7.1
 */