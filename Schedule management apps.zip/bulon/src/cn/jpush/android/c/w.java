package cn.jpush.android.c;

import android.content.Context;
import java.io.Closeable;
import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.ref.WeakReference;
import java.net.InetAddress;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class w
{
  public static WeakReference<JSONObject> a = null;
  public static JSONObject b = null;
  private static final String c;
  private static String d;
  private static String e;
  private static final String f;
  private static ExecutorService g;
  private static Object h = new Object();
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[32];
    int i = 0;
    String str1 = "\020|#`[%\"rG%o7p[\037S>z@\016c$j\035\0209}";
    int j = -1;
    Object localObject2 = localObject1;
    int i9;
    label133:
    String str2;
    for (;;)
    {
      Object localObject3 = str1.toCharArray();
      int k = localObject3.length;
      int m = 0;
      if (k <= 1) {}
      while (k > m)
      {
        Object localObject7 = localObject3;
        int i6 = m;
        int i7 = k;
        Object localObject8 = localObject3;
        for (;;)
        {
          int i8 = localObject8[m];
          switch (i6 % 5)
          {
          default: 
            i9 = 51;
            localObject8[m] = ((char)(i9 ^ i8));
            m = i6 + 1;
            if (i7 != 0) {
              break label133;
            }
            localObject8 = localObject7;
            i6 = m;
            m = i7;
          }
        }
        k = i7;
        localObject3 = localObject7;
      }
      str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "\031c8gV\024x";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "\n`7gU\025~;";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "\ti8w\023\026c13@\026e5v\t";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "Z|7aG\t";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "\ny\"3P\025b\"v]\016,3kP\037|\"z\\\024 vtZ\fivfCZ3}WZ`9t\t";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "\026c13@\023v3)";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "\026c13W\023z?wV\036,?}G\025,";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "\033|&LX\037u";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "\r~7c\023\031c8gR\023b3a\023\037t5vC\016e9}\037Zk?eVZy&3@\037b23_\025kl";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "\017e2";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "\017x0>\013";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "/X\020>\013";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "\022x\"c\tU#";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "Zc#gC\017x\005gA\037m;?\023\035e v\023\017|v`R\fiv)";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "\022e%g\\\bu\tuZ\026i";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "\031m84GZ{$zG\037,";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "\tm v\023\026c13Z\024,!aZ\016i\036z@\016c$j\025kl";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "\031m84GZi8p\\\036e8t\023";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "\031c8gV\002xvz@Zb#_Z vtZ\fivfCZ7eVZ";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "\031m84GZc&v]Z";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "Z vtZ\fivfCZ7eVZ6";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "\031y$aV\024x\t`V\t?|]%j?V";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "\031c8gV\002xvz@Zb#_Z vtZ\fivfCZ~3rWZ";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "Ze8cF\016_\"aV\033az3T\023z33F\n,$vR\036,v)";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "V,1zE\037,#c\023\bi7w\023@";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "\031m84GZn#z_\036,";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "Ze%3]\017`:?\023\bi\"fA\024,8f_\026";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "\031m84GZ~3rWZ";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "Ze8g\\ZF%|]5n<vP\016 vtZ\fivfCZ~3rWZ6";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "\tx7g@Tf&f@\022\"5}";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = "\022x\"c\tU#%gR\016xyC\017>=P\024";
        j = 30;
        localObject1 = localObject2;
      }
    }
    localObject1[i] = str2;
    z = (String[])localObject2;
    c = w.class.getSimpleName();
    d = "";
    Object localObject4 = "Uzg<A\037|9aG".toCharArray();
    int n = localObject4.length;
    int i1 = 0;
    if (n <= 1) {}
    label969:
    label1109:
    while (n > i1)
    {
      Object localObject5 = localObject4;
      int i2 = i1;
      int i3 = n;
      Object localObject6 = localObject4;
      int i4 = localObject6[i1];
      int i5;
      switch (i2 % 5)
      {
      default: 
        i5 = 51;
      }
      for (;;)
      {
        localObject6[i1] = ((char)(i5 ^ i4));
        i1 = i2 + 1;
        if (i3 != 0) {
          break label1109;
        }
        localObject6 = localObject5;
        i2 = i1;
        i1 = i3;
        break label969;
        i9 = 122;
        break;
        i9 = 12;
        break;
        i9 = 86;
        break;
        i9 = 19;
        break;
        i5 = 122;
        continue;
        i5 = 12;
        continue;
        i5 = 86;
        continue;
        i5 = 19;
      }
      n = i3;
      localObject4 = localObject5;
    }
    e = new String((char[])localObject4).intern();
    f = z[31] + e;
    g = Executors.newSingleThreadExecutor();
  }
  
  public static String a()
  {
    return d;
  }
  
  public static String a(Context paramContext, String paramString)
  {
    if (ac.a(paramString)) {
      r.b();
    }
    long l;
    String str3;
    do
    {
      return null;
      l = a.s(paramContext);
      if (l == 0L)
      {
        r.b();
        return null;
      }
      String str1 = a.t(paramContext);
      if (ac.a(str1))
      {
        r.b();
        return null;
      }
      String str2 = a.b(str1);
      str3 = a.b(l + str2 + paramString);
    } while (ac.a(str3));
    return l + ":" + str3;
  }
  
  public static String a(String paramString)
  {
    if (!paramString.startsWith(z[13])) {
      paramString = z[13] + paramString;
    }
    if (!paramString.endsWith(e)) {
      paramString = paramString + e;
    }
    d = paramString;
    return paramString;
  }
  
  /* Error */
  private static ArrayList<JSONArray> a(JSONArray paramJSONArray, int paramInt)
  {
    // Byte code:
    //   0: new 187	java/util/ArrayList
    //   3: dup
    //   4: invokespecial 188	java/util/ArrayList:<init>	()V
    //   7: astore_2
    //   8: new 190	org/json/JSONArray
    //   11: dup
    //   12: invokespecial 191	org/json/JSONArray:<init>	()V
    //   15: astore_3
    //   16: aload_0
    //   17: ifnull +253 -> 270
    //   20: aload_0
    //   21: invokevirtual 195	org/json/JSONArray:length	()I
    //   24: ifle +246 -> 270
    //   27: iconst_m1
    //   28: aload_0
    //   29: invokevirtual 195	org/json/JSONArray:length	()I
    //   32: iadd
    //   33: istore 4
    //   35: iconst_0
    //   36: istore 5
    //   38: iconst_0
    //   39: istore 6
    //   41: iload 4
    //   43: iflt +214 -> 257
    //   46: aload_0
    //   47: iload 4
    //   49: invokevirtual 199	org/json/JSONArray:optJSONObject	(I)Lorg/json/JSONObject;
    //   52: astore 8
    //   54: aload 8
    //   56: ifnull +293 -> 349
    //   59: aload 8
    //   61: invokevirtual 202	org/json/JSONObject:toString	()Ljava/lang/String;
    //   64: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   67: bipush 12
    //   69: aaload
    //   70: invokevirtual 206	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   73: arraylength
    //   74: istore 19
    //   76: iload 6
    //   78: iload 19
    //   80: iadd
    //   81: istore 20
    //   83: iload 20
    //   85: ldc 207
    //   87: if_icmple +38 -> 125
    //   90: iload 4
    //   92: iconst_1
    //   93: if_icmple +32 -> 125
    //   96: iload 4
    //   98: iconst_1
    //   99: if_icmple +5 -> 104
    //   102: aload_2
    //   103: areturn
    //   104: iload 4
    //   106: iconst_1
    //   107: if_icmpne +18 -> 125
    //   110: aload_3
    //   111: aload 8
    //   113: invokevirtual 211	org/json/JSONArray:put	(Ljava/lang/Object;)Lorg/json/JSONArray;
    //   116: pop
    //   117: aload_2
    //   118: aload_3
    //   119: invokevirtual 215	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   122: pop
    //   123: aload_2
    //   124: areturn
    //   125: iload 5
    //   127: iload 19
    //   129: iadd
    //   130: sipush 20480
    //   133: if_icmple +55 -> 188
    //   136: aload_2
    //   137: aload_3
    //   138: invokevirtual 215	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   141: pop
    //   142: new 190	org/json/JSONArray
    //   145: dup
    //   146: invokespecial 191	org/json/JSONArray:<init>	()V
    //   149: astore 11
    //   151: aload 11
    //   153: aload 8
    //   155: invokevirtual 211	org/json/JSONArray:put	(Ljava/lang/Object;)Lorg/json/JSONArray;
    //   158: pop
    //   159: iload 20
    //   161: istore 12
    //   163: iload 19
    //   165: istore 9
    //   167: iinc 4 255
    //   170: iload 9
    //   172: istore 5
    //   174: iload 12
    //   176: istore 13
    //   178: aload 11
    //   180: astore_3
    //   181: iload 13
    //   183: istore 6
    //   185: goto -144 -> 41
    //   188: iload 5
    //   190: iload 19
    //   192: iadd
    //   193: istore 21
    //   195: aload_3
    //   196: aload 8
    //   198: invokevirtual 211	org/json/JSONArray:put	(Ljava/lang/Object;)Lorg/json/JSONArray;
    //   201: pop
    //   202: aload_3
    //   203: astore 24
    //   205: iload 20
    //   207: istore 12
    //   209: iload 21
    //   211: istore 9
    //   213: aload 24
    //   215: astore 11
    //   217: goto -50 -> 167
    //   220: astore 14
    //   222: aload 14
    //   224: astore 15
    //   226: iload 5
    //   228: istore 9
    //   230: iload 6
    //   232: istore 16
    //   234: aload_3
    //   235: astore 11
    //   237: iload 16
    //   239: istore 12
    //   241: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   244: pop
    //   245: aload 15
    //   247: invokevirtual 218	java/io/UnsupportedEncodingException:getMessage	()Ljava/lang/String;
    //   250: pop
    //   251: invokestatic 220	cn/jpush/android/c/r:e	()V
    //   254: goto -87 -> 167
    //   257: aload_3
    //   258: invokevirtual 195	org/json/JSONArray:length	()I
    //   261: ifle +9 -> 270
    //   264: aload_2
    //   265: aload_3
    //   266: invokevirtual 215	java/util/ArrayList:add	(Ljava/lang/Object;)Z
    //   269: pop
    //   270: aload_2
    //   271: areturn
    //   272: astore 29
    //   274: aload 29
    //   276: astore 15
    //   278: aload_3
    //   279: astore 11
    //   281: iload 20
    //   283: istore 12
    //   285: iload 5
    //   287: istore 9
    //   289: goto -48 -> 241
    //   292: astore 25
    //   294: aload_3
    //   295: astore 11
    //   297: iload 20
    //   299: istore 12
    //   301: iload 19
    //   303: istore 9
    //   305: aload 25
    //   307: astore 15
    //   309: goto -68 -> 241
    //   312: astore 27
    //   314: iload 20
    //   316: istore 12
    //   318: iload 19
    //   320: istore 9
    //   322: aload 27
    //   324: astore 15
    //   326: goto -85 -> 241
    //   329: astore 15
    //   331: aload_3
    //   332: astore 22
    //   334: iload 20
    //   336: istore 12
    //   338: iload 21
    //   340: istore 9
    //   342: aload 22
    //   344: astore 11
    //   346: goto -105 -> 241
    //   349: iload 5
    //   351: istore 9
    //   353: iload 6
    //   355: istore 10
    //   357: aload_3
    //   358: astore 11
    //   360: iload 10
    //   362: istore 12
    //   364: goto -197 -> 167
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	367	0	paramJSONArray	JSONArray
    //   0	367	1	paramInt	int
    //   7	264	2	localArrayList	ArrayList
    //   15	343	3	localObject1	Object
    //   33	135	4	i	int
    //   36	314	5	j	int
    //   39	315	6	k	int
    //   52	145	8	localJSONObject	JSONObject
    //   165	187	9	m	int
    //   355	6	10	n	int
    //   149	210	11	localObject2	Object
    //   161	202	12	i1	int
    //   176	6	13	i2	int
    //   220	3	14	localUnsupportedEncodingException1	UnsupportedEncodingException
    //   224	101	15	localObject3	Object
    //   329	1	15	localUnsupportedEncodingException2	UnsupportedEncodingException
    //   232	6	16	i3	int
    //   74	245	19	i4	int
    //   81	254	20	i5	int
    //   193	146	21	i6	int
    //   332	11	22	localObject4	Object
    //   203	11	24	localObject5	Object
    //   292	14	25	localUnsupportedEncodingException3	UnsupportedEncodingException
    //   312	11	27	localUnsupportedEncodingException4	UnsupportedEncodingException
    //   272	3	29	localUnsupportedEncodingException5	UnsupportedEncodingException
    // Exception table:
    //   from	to	target	type
    //   59	76	220	java/io/UnsupportedEncodingException
    //   110	123	272	java/io/UnsupportedEncodingException
    //   136	151	292	java/io/UnsupportedEncodingException
    //   151	159	312	java/io/UnsupportedEncodingException
    //   195	202	329	java/io/UnsupportedEncodingException
  }
  
  private static void a(Context paramContext)
  {
    b = null;
    a(paramContext, z[0], null);
  }
  
  public static void a(Context paramContext, int paramInt)
  {
    int i = 0;
    if (b == null) {}
    for (;;)
    {
      return;
      if (paramInt >= 204800)
      {
        a(paramContext);
        return;
      }
      try
      {
        j = b.toString().getBytes(z[11]).length;
        k = j + paramInt - 204800;
        if (k > 0)
        {
          localJSONArray1 = b.optJSONArray(z[1]);
          if ((localJSONArray1 == null) || (localJSONArray1.length() <= 0)) {}
        }
      }
      catch (UnsupportedEncodingException localUnsupportedEncodingException1)
      {
        try
        {
          int k;
          JSONArray localJSONArray1;
          JSONArray localJSONArray2 = new JSONArray();
          m = 0;
          if (m < localJSONArray1.length())
          {
            JSONObject localJSONObject = localJSONArray1.getJSONObject(m);
            if (localJSONObject != null)
            {
              if (i >= k) {
                localJSONArray2.put(localJSONObject);
              }
              i += localJSONObject.toString().getBytes(z[11]).length;
            }
          }
          else
          {
            if (localJSONArray2.length() > 0) {
              b.put(z[1], localJSONArray2);
            }
            for (;;)
            {
              a(paramContext, z[0], b);
              return;
              b = null;
            }
          }
        }
        catch (UnsupportedEncodingException localUnsupportedEncodingException2)
        {
          for (;;)
          {
            int m;
            return;
            m++;
          }
          localUnsupportedEncodingException1 = localUnsupportedEncodingException1;
          int j = 0;
        }
        catch (JSONException localJSONException) {}
      }
    }
  }
  
  public static void a(Context paramContext, JSONArray paramJSONArray, x paramx)
  {
    g.execute(new y(paramContext, paramJSONArray, null));
  }
  
  public static void a(Context paramContext, JSONObject paramJSONObject)
  {
    a(paramContext, new JSONArray().put(paramJSONObject), null);
  }
  
  private static void a(Context paramContext, JSONObject paramJSONObject, ArrayList<JSONArray> paramArrayList)
  {
    if ((paramArrayList == null) || (paramArrayList.size() <= 0)) {
      a(paramContext);
    }
    JSONArray localJSONArray1 = new JSONArray();
    for (int i = 0; i < paramArrayList.size(); i++)
    {
      JSONArray localJSONArray2 = (JSONArray)paramArrayList.get(i);
      for (int j = 0; j < localJSONArray2.length(); j++) {
        if (localJSONArray2.optJSONObject(j) != null) {
          localJSONArray1.put(localJSONArray2.optJSONObject(j));
        }
      }
    }
    try
    {
      paramJSONObject.put(z[1], localJSONArray1);
      label104:
      b = paramJSONObject;
      a(paramContext, z[0], paramJSONObject);
      return;
    }
    catch (JSONException localJSONException)
    {
      break label104;
    }
  }
  
  private static void a(Context paramContext, JSONObject paramJSONObject, JSONArray paramJSONArray, ArrayList<JSONArray> paramArrayList)
  {
    if (paramArrayList == null) {}
    do
    {
      return;
      if (paramArrayList.size() == 1)
      {
        b = null;
        a(paramContext);
        return;
      }
    } while ((paramJSONArray == null) || (paramArrayList.size() <= 1));
    paramArrayList.remove(paramJSONArray);
    JSONArray localJSONArray1 = new JSONArray();
    for (int i = 0; i < paramArrayList.size(); i++)
    {
      JSONArray localJSONArray2 = (JSONArray)paramArrayList.get(i);
      for (int j = 0; j < localJSONArray2.length(); j++) {
        if (localJSONArray2.optJSONObject(j) != null) {
          localJSONArray1.put(localJSONArray2.optJSONObject(j));
        }
      }
    }
    try
    {
      paramJSONObject.put(z[1], localJSONArray1);
      label132:
      b = paramJSONObject;
      a(paramContext, z[0], paramJSONObject);
      return;
    }
    catch (JSONException localJSONException)
    {
      break label132;
    }
  }
  
  private static void a(Closeable paramCloseable)
  {
    if (paramCloseable != null) {}
    try
    {
      paramCloseable.close();
      return;
    }
    catch (IOException localIOException) {}
  }
  
  /* Error */
  public static boolean a(Context paramContext, String paramString, JSONObject paramJSONObject)
  {
    // Byte code:
    //   0: aload_1
    //   1: invokestatic 153	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   4: ifeq +12 -> 16
    //   7: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   10: pop
    //   11: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   14: iconst_0
    //   15: ireturn
    //   16: aload_1
    //   17: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   20: iconst_0
    //   21: aaload
    //   22: invokevirtual 280	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   25: ifeq +44 -> 69
    //   28: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   31: bipush 15
    //   33: aaload
    //   34: astore_3
    //   35: aload_0
    //   36: ifnonnull +43 -> 79
    //   39: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   42: pop
    //   43: new 119	java/lang/StringBuilder
    //   46: dup
    //   47: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   50: bipush 19
    //   52: aaload
    //   53: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   56: aload_3
    //   57: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   60: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   63: pop
    //   64: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   67: iconst_0
    //   68: ireturn
    //   69: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   72: bipush 22
    //   74: aaload
    //   75: astore_3
    //   76: goto -41 -> 35
    //   79: getstatic 147	cn/jpush/android/c/w:h	Ljava/lang/Object;
    //   82: astore 4
    //   84: aload 4
    //   86: monitorenter
    //   87: ldc 111
    //   89: astore 5
    //   91: aload_2
    //   92: ifnull +57 -> 149
    //   95: aload_2
    //   96: invokevirtual 202	org/json/JSONObject:toString	()Ljava/lang/String;
    //   99: astore 5
    //   101: aload_1
    //   102: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   105: iconst_0
    //   106: aaload
    //   107: invokevirtual 280	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   110: istore 7
    //   112: iload 7
    //   114: ifeq +35 -> 149
    //   117: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   120: pop
    //   121: new 119	java/lang/StringBuilder
    //   124: dup
    //   125: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   128: bipush 17
    //   130: aaload
    //   131: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   134: aload_2
    //   135: iconst_1
    //   136: invokevirtual 283	org/json/JSONObject:toString	(I)Ljava/lang/String;
    //   139: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   142: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   145: pop
    //   146: invokestatic 285	cn/jpush/android/c/r:d	()V
    //   149: aconst_null
    //   150: astore 8
    //   152: aload_0
    //   153: aload_1
    //   154: iconst_0
    //   155: invokevirtual 291	android/content/Context:openFileOutput	(Ljava/lang/String;I)Ljava/io/FileOutputStream;
    //   158: astore 20
    //   160: aload 20
    //   162: astore 8
    //   164: aload 8
    //   166: aload 5
    //   168: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   171: bipush 12
    //   173: aaload
    //   174: invokevirtual 206	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   177: invokevirtual 297	java/io/FileOutputStream:write	([B)V
    //   180: aload 8
    //   182: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   185: aload 4
    //   187: monitorexit
    //   188: iconst_1
    //   189: ireturn
    //   190: astore 21
    //   192: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   195: pop
    //   196: new 119	java/lang/StringBuilder
    //   199: dup
    //   200: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   203: bipush 17
    //   205: aaload
    //   206: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   209: aload_2
    //   210: invokevirtual 202	org/json/JSONObject:toString	()Ljava/lang/String;
    //   213: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   216: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   219: pop
    //   220: invokestatic 285	cn/jpush/android/c/r:d	()V
    //   223: goto -74 -> 149
    //   226: astore 6
    //   228: aload 4
    //   230: monitorexit
    //   231: aload 6
    //   233: athrow
    //   234: astore 16
    //   236: aconst_null
    //   237: astore 17
    //   239: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   242: pop
    //   243: new 119	java/lang/StringBuilder
    //   246: dup
    //   247: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   250: bipush 20
    //   252: aaload
    //   253: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   256: aload_3
    //   257: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   263: bipush 14
    //   265: aaload
    //   266: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   269: aload 16
    //   271: invokevirtual 300	java/io/FileNotFoundException:getMessage	()Ljava/lang/String;
    //   274: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   277: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   280: pop
    //   281: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   284: aload 17
    //   286: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   289: aload 4
    //   291: monitorexit
    //   292: iconst_0
    //   293: ireturn
    //   294: astore 13
    //   296: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   299: pop
    //   300: new 119	java/lang/StringBuilder
    //   303: dup
    //   304: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   307: bipush 18
    //   309: aaload
    //   310: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   313: aload_3
    //   314: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   320: bipush 21
    //   322: aaload
    //   323: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   326: aload 13
    //   328: invokevirtual 218	java/io/UnsupportedEncodingException:getMessage	()Ljava/lang/String;
    //   331: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   334: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   337: pop
    //   338: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   341: aload 8
    //   343: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   346: aload 4
    //   348: monitorexit
    //   349: iconst_0
    //   350: ireturn
    //   351: astore 10
    //   353: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   356: pop
    //   357: new 119	java/lang/StringBuilder
    //   360: dup
    //   361: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   364: bipush 16
    //   366: aaload
    //   367: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   370: aload_3
    //   371: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   374: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   377: bipush 21
    //   379: aaload
    //   380: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   383: aload 10
    //   385: invokevirtual 301	java/io/IOException:getMessage	()Ljava/lang/String;
    //   388: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   391: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   394: pop
    //   395: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   398: aload 8
    //   400: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   403: aload 4
    //   405: monitorexit
    //   406: iconst_0
    //   407: ireturn
    //   408: aload 8
    //   410: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   413: aload 9
    //   415: athrow
    //   416: astore 9
    //   418: aload 17
    //   420: astore 8
    //   422: goto -14 -> 408
    //   425: astore 16
    //   427: aload 8
    //   429: astore 17
    //   431: goto -192 -> 239
    //   434: astore 9
    //   436: goto -28 -> 408
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	439	0	paramContext	Context
    //   0	439	1	paramString	String
    //   0	439	2	paramJSONObject	JSONObject
    //   34	337	3	str1	String
    //   82	322	4	localObject1	Object
    //   89	78	5	str2	String
    //   226	6	6	localObject2	Object
    //   110	3	7	bool	boolean
    //   150	278	8	localObject3	Object
    //   413	1	9	localObject4	Object
    //   416	1	9	localObject5	Object
    //   434	1	9	localObject6	Object
    //   351	33	10	localIOException	IOException
    //   294	33	13	localUnsupportedEncodingException	UnsupportedEncodingException
    //   234	36	16	localFileNotFoundException1	java.io.FileNotFoundException
    //   425	1	16	localFileNotFoundException2	java.io.FileNotFoundException
    //   237	193	17	localObject7	Object
    //   158	3	20	localFileOutputStream	java.io.FileOutputStream
    //   190	1	21	localException	Exception
    // Exception table:
    //   from	to	target	type
    //   117	149	190	java/lang/Exception
    //   95	112	226	finally
    //   117	149	226	finally
    //   180	188	226	finally
    //   192	223	226	finally
    //   284	292	226	finally
    //   341	349	226	finally
    //   398	406	226	finally
    //   408	416	226	finally
    //   152	160	234	java/io/FileNotFoundException
    //   152	160	294	java/io/UnsupportedEncodingException
    //   164	180	294	java/io/UnsupportedEncodingException
    //   152	160	351	java/io/IOException
    //   164	180	351	java/io/IOException
    //   239	284	416	finally
    //   164	180	425	java/io/FileNotFoundException
    //   152	160	434	finally
    //   164	180	434	finally
    //   296	341	434	finally
    //   353	398	434	finally
  }
  
  public static String b()
  {
    try
    {
      InetAddress.getByName(z[30]);
      return f;
    }
    catch (Exception localException) {}
    return d;
  }
  
  public static String b(String paramString)
  {
    try
    {
      String str = c.a(paramString.getBytes(), 10);
      return str;
    }
    catch (Exception localException)
    {
      r.e();
    }
    return null;
  }
  
  /* Error */
  public static JSONObject b(Context paramContext, String paramString)
  {
    // Byte code:
    //   0: aload_1
    //   1: ifnull +10 -> 11
    //   4: aload_1
    //   5: invokevirtual 317	java/lang/String:length	()I
    //   8: ifgt +12 -> 20
    //   11: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   14: pop
    //   15: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   18: aconst_null
    //   19: areturn
    //   20: aload_1
    //   21: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   24: iconst_0
    //   25: aaload
    //   26: invokevirtual 280	java/lang/String:equals	(Ljava/lang/Object;)Z
    //   29: ifeq +44 -> 73
    //   32: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   35: bipush 15
    //   37: aaload
    //   38: astore_3
    //   39: aload_0
    //   40: ifnonnull +43 -> 83
    //   43: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   46: pop
    //   47: new 119	java/lang/StringBuilder
    //   50: dup
    //   51: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   54: bipush 23
    //   56: aaload
    //   57: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   60: aload_3
    //   61: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   64: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   67: pop
    //   68: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   71: aconst_null
    //   72: areturn
    //   73: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   76: bipush 22
    //   78: aaload
    //   79: astore_3
    //   80: goto -41 -> 39
    //   83: aload_0
    //   84: aload_1
    //   85: invokevirtual 321	android/content/Context:openFileInput	(Ljava/lang/String;)Ljava/io/FileInputStream;
    //   88: astore 13
    //   90: aload 13
    //   92: astore 5
    //   94: iconst_1
    //   95: aload 5
    //   97: invokevirtual 326	java/io/FileInputStream:available	()I
    //   100: iadd
    //   101: newarray 慢⁤污潬慣楴湯
    //   104: dconst_0
    //   105: aload 5
    //   107: aload 14
    //   109: invokevirtual 330	java/io/FileInputStream:read	([B)I
    //   112: pop
    //   113: aload 5
    //   115: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   118: new 24	java/lang/String
    //   121: dup
    //   122: aload 14
    //   124: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   127: bipush 12
    //   129: aaload
    //   130: invokespecial 333	java/lang/String:<init>	([BLjava/lang/String;)V
    //   133: astore 16
    //   135: aload 16
    //   137: invokestatic 153	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   140: ifeq +216 -> 356
    //   143: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   146: pop
    //   147: new 119	java/lang/StringBuilder
    //   150: dup
    //   151: invokespecial 171	java/lang/StringBuilder:<init>	()V
    //   154: aload_3
    //   155: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   158: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   161: bipush 27
    //   163: aaload
    //   164: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   167: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   170: pop
    //   171: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   174: aconst_null
    //   175: areturn
    //   176: astore 20
    //   178: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   181: pop
    //   182: new 119	java/lang/StringBuilder
    //   185: dup
    //   186: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   189: bipush 18
    //   191: aaload
    //   192: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   195: aload_3
    //   196: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   199: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   202: bipush 25
    //   204: aaload
    //   205: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   208: aload 20
    //   210: invokevirtual 218	java/io/UnsupportedEncodingException:getMessage	()Ljava/lang/String;
    //   213: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   216: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   219: pop
    //   220: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   223: aconst_null
    //   224: areturn
    //   225: astore 10
    //   227: aconst_null
    //   228: astore 5
    //   230: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   233: pop
    //   234: new 119	java/lang/StringBuilder
    //   237: dup
    //   238: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   241: bipush 20
    //   243: aaload
    //   244: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   247: aload_3
    //   248: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   251: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   254: bipush 24
    //   256: aaload
    //   257: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   260: aload 10
    //   262: invokevirtual 300	java/io/FileNotFoundException:getMessage	()Ljava/lang/String;
    //   265: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   268: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   271: pop
    //   272: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   275: aload 5
    //   277: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   280: aconst_null
    //   281: areturn
    //   282: astore 7
    //   284: aconst_null
    //   285: astore 5
    //   287: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   290: pop
    //   291: new 119	java/lang/StringBuilder
    //   294: dup
    //   295: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   298: bipush 28
    //   300: aaload
    //   301: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   304: aload_3
    //   305: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   308: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   311: bipush 25
    //   313: aaload
    //   314: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   317: aload 7
    //   319: invokevirtual 301	java/io/IOException:getMessage	()Ljava/lang/String;
    //   322: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   325: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   328: pop
    //   329: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   332: aload 5
    //   334: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   337: aconst_null
    //   338: areturn
    //   339: astore 4
    //   341: aconst_null
    //   342: astore 5
    //   344: aload 4
    //   346: astore 6
    //   348: aload 5
    //   350: invokestatic 299	cn/jpush/android/c/w:a	(Ljava/io/Closeable;)V
    //   353: aload 6
    //   355: athrow
    //   356: new 201	org/json/JSONObject
    //   359: dup
    //   360: aload 16
    //   362: invokespecial 334	org/json/JSONObject:<init>	(Ljava/lang/String;)V
    //   365: astore 23
    //   367: aload 23
    //   369: areturn
    //   370: astore 17
    //   372: getstatic 109	cn/jpush/android/c/w:c	Ljava/lang/String;
    //   375: pop
    //   376: new 119	java/lang/StringBuilder
    //   379: dup
    //   380: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   383: bipush 26
    //   385: aaload
    //   386: invokespecial 122	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   389: aload_3
    //   390: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   393: getstatic 102	cn/jpush/android/c/w:z	[Ljava/lang/String;
    //   396: bipush 29
    //   398: aaload
    //   399: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   402: aload 17
    //   404: invokevirtual 335	org/json/JSONException:getMessage	()Ljava/lang/String;
    //   407: invokevirtual 126	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   410: invokevirtual 129	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   413: pop
    //   414: invokestatic 157	cn/jpush/android/c/r:b	()V
    //   417: aconst_null
    //   418: areturn
    //   419: astore 6
    //   421: goto -73 -> 348
    //   424: astore 7
    //   426: goto -139 -> 287
    //   429: astore 10
    //   431: goto -201 -> 230
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	434	0	paramContext	Context
    //   0	434	1	paramString	String
    //   38	352	3	str1	String
    //   339	6	4	localObject1	Object
    //   92	257	5	localFileInputStream1	java.io.FileInputStream
    //   346	8	6	localObject2	Object
    //   419	1	6	localObject3	Object
    //   282	36	7	localIOException1	IOException
    //   424	1	7	localIOException2	IOException
    //   225	36	10	localFileNotFoundException1	java.io.FileNotFoundException
    //   429	1	10	localFileNotFoundException2	java.io.FileNotFoundException
    //   88	3	13	localFileInputStream2	java.io.FileInputStream
    //   103	20	14	arrayOfByte	byte[]
    //   133	228	16	str2	String
    //   370	33	17	localJSONException	JSONException
    //   176	33	20	localUnsupportedEncodingException	UnsupportedEncodingException
    //   365	3	23	localJSONObject	JSONObject
    // Exception table:
    //   from	to	target	type
    //   118	174	176	java/io/UnsupportedEncodingException
    //   356	367	176	java/io/UnsupportedEncodingException
    //   83	90	225	java/io/FileNotFoundException
    //   83	90	282	java/io/IOException
    //   83	90	339	finally
    //   118	174	370	org/json/JSONException
    //   356	367	370	org/json/JSONException
    //   94	113	419	finally
    //   230	275	419	finally
    //   287	332	419	finally
    //   94	113	424	java/io/IOException
    //   94	113	429	java/io/FileNotFoundException
  }
  
  private static void b(Context paramContext, JSONObject paramJSONObject)
  {
    b = paramJSONObject;
    a(paramContext, z[0], paramJSONObject);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.w
 * JD-Core Version:    0.7.1
 */