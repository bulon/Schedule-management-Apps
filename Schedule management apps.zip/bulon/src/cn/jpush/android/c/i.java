package cn.jpush.android.c;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class i
{
  public static String a;
  private static final String z;
  
  static
  {
    String str1 = "Z\031\020E\tn-DX@|(!\006INZ\032O";
    int i = -1;
    Object localObject1 = str1.toCharArray();
    int j = localObject1.length;
    int k;
    label21:
    int i2;
    if (j <= 1)
    {
      k = 0;
      Object localObject2 = localObject1;
      int m = k;
      int n = j;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i1 = localObject3[k];
        switch (m % 5)
        {
        default: 
          i2 = 36;
          label80:
          localObject3[k] = ((char)(i2 ^ i1));
          k = m + 1;
          if (n != 0) {
            break label117;
          }
          localObject3 = localObject2;
          m = k;
          k = n;
        }
      }
      label117:
      j = n;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (j > k) {
        break label21;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        z = str2;
        str1 = "Z\031\020Ein\004\rclk\r\004";
        i = 0;
        break;
        i2 = 35;
        break label80;
        i2 = 96;
        break label80;
        i2 = 105;
        break label80;
        i2 = 60;
        break;
      case 0: 
        a = str2;
        return;
        k = 0;
      }
    }
  }
  
  public static String a()
  {
    return new SimpleDateFormat(z).format(new Date());
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.i
 * JD-Core Version:    0.7.1
 */