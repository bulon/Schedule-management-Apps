package cn.jpush.android.c;

import cn.jpush.android.api.d;
import java.util.Iterator;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class t
{
  public static final Pattern a;
  public static final Pattern b;
  public static final Pattern c;
  public static final Pattern d;
  public static final Pattern e;
  public static final Pattern f;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[3];
    int i = 0;
    String str1 = "e\002丐S龝\013t)\037\025A\030=$gfr4";
    int j = -1;
    Object localObject2 = localObject1;
    int i16;
    label133:
    String str2;
    for (;;)
    {
      Object localObject3 = str1.toCharArray();
      int k = localObject3.length;
      int m = 0;
      if (k <= 1) {}
      while (k > m)
      {
        Object localObject10 = localObject3;
        int i13 = m;
        int i14 = k;
        Object localObject11 = localObject3;
        for (;;)
        {
          int i15 = localObject11[m];
          switch (i13 % 5)
          {
          default: 
            i16 = 56;
            localObject11[m] = ((char)(i16 ^ i15));
            m = i13 + 1;
            if (i14 != 0) {
              break label133;
            }
            localObject11 = localObject10;
            i13 = m;
            m = i14;
          }
        }
        k = i14;
        localObject3 = localObject10;
      }
      str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "e\002丐S龝\013t)\037\025A\030=$gf\" R\f\013$4";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "\023q8VcZtj?\025ai=G\026힦蘿Sﷷ﷋t￿#cZtj?\025ai=G\026힦蘿Sﷷ﷋t￿\"\025fs9TcZtj?\025ai=G\026힦蘿Sﷷ﷋t￿#d\025p;";
        j = 1;
        localObject1 = localObject2;
      }
    }
    localObject1[i] = str2;
    z = (String[])localObject2;
    String str3 = "";
    int n = -1;
    label237:
    String str4;
    for (;;)
    {
      Object localObject4 = str3.toCharArray();
      int i1 = localObject4.length;
      int i2 = 0;
      if (i1 <= 1) {}
      label274:
      label561:
      while (i1 > i2)
      {
        Object localObject8 = localObject4;
        int i9 = i2;
        int i10 = i1;
        Object localObject9 = localObject4;
        int i11 = localObject9[i2];
        int i12;
        switch (i9 % 5)
        {
        default: 
          i12 = 56;
        }
        for (;;)
        {
          localObject9[i2] = ((char)(i12 ^ i11));
          i2 = i9 + 1;
          if (i10 != 0) {
            break label651;
          }
          localObject9 = localObject8;
          i9 = i2;
          i2 = i10;
          break label274;
          i16 = 59;
          break;
          i16 = 89;
          break;
          i16 = 16;
          break;
          i16 = 126;
          break;
          c = Pattern.compile(str4);
          StringBuilder localStringBuilder = new StringBuilder(z[2]).append(a);
          Object localObject5 = "\022%".toCharArray();
          int i3 = localObject5.length;
          int i4 = 0;
          if (i3 <= 1) {}
          while (i3 > i4)
          {
            Object localObject6 = localObject5;
            int i5 = i4;
            int i6 = i3;
            Object localObject7 = localObject5;
            int i7 = localObject7[i4];
            int i8;
            switch (i5 % 5)
            {
            default: 
              i8 = 56;
            }
            for (;;)
            {
              localObject7[i4] = ((char)(i8 ^ i7));
              i4 = i5 + 1;
              if (i6 != 0) {
                break label561;
              }
              localObject7 = localObject6;
              i5 = i4;
              i4 = i6;
              break;
              i8 = 59;
              continue;
              i8 = 89;
              continue;
              i8 = 16;
              continue;
              i8 = 126;
            }
            i3 = i6;
            localObject5 = localObject6;
          }
          d = Pattern.compile(new String((char[])localObject5).intern() + c + ")");
          str3 = "`8=\004y\026\003 S\001grLPdd\0055\"\025grM\005\t\027k%HEg\031K\037\025A\030=$\b\026`M%Y\026#QSb\013t)\"\025f\" R\016\017$8\"\026`8=\004y\026\003 S\001f\002qSBztJN\025\002\005=#C\013u\"KE\022r";
          n = 2;
          break label237;
          i12 = 59;
          continue;
          i12 = 89;
          continue;
          i12 = 16;
          continue;
          i12 = 126;
        }
        i1 = i10;
        localObject4 = localObject8;
      }
      label651:
      str4 = new String((char[])localObject4).intern();
      switch (n)
      {
      case 1: 
      default: 
        a = Pattern.compile(str4);
        str3 = "\023q/D\020S-d\016DS-d\016KG\021d\nHG\021d\nHH%b\nKK%B\nKKp*\"\027gv8A\002\023f*%Y\026#QSb\013t)\"\034gtL!d\025\005;\"\031gsLYd\023\0059\"\024gbLAd\035\005-#D\023f*\"\035`8=\030y\026\037 S\001f\"\"\003\021\022\"!R\016\017$8A\002gc8A\002`8=\004y\026\003 S\001g}LSdd\005>\"\023gxLTd\034\0058\"\021guLEd\004\0056\"\005f%8A\002g|K\037\025]\030=8\b\026`M\005\nFp9\005\t\027k%\003\021\004\005PW\007\022f8V\007\001q/DcZtj?\025ai=G\026힦蘿Sﷷ﷋t￿#cZtj?\025ai=G\026힦蘿Sﷷ﷋t￿\"\025f\" R\016\017$LP\021\020q/D\020\004cq\033JT%q\fHZ%q\rQZ%q%[_<v\031QW4~\021II*d\013OC#MWD\023f*\034QA%r%YY=u\030_S0z\023VT+c\nNL j#\021Gq/D[Z-l\035WV%s\021WK%s%YX=v\031PR2|\023VT+e\b@B#MWD_\002u\024SV6j#D\023f*\033\\N%u%[^>b\rLN\0049\002^`0z\025UT+M\002\020\004cw\021NG>K\037Z_<v\031PR5}\020HJ+c\nML MWDS\002{\023VI-e#D\023f*\027V]6l\027VO%y%\\^5}\020WJ+c\ne\022%8A\002Q6r\rDQ\002u\023WK\0049\002S`<w\026QV7`\fOB#M\002T`8r\035QP+c\nMM M\002\020\004c}\027TG4\034QG4e\r]N4l\023cZ:t\033_S2|\023VT)a\fKO,f\t@B#MWD\023f*\020YV<l\020]O%~%YX<v\031QW6`\fMA\0049\002\020\004c\f_G6}WD\023f*\016JT%`%Y^?w\026SW4~\fKO.i#\021G(q\002J`<\rML\004l\rcZ;s\032]\\1y\024SW4~\021JO,f\007Bf%8A\002O<|\002LI8f\033TG-K\035\\]>x\024SW4~\021HI-f\tBfpl\013cZ>{\rAA\004l\bcZ:u\031QU,M\002O`?c#D\023f*\006VgtLS\bA.}K\016_%h\020d\026\005=O\tYlr\r\013Z`q\024\016\\%h\020d\026\005=F\bZ2x\034AP7zJ^G!~\"\025gt)\n\fYh!\007Q\0168l\006VgtLS\\^;qNY_%h\020d\026\005=\031\016Lk%O\\G!~\"\025gtx\031ZPoq\024\017]l#\034ZZ%h\020d\026\005=\026TX3&\037AZ`u\r[\f8l\006VgtLSRC8|\016\\W)l\006VgtLSS\\;u\035PO/l\006VgtLSBX2j\037P\022%i%]O,M\002B`8}\te\022plV\007\001q/D\n\016\002 S\rf%\"%\b\026mM%\b\026`M\002c\013t!#c\013t)#C\t$l%\t\026`M%\b\026`M\002c\nt)#\021gw8A\002\tlKN\025\016\004lLc\013t$#c\013t)#D`i=Oe`i=Ge@km\002c\nt)#c\013t)#D`h=GeGi9\"\026\023f*L\r`i=KeGkKN\025\017\004KN\025\002\004l%\b\026hM%\b\026`M\005\nF%KO\025\002\004KN\025\002\004l%\t\026`M\002\b\022\005>V\007\001k%%\b\026lM\002\n`i=Je`i=GeG\002 S\tf\002 S\001f\"\"\003D`h=Ge`i=GeG\002 S\001fp9W\020\004cLDd_\"!R\rFp/W\020gv8A\002\023f*%Y\026#QSb\013t)Þ\025ퟄ陵=ﶱ﷈\026ﾶLEd\024\005/\"\002g\031LXd\006\0053\"FgtLPd\020\0051\"\022g~LVd\022\005<\"gfplV\007\001\0055%Y\026?QS~\013t)#C\t$9W\022\022f8A\002g;lZ\021";
        n = 0;
        break;
      case 0: 
        b = Pattern.compile(str4);
        str3 = "\023q\"Kc\013t%#D\t\002 S\ff\002 S\001f%KN\025\n\004KN\025\002\004kLEG\002!S\001f\002 S\001f%KO\025\002\0049\"\026\023k%%\b\026lM\002\n`i=Je`i=GeG\002 S\tf\002 S\001f\"\"\003D`h=Ge`i=GeG\002!S\001f% Wd\025q\"Kc\013t%#D\t\002 S\ff\002 S\001f%KN\025\n\004KN\025\002\004kLEG\002!S\001f\002 S\001f%KO\025\002\004lN\021gw8L\r`i=KeGkKN\025\017\004KN\025\002\004l%\b\026hM%\b\026`M\005\nF%KO\025\002\004KN\025\002\004l%\b\026`MW\021";
        n = 1;
        break;
      case 2: 
        e = Pattern.compile(str4);
        str3 = "\023\005;%\b\026`MUcgt0\"\026fs9A\020gqKN\025\002\004;\"\021`\005=^d\025\004:W\007\023\002 S\001f\002 S\001gt0\"\026f\002 S\001gt0\"\026frKN\025\002\0049";
        n = 3;
      }
    }
    f = Pattern.compile(str4);
  }
  
  public static int a(Set<String> paramSet)
  {
    if ((paramSet == null) || (paramSet.isEmpty())) {
      return 0;
    }
    if (paramSet.size() > 100) {
      return d.g;
    }
    Iterator localIterator = paramSet.iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      if (str.length() > 40) {
        return d.f;
      }
      if (!Pattern.compile(z[0]).matcher(str).matches()) {
        return d.e;
      }
    }
    return 0;
  }
  
  public static boolean a(String paramString)
  {
    if (paramString == null) {
      return false;
    }
    return Pattern.compile(z[1]).matcher(paramString).matches();
  }
  
  public static int b(String paramString)
  {
    if ((paramString == null) || (ac.a(paramString))) {}
    do
    {
      return 0;
      if (paramString.length() > 40) {
        return d.d;
      }
    } while (Pattern.compile(z[0]).matcher(paramString).matches());
    return d.c;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.t
 * JD-Core Version:    0.7.1
 */