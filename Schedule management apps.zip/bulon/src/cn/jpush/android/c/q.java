package cn.jpush.android.c;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

public final class q
{
  public static String[] a(Context paramContext)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    try
    {
      String[] arrayOfString = localPackageManager.getPackageInfo(paramContext.getPackageName(), 4096).requestedPermissions;
      return arrayOfString;
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      r.i();
    }
    return null;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.q
 * JD-Core Version:    0.7.1
 */