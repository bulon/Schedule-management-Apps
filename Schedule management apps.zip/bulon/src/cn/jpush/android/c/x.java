package cn.jpush.android.c;

public abstract interface x {}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.x
 * JD-Core Version:    0.7.1
 */