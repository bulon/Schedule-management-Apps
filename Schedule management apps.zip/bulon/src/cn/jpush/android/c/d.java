package cn.jpush.android.c;

abstract class d
{
  public byte[] a;
  public int b;
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.d
 * JD-Core Version:    0.7.1
 */