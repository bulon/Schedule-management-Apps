package cn.jpush.android.c;

 enum b
{
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[5];
    int i = 0;
    String str1 = "^}W#~RoA&iTfA3sZy[0i^mM";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label35:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label51:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 96;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label51;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "^}W#~RoA&iTfA3bH";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "^}W#~RoA&iTfA%cOnL.zWxJ/iZl[";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "^}W#~RoA&iTfA.~L";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "^}W#~RoA&iTfA3~OW.|";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        a = new b(z[3], 0);
        b = new b(z[4], 1);
        c = new b(z[2], 2);
        d = new b(z[0], 3);
        e = new b(z[1], 4);
        b[] arrayOfb = new b[5];
        arrayOfb[0] = a;
        arrayOfb[1] = b;
        arrayOfb[2] = c;
        arrayOfb[3] = d;
        arrayOfb[4] = e;
        f = arrayOfb;
        return;
        i3 = 59;
        continue;
        i3 = 27;
        continue;
        i3 = 43;
        continue;
        i3 = 30;
      }
    }
  }
  
  private b() {}
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.b
 * JD-Core Version:    0.7.1
 */