package cn.jpush.android.c;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.os.Environment;
import android.preference.PreferenceManager;
import android.text.TextUtils;
import java.io.File;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.UUID;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class k
{
  public static final String a;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[7];
    int i = 0;
    String str1 = "xU";
    int j = -1;
    Object localObject2 = localObject1;
    int i9;
    label133:
    String str2;
    for (;;)
    {
      Object localObject3 = str1.toCharArray();
      int k = localObject3.length;
      int m = 0;
      if (k <= 1) {}
      while (k > m)
      {
        Object localObject7 = localObject3;
        int i6 = m;
        int i7 = k;
        Object localObject8 = localObject3;
        for (;;)
        {
          int i8 = localObject8[m];
          switch (i6 % 5)
          {
          default: 
            i9 = 127;
            localObject8[m] = ((char)(i9 ^ i8));
            m = i6 + 1;
            if (i7 != 0) {
              break label133;
            }
            localObject8 = localObject7;
            i6 = m;
            m = i7;
          }
        }
        k = i7;
        localObject3 = localObject7;
      }
      str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "xV";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "\t<\"bF\n\034!2[";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "\003\017wo\0136\025u*\013w\003{=Ew";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "3\016`";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "3\006f._3\016`u_";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "x&|+\r8\016v`\0336\023s`";
        j = 5;
        localObject1 = localObject2;
      }
    }
    localObject1[i] = str2;
    z = (String[])localObject2;
    StringBuilder localStringBuilder = new StringBuilder().append(File.separator);
    Object localObject4 = "%\016q'".toCharArray();
    int n = localObject4.length;
    int i1 = 0;
    if (n <= 1) {}
    label371:
    label509:
    while (n > i1)
    {
      Object localObject5 = localObject4;
      int i2 = i1;
      int i3 = n;
      Object localObject6 = localObject4;
      int i4 = localObject6[i1];
      int i5;
      switch (i2 % 5)
      {
      default: 
        i5 = 127;
      }
      for (;;)
      {
        localObject6[i1] = ((char)(i5 ^ i4));
        i1 = i2 + 1;
        if (i3 != 0) {
          break label509;
        }
        localObject6 = localObject5;
        i2 = i1;
        i1 = i3;
        break label371;
        i9 = 87;
        break;
        i9 = 103;
        break;
        i9 = 18;
        break;
        i9 = 79;
        break;
        i5 = 87;
        continue;
        i5 = 103;
        continue;
        i5 = 18;
        continue;
        i5 = 79;
      }
      n = i3;
      localObject4 = localObject5;
    }
    a = new String((char[])localObject4).intern() + File.separator;
  }
  
  public static String a(Context paramContext, String paramString)
  {
    String str = paramContext.getFilesDir() + "/" + paramString;
    File localFile = new File(str);
    if (!localFile.exists()) {
      localFile.mkdir();
    }
    return str + "/";
  }
  
  private static String a(String paramString)
  {
    if (TextUtils.isEmpty(paramString)) {
      paramString = "";
    }
    while (paramString.lastIndexOf(File.separator) == 0) {
      return paramString;
    }
    return paramString + File.separator;
  }
  
  public static void a(Context paramContext)
  {
    if (a.a())
    {
      String str1 = e(paramContext);
      String str2 = Environment.getExternalStorageDirectory().getAbsolutePath();
      File localFile1 = new File(str2 + str1);
      if (!localFile1.isDirectory()) {
        localFile1.mkdirs();
      }
      File localFile2 = new File(str2 + str1 + z[1]);
      if (!localFile2.isDirectory()) {
        localFile2.mkdirs();
      }
      File localFile3 = new File(str2 + str1 + z[0]);
      if (!localFile3.isDirectory()) {
        localFile3.mkdirs();
      }
      File localFile4 = new File(str2 + str1 + File.separator + paramContext.getPackageName());
      if (!localFile4.isDirectory()) {
        localFile4.mkdirs();
      }
      return;
    }
    r.e();
  }
  
  private static boolean a(File paramFile)
  {
    for (;;)
    {
      int j;
      try
      {
        if (!paramFile.exists()) {
          return false;
        }
        if (paramFile.isFile()) {
          return paramFile.delete();
        }
        String[] arrayOfString = paramFile.list();
        int i = arrayOfString.length;
        j = 0;
        if (j < i)
        {
          File localFile = new File(paramFile, arrayOfString[j]);
          if (localFile.isDirectory()) {
            a(localFile);
          } else {
            localFile.delete();
          }
        }
      }
      catch (Exception localException)
      {
        r.e();
        return false;
      }
      boolean bool = paramFile.delete();
      return bool;
      j++;
    }
  }
  
  public static String b(Context paramContext)
  {
    if (a.a())
    {
      String str1 = a(Environment.getExternalStorageDirectory().getAbsolutePath());
      String str2 = str1 + e(paramContext) + z[1];
      if (!new File(str2).isDirectory()) {
        a(paramContext);
      }
      return str2 + File.separator;
    }
    return "";
  }
  
  public static String b(Context paramContext, String paramString)
  {
    if (a.a())
    {
      String str2 = Environment.getExternalStorageDirectory().getAbsolutePath();
      String str3 = str2 + z[6] + paramContext.getPackageName() + File.separator + paramString + File.separator;
      File localFile3 = new File(str3);
      if (!localFile3.exists()) {
        localFile3.mkdirs();
      }
      return str3;
    }
    File localFile1 = new File(paramContext.getFilesDir() + a);
    if ((localFile1.exists()) && (localFile1.isDirectory()))
    {
      File[] arrayOfFile = localFile1.listFiles();
      if (arrayOfFile.length > 10)
      {
        Arrays.sort(arrayOfFile, new l());
        a(arrayOfFile[(-1 + arrayOfFile.length)]);
      }
    }
    String str1 = paramContext.getFilesDir() + a + paramString;
    File localFile2 = new File(str1);
    if (!localFile2.exists()) {
      localFile2.mkdirs();
    }
    return str1 + "/";
  }
  
  public static String c(Context paramContext)
  {
    if (a.a())
    {
      String str1 = a(Environment.getExternalStorageDirectory().getAbsolutePath());
      String str2 = str1 + e(paramContext) + z[0];
      if (!new File(str2).isDirectory()) {
        a(paramContext);
      }
      return str2 + "/";
    }
    return "";
  }
  
  public static void d(Context paramContext)
  {
    File[] arrayOfFile = paramContext.getFilesDir().listFiles();
    int i = arrayOfFile.length;
    int j = 0;
    if (j < i)
    {
      File localFile = arrayOfFile[j];
      String str = localFile.getName();
      if (TextUtils.isEmpty(str)) {}
      for (boolean bool = false;; bool = Pattern.compile(z[2]).matcher(str).matches())
      {
        if (bool) {
          m.a(localFile.getAbsolutePath());
        }
        j++;
        break;
      }
    }
  }
  
  private static String e(Context paramContext)
  {
    SharedPreferences localSharedPreferences = PreferenceManager.getDefaultSharedPreferences(paramContext);
    String str1 = localSharedPreferences.getString(z[4], "");
    String str3;
    File localFile1;
    String str4;
    if (TextUtils.isEmpty(str1))
    {
      String str2 = Environment.getExternalStorageDirectory().getAbsolutePath();
      str3 = z[6];
      localFile1 = new File(str2 + str3);
      if (!localFile1.exists()) {
        break label299;
      }
      ArrayList localArrayList = new ArrayList();
      for (File localFile2 : localFile1.listFiles()) {
        if (localFile2.isDirectory())
        {
          localArrayList.add(localFile2.getName());
          new StringBuilder(z[5]).append(localFile2.getName()).toString();
          r.a();
        }
      }
      int k = localArrayList.size();
      if (k <= 0) {
        break label265;
      }
      String str5 = (String)localArrayList.get(k / 2);
      str4 = str3 + str5;
    }
    for (;;)
    {
      new StringBuilder(z[3]).append(str4).toString();
      r.c();
      localSharedPreferences.edit().putString(z[4], str4).commit();
      return str1;
      label265:
      str4 = str3 + UUID.randomUUID().toString().substring(0, 5);
      continue;
      label299:
      localFile1.mkdirs();
      str4 = str3 + UUID.randomUUID().toString().substring(0, 5);
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.k
 * JD-Core Version:    0.7.1
 */