package cn.jpush.android.c;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class ab
{
  public static String a;
  public static int b;
  public static int c;
  public static int d;
  public static int e;
  private static final String z;
  
  static
  {
    Object localObject1 = "p\026P26D\"\004/)'aqvdUZ8".toCharArray();
    int i = localObject1.length;
    int j = 0;
    Object localObject2;
    int k;
    int m;
    Object localObject3;
    label27:
    int n;
    int i1;
    if (i <= 1)
    {
      localObject2 = localObject1;
      k = j;
      m = i;
      localObject3 = localObject1;
      n = localObject3[j];
      switch (k % 5)
      {
      default: 
        i1 = 27;
      }
    }
    for (;;)
    {
      localObject3[j] = ((char)(i1 ^ n));
      j = k + 1;
      if (m == 0)
      {
        localObject3 = localObject2;
        k = j;
        j = m;
        break label27;
      }
      i = m;
      localObject1 = localObject2;
      if (i > j) {
        break;
      }
      z = new String((char[])localObject1).intern();
      a = new SimpleDateFormat(z).format(new Date());
      return;
      i1 = 9;
      continue;
      i1 = 111;
      continue;
      i1 = 41;
      continue;
      i1 = 75;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.ab
 * JD-Core Version:    0.7.1
 */