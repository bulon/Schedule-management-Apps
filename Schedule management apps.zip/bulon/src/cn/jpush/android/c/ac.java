package cn.jpush.android.c;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

public final class ac
{
  private static String a;
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = "&v\t";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 63;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "[\003\016;\013^\004\0130\006*pLz-";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        a = z[1];
        return;
        i3 = 107;
        break label96;
        i3 = 50;
        break label96;
        i3 = 60;
        break label96;
        i3 = 8;
        break label96;
        m = 0;
      }
    }
  }
  
  public static boolean a(String paramString)
  {
    if (paramString == null) {}
    while ((paramString.length() == 0) || (paramString.trim().length() == 0)) {
      return true;
    }
    return false;
  }
  
  public static boolean a(String paramString1, String paramString2)
  {
    if (paramString1 == null) {}
    while (paramString2 == null) {
      return false;
    }
    return paramString1.equals(paramString2);
  }
  
  public static String b(String paramString)
  {
    int i = 0;
    if ((paramString == null) || ("".equals(paramString))) {
      return null;
    }
    try
    {
      MessageDigest localMessageDigest = MessageDigest.getInstance(z[0]);
      localMessageDigest.update(paramString.getBytes());
      byte[] arrayOfByte = localMessageDigest.digest();
      if (arrayOfByte == null) {
        return "";
      }
      StringBuffer localStringBuffer = new StringBuffer(2 * arrayOfByte.length);
      while (i < arrayOfByte.length)
      {
        int j = arrayOfByte[i];
        localStringBuffer.append(z[1].charAt(0xF & j >> 4)).append(z[1].charAt(j & 0xF));
        i++;
      }
      String str = localStringBuffer.toString();
      return str;
    }
    catch (NoSuchAlgorithmException localNoSuchAlgorithmException) {}
    return null;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.ac
 * JD-Core Version:    0.7.1
 */