package cn.jpush.android.c;

import android.content.Context;
import android.text.TextUtils;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

public final class m
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[4];
    String str1 = ":V\03222";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 10;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "!W\020S*\fm2ko\027v";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "\016a(ve\0018?mo\016v9W~\002n\032vf\n\"q?l\006n9Ok\033jf";
        j = 2;
        arrayOfString2 = arrayOfString1;
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        j = 3;
        arrayOfString2 = arrayOfString1;
        str1 = "C\"?pd\033g2k0";
        i = 2;
        break;
      case 2: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 111;
        break label96;
        i3 = 2;
        break label96;
        i3 = 92;
        break label96;
        i3 = 31;
        break label96;
        m = 0;
      }
    }
  }
  
  public static ArrayList<String> a(InputStream paramInputStream)
  {
    ArrayList localArrayList = new ArrayList();
    BufferedReader localBufferedReader;
    try
    {
      InputStreamReader localInputStreamReader = new InputStreamReader(paramInputStream, z[0]);
      localBufferedReader = new BufferedReader(localInputStreamReader, 2048);
      for (;;)
      {
        String str1 = localBufferedReader.readLine();
        if (str1 == null) {
          break;
        }
        String str2 = str1.trim();
        if (!"".equals(str2)) {
          localArrayList.add(str2);
        }
      }
      localInputStreamReader.close();
    }
    catch (Exception localException)
    {
      localException.getMessage();
      r.e();
      return localArrayList;
    }
    localBufferedReader.close();
    return localArrayList;
  }
  
  public static void a(String paramString)
  {
    File localFile1 = new File(paramString);
    if (localFile1.exists())
    {
      if (localFile1.isDirectory()) {
        for (File localFile2 : localFile1.listFiles())
        {
          a(localFile2.getAbsolutePath());
          localFile2.delete();
        }
      }
      localFile1.delete();
    }
  }
  
  /* Error */
  public static boolean a(String paramString1, String paramString2, Context paramContext)
  {
    // Byte code:
    //   0: aload_2
    //   1: ifnonnull +16 -> 17
    //   4: new 106	java/lang/IllegalArgumentException
    //   7: dup
    //   8: getstatic 32	cn/jpush/android/c/m:z	[Ljava/lang/String;
    //   11: iconst_1
    //   12: aaload
    //   13: invokespecial 107	java/lang/IllegalArgumentException:<init>	(Ljava/lang/String;)V
    //   16: athrow
    //   17: new 109	java/lang/StringBuilder
    //   20: dup
    //   21: getstatic 32	cn/jpush/android/c/m:z	[Ljava/lang/String;
    //   24: iconst_2
    //   25: aaload
    //   26: invokespecial 110	java/lang/StringBuilder:<init>	(Ljava/lang/String;)V
    //   29: aload_0
    //   30: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   33: getstatic 32	cn/jpush/android/c/m:z	[Ljava/lang/String;
    //   36: iconst_3
    //   37: aaload
    //   38: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   41: aload_1
    //   42: invokevirtual 114	java/lang/StringBuilder:append	(Ljava/lang/String;)Ljava/lang/StringBuilder;
    //   45: invokevirtual 117	java/lang/StringBuilder:toString	()Ljava/lang/String;
    //   48: pop
    //   49: invokestatic 119	cn/jpush/android/c/r:a	()V
    //   52: aload_0
    //   53: invokestatic 125	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   56: ifne +89 -> 145
    //   59: aload_1
    //   60: invokestatic 125	android/text/TextUtils:isEmpty	(Ljava/lang/CharSequence;)Z
    //   63: ifne +82 -> 145
    //   66: new 80	java/io/File
    //   69: dup
    //   70: aload_0
    //   71: invokespecial 82	java/io/File:<init>	(Ljava/lang/String;)V
    //   74: astore 4
    //   76: aload 4
    //   78: invokevirtual 86	java/io/File:exists	()Z
    //   81: ifne +9 -> 90
    //   84: aload 4
    //   86: invokevirtual 128	java/io/File:createNewFile	()Z
    //   89: pop
    //   90: new 130	java/io/FileOutputStream
    //   93: dup
    //   94: aload 4
    //   96: invokespecial 133	java/io/FileOutputStream:<init>	(Ljava/io/File;)V
    //   99: astore 6
    //   101: aload 6
    //   103: aload_1
    //   104: getstatic 32	cn/jpush/android/c/m:z	[Ljava/lang/String;
    //   107: iconst_0
    //   108: aaload
    //   109: invokevirtual 137	java/lang/String:getBytes	(Ljava/lang/String;)[B
    //   112: invokevirtual 141	java/io/FileOutputStream:write	([B)V
    //   115: aload 6
    //   117: invokevirtual 144	java/io/FileOutputStream:flush	()V
    //   120: aload 6
    //   122: invokevirtual 145	java/io/FileOutputStream:close	()V
    //   125: iconst_1
    //   126: ireturn
    //   127: aload 6
    //   129: ifnull +8 -> 137
    //   132: aload 6
    //   134: invokevirtual 145	java/io/FileOutputStream:close	()V
    //   137: aload 7
    //   139: athrow
    //   140: astore 5
    //   142: invokestatic 148	cn/jpush/android/c/r:g	()V
    //   145: iconst_0
    //   146: ireturn
    //   147: astore 7
    //   149: goto -22 -> 127
    //   152: astore 7
    //   154: aconst_null
    //   155: astore 6
    //   157: goto -30 -> 127
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	160	0	paramString1	String
    //   0	160	1	paramString2	String
    //   0	160	2	paramContext	Context
    //   74	21	4	localFile	File
    //   140	1	5	localIOException	java.io.IOException
    //   99	57	6	localFileOutputStream	FileOutputStream
    //   137	1	7	localObject1	Object
    //   147	1	7	localObject2	Object
    //   152	1	7	localObject3	Object
    // Exception table:
    //   from	to	target	type
    //   66	90	140	java/io/IOException
    //   120	125	140	java/io/IOException
    //   132	137	140	java/io/IOException
    //   137	140	140	java/io/IOException
    //   101	120	147	finally
    //   90	101	152	finally
  }
  
  public static boolean a(String paramString, byte[] paramArrayOfByte, Context paramContext)
  {
    k.a(paramContext);
    if ((!TextUtils.isEmpty(paramString)) && (paramArrayOfByte.length > 0))
    {
      File localFile = new File(paramString);
      if (!localFile.exists()) {
        localFile.createNewFile();
      }
      try
      {
        localFileOutputStream = new FileOutputStream(localFile);
        if (localFileOutputStream == null) {
          break label80;
        }
      }
      finally
      {
        try
        {
          localFileOutputStream.write(paramArrayOfByte);
          localFileOutputStream.flush();
          localFileOutputStream.close();
          return true;
        }
        finally
        {
          FileOutputStream localFileOutputStream;
          break label70;
        }
        localObject1 = finally;
        localFileOutputStream = null;
      }
      label70:
      localFileOutputStream.close();
      label80:
      throw ((Throwable)localObject1);
    }
    else
    {
      return false;
    }
  }
  
  public static String b(String paramString)
  {
    if (!ac.a(paramString))
    {
      int i = paramString.lastIndexOf(".");
      int j = paramString.length();
      if ((i > 0) && (i + 1 != j)) {
        return paramString.substring(i, paramString.length());
      }
    }
    return "";
  }
  
  public static String c(String paramString)
  {
    if (ac.a(paramString)) {
      return "";
    }
    return paramString.substring(1 + paramString.lastIndexOf("/"), paramString.length());
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.c.m
 * JD-Core Version:    0.7.1
 */