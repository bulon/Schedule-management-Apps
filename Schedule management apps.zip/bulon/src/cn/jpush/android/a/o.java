package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.c.h;
import cn.jpush.android.c.r;
import java.util.ArrayList;
import org.json.JSONObject;

public final class o
  extends d
{
  private static final String[] ab;
  public int V;
  public boolean W;
  public ArrayList<String> X = new ArrayList();
  public String Y = "";
  public String Z = "";
  public String a;
  public String aa;
  
  static
  {
    Object localObject1 = new String[6];
    int i = 0;
    String str1 = "w\035B\020\027n";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 98;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "f-o\033\021";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "f-n\026\rt";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "f-h\f\016";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "f-x\f\007p";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        ab = (String[])localObject2;
        return;
        i3 = 3;
        continue;
        i3 = 114;
        continue;
        i3 = 29;
        continue;
        i3 = 126;
      }
    }
  }
  
  public o()
  {
    this.n = 0;
  }
  
  public final void a(Context paramContext)
  {
    r.a();
    new p(this, paramContext, this).start();
  }
  
  public final boolean a(Context paramContext, JSONObject paramJSONObject)
  {
    r.a();
    this.a = paramJSONObject.optString(ab[4], "").trim();
    this.V = paramJSONObject.optInt(ab[3], 0);
    if (paramJSONObject.optInt(ab[2], 0) == 0) {}
    for (boolean bool = true;; bool = false)
    {
      this.W = bool;
      if (this.W) {
        this.X = h.a(paramJSONObject.optJSONArray(ab[5]));
      }
      this.Y = paramJSONObject.optString(ab[1], "");
      this.Z = paramJSONObject.optString(ab[0], "");
      return true;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.o
 * JD-Core Version:    0.7.1
 */