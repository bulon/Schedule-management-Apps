package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.api.k;
import cn.jpush.android.c.a;
import cn.jpush.android.c.r;
import cn.jpush.android.service.ServiceInterface;
import org.json.JSONObject;

public final class q
  extends h
{
  private static final String[] bb;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = "<b4 65}(";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 69;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "\b|4\021**|\f-2e\022*9wRe";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        bb = arrayOfString1;
        return;
        i3 = 93;
        break label96;
        i3 = 18;
        break label96;
        i3 = 95;
        break label96;
        i3 = 127;
        break label96;
        m = 0;
      }
    }
  }
  
  public q()
  {
    this.n = 3;
    this.ac = null;
  }
  
  public final void a(Context paramContext)
  {
    
    if (l.a(this.X, this.Y, paramContext))
    {
      ServiceInterface.a(paramContext, this);
      return;
    }
    if (this.aa == 1)
    {
      paramContext.startActivity(a.a(paramContext, this, true));
      return;
    }
    if (this.aa == 0)
    {
      k.a(paramContext, this, true, true);
      return;
    }
    new StringBuilder(bb[1]).append(this.aa).toString();
    r.b();
  }
  
  public final boolean a(Context paramContext, JSONObject paramJSONObject)
  {
    r.a();
    boolean bool = super.a(paramContext, paramJSONObject);
    this.aa = paramJSONObject.optInt(bb[0], 0);
    return bool;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.q
 * JD-Core Version:    0.7.1
 */