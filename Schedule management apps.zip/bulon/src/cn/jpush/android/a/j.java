package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.c.ac;
import cn.jpush.android.service.ServiceInterface;

final class j
  extends Thread
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = "0\025\033%/\033";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 122;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "0\025\033%/\037";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 70;
        break label96;
        i3 = 124;
        break label96;
        i3 = 26;
        break label96;
        i3 = 108;
        break label96;
        m = 0;
      }
    }
  }
  
  j(h paramh1, Context paramContext, int paramInt, h paramh2) {}
  
  public final void run()
  {
    if (l.a(this.d.ac.b)) {
      this.d.ac.l = d.a(this.d.ac.b, this.d.c, z[1], this.a);
    }
    if (l.a(this.d.ac.h)) {
      this.d.ac.m = d.a(this.d.ac.h, this.d.c, z[0], this.a);
    }
    if ((ac.a(this.d.ac.l)) || (ac.a(this.d.ac.m)))
    {
      ServiceInterface.a(this.d.c, 1014, this.a);
      return;
    }
    ServiceInterface.a(this.d.c, this.b, this.a);
    h.a(this.d, this.c, this.a);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.j
 * JD-Core Version:    0.7.1
 */