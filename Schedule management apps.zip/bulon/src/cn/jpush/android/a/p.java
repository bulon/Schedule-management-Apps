package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.c.a;
import cn.jpush.android.c.m;
import cn.jpush.android.c.n;
import cn.jpush.android.c.r;
import cn.jpush.android.service.ServiceInterface;

final class p
  extends Thread
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[3];
    String str1 = "/akLA\037lzQU@/{ZZ\024`yZ\021\tgaC\021ZbaPTZ\".";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 49;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "\034fbQ\013U ";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        j = 2;
        arrayOfString2 = arrayOfString1;
        str1 = "TgzY]";
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 122;
        break label96;
        i3 = 15;
        break label96;
        i3 = 14;
        break label96;
        i3 = 52;
        break label96;
        m = 0;
      }
    }
  }
  
  p(o paramo1, Context paramContext, o paramo2) {}
  
  public final void run()
  {
    if (this.c.V == 1)
    {
      ServiceInterface.a(this.c.c, 995, this.a);
      cn.jpush.android.api.k.a(this.a, this.c);
    }
    String str1;
    String str2;
    do
    {
      str1 = this.b.c;
      str2 = this.b.a;
      if (this.c.W) {
        break;
      }
      ServiceInterface.a(str1, 995, this.a);
      cn.jpush.android.api.k.a(this.a, this.b);
      do
      {
        return;
      } while ((this.c.R.equals("0")) || (this.c.R.length() > 1));
    } while (this.c.V == 0);
    new StringBuilder(z[0]).append(this.c.V).toString();
    r.b();
    return;
    if (!l.a(str2))
    {
      ServiceInterface.a(str1, 996, this.a);
      return;
    }
    String str3 = null;
    int i = 0;
    String str4;
    if (i < 4)
    {
      str3 = n.a(str2, 5, 5000L);
      if (!n.a(str3)) {
        str4 = str3;
      }
    }
    for (int j = 1;; j = 0)
    {
      if (j == 0)
      {
        r.b();
        ServiceInterface.a(str1, 1014, this.a);
        ServiceInterface.a(str1, 1021, a.b(this.a, str2), this.a);
        return;
        i++;
        break;
      }
      String str5 = str2.substring(0, 1 + str2.lastIndexOf("/"));
      boolean bool = d.a(this.b.X, this.a, str5, str1, this.b.f());
      if ((this.c.p) && (!bool))
      {
        r.b();
        ServiceInterface.a(str1, 1014, this.a);
        return;
      }
      if (this.b.f()) {}
      for (String str6 = cn.jpush.android.c.k.b(this.a, str1) + str1 + z[2]; m.a(str6, str4, this.a); str6 = cn.jpush.android.c.k.a(this.a, str1) + str1)
      {
        this.b.aa = (z[1] + str6);
        ServiceInterface.a(str1, 995, this.a);
        cn.jpush.android.api.k.a(this.a, this.b);
        return;
      }
      ServiceInterface.a(str1, 1014, this.a);
      return;
      str4 = str3;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.p
 * JD-Core Version:    0.7.1
 */