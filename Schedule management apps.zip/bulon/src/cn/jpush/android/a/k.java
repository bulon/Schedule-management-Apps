package cn.jpush.android.a;

import java.io.Serializable;
import java.util.ArrayList;
import org.json.JSONException;
import org.json.JSONObject;

public final class k
  implements Serializable
{
  private static final String[] z;
  public String a;
  public String b;
  public String c;
  public String d;
  public boolean e;
  public String f;
  public String g;
  public String h;
  public boolean i;
  public String j;
  public ArrayList<String> k = new ArrayList();
  public String l;
  public String m;
  public String n;
  
  static
  {
    Object localObject1 = new String[14];
    int i1 = 0;
    String str1 = "8\byvB\006\030yDs\023\027";
    int i2 = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int i3 = localObject3.length;
    int i4 = 0;
    label36:
    Object localObject4;
    int i5;
    int i6;
    Object localObject5;
    label52:
    int i7;
    int i8;
    if (i3 <= 1)
    {
      localObject4 = localObject3;
      i5 = i4;
      i6 = i3;
      localObject5 = localObject3;
      i7 = localObject5[i4];
      switch (i5 % 5)
      {
      default: 
        i8 = 18;
      }
    }
    for (;;)
    {
      localObject5[i4] = ((char)(i8 ^ i7));
      i4 = i5 + 1;
      if (i6 == 0)
      {
        localObject5 = localObject4;
        i5 = i4;
        i4 = i6;
        break label52;
      }
      i3 = i6;
      localObject3 = localObject4;
      if (i3 > i4) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (i2)
      {
      default: 
        localObject1[i1] = str2;
        i1 = 1;
        str1 = "8\026quu\002/}`z";
        localObject1 = localObject2;
        i2 = 0;
        break;
      case 0: 
        localObject1[i1] = str2;
        i1 = 2;
        str1 = "8\026{|7\036h|";
        i2 = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i1] = str2;
        i1 = 3;
        str1 = "\006 uzt\b";
        i2 = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i1] = str2;
        i1 = 4;
        str1 = "\006 hmb\002";
        i2 = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i1] = str2;
        i1 = 5;
        str1 = "\006 ya`\013";
        i2 = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i1] = str2;
        i1 = 6;
        str1 = "\006 o}h\002";
        i2 = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i1] = str2;
        i1 = 7;
        str1 = "\006 uw}\t if~";
        i2 = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i1] = str2;
        i1 = 8;
        str1 = "\006 nqa";
        i2 = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i1] = str2;
        i1 = 9;
        str1 = "\006 jq`";
        i2 = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i1] = str2;
        i1 = 10;
        str1 = "\006 ow}\025\032";
        i2 = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i1] = str2;
        i1 = 11;
        str1 = "\006 yfw\024";
        i2 = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i1] = str2;
        i1 = 12;
        str1 = "\006 h}f\013\032";
        i2 = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i1] = str2;
        i1 = 13;
        str1 = "";
        i2 = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i1] = str2;
        z = (String[])localObject2;
        return;
        i8 = 103;
        continue;
        i8 = 127;
        continue;
        i8 = 28;
        continue;
        i8 = 20;
      }
    }
  }
  
  public k(h paramh) {}
  
  private JSONObject a()
  {
    localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put(z[12], this.a);
      localJSONObject.put(z[7], this.b);
      localJSONObject.put(z[9], this.c);
      localJSONObject.put(z[4], this.d);
      String str1 = z[10];
      int i1;
      String str2;
      int i2;
      if (this.e)
      {
        i1 = 0;
        localJSONObject.put(str1, i1);
        localJSONObject.put(z[6], this.f);
        localJSONObject.put(z[3], this.g);
        localJSONObject.put(z[13], this.h);
        localJSONObject.put(z[5], this.j);
        str2 = z[8];
        boolean bool = this.i;
        i2 = 0;
        if (!bool) {
          break label209;
        }
      }
      for (;;)
      {
        localJSONObject.put(str2, i2);
        localJSONObject.put(z[11], cn.jpush.android.c.h.a(this.k));
        return localJSONObject;
        i1 = 1;
        break;
        label209:
        i2 = 1;
      }
      return localJSONObject;
    }
    catch (JSONException localJSONException) {}
  }
  
  public final String toString()
  {
    JSONObject localJSONObject = a();
    try
    {
      localJSONObject.put(z[2], this.l);
      localJSONObject.put(z[1], this.m);
      localJSONObject.put(z[0], this.n);
      label47:
      return localJSONObject.toString();
    }
    catch (JSONException localJSONException)
    {
      break label47;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.k
 * JD-Core Version:    0.7.1
 */