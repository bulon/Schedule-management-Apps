package cn.jpush.android.a;

import android.content.Context;
import android.text.TextUtils;
import cn.jpush.android.c.ac;
import cn.jpush.android.service.ServiceInterface;
import org.json.JSONException;
import org.json.JSONObject;

public final class l
{
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[27];
    int i = 0;
    String str1 = "=\032YX<$ TC";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 82;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "\036\020v{r3*TC7(1";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "1!e^6";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "1&N^=>JV # uE;7,TV>\0356]z7#6[P7ph\032X 9\"SY3<\017IX<jO";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "\005+QY='eWD5p1CG7ph\032";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "1!eC";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "=6]h;4";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "#-U@\r$<JR";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "\026$S[74eNXr7 N\0278#*T\0274\"*W\027'\")\032U73$OD7?#\032^<&$V^6p0H[r}e";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "\036\n\032z\001\027\f~";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "1&N^=>VX34\bIP\030#*Tq ?(oE>ph\032";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "\005+QY='+\032z\001\027eJE=$*YX>p3_E!9*T\031r\027,LRr%5\032\032r";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "3*TC7>1eC+  ";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "\",Y_\r= ^^3";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "?3_E 9!_h?#\"e^6";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = ">\032UY>)";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "\036\nez\001\027\f~";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "= ID37 ";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = ">\032XB;<!_E\r9!";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "%7V";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "$<JR";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "$,N[7";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "5=NE3#";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "\007\f|~";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "\016\036RC& 9RC& 6g\034hj\024\035";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "\031+LV>9!\032B <e\027\027";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        return;
        i3 = 80;
        continue;
        i3 = 69;
        continue;
        i3 = 58;
        continue;
        i3 = 55;
      }
    }
  }
  
  public static a a(Context paramContext, String paramString1, String paramString2, String paramString3)
  {
    new StringBuilder(z[15]).append(paramString1).toString();
    cn.jpush.android.c.r.b();
    if (paramContext == null) {
      throw new IllegalArgumentException(z[1]);
    }
    if (TextUtils.isEmpty(paramString1))
    {
      cn.jpush.android.c.r.e();
      ServiceInterface.a(z[9], 996, paramContext);
    }
    JSONObject localJSONObject1;
    do
    {
      return null;
      localJSONObject1 = a(paramContext, z[17], paramString1);
    } while (localJSONObject1 == null);
    String str = localJSONObject1.optString(z[6], "");
    if (ac.a(str)) {
      str = localJSONObject1.optString(z[2], "");
    }
    if (localJSONObject1.optInt(z[16], 0) == 1) {}
    for (boolean bool = true;; bool = false)
    {
      int i = 0;
      if (bool) {
        i = localJSONObject1.optInt(z[19], 0);
      }
      a locala = new a();
      locala.c = str;
      locala.a = localJSONObject1;
      locala.b = localJSONObject1.optInt(z[7], 3);
      locala.e = bool;
      locala.f = i;
      locala.h = localJSONObject1.optString(z[18], "");
      locala.i = localJSONObject1.optString(z[12], "");
      locala.j = localJSONObject1.optString(z[22], "");
      locala.k = localJSONObject1.optString(z[23], "");
      locala.l = paramString2;
      locala.m = paramString3;
      locala.d = localJSONObject1.optString(z[14], "");
      if (!ac.a(locala.h))
      {
        JSONObject localJSONObject2 = a(paramContext, str, localJSONObject1, z[13]);
        if (localJSONObject2 != null)
        {
          locala.a(localJSONObject2.optString(z[20], ""));
          locala.S = localJSONObject2.optString(z[21], "");
          locala.a(true);
        }
      }
      return locala;
    }
  }
  
  private static JSONObject a(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      JSONObject localJSONObject = new JSONObject(paramString2);
      return localJSONObject;
    }
    catch (JSONException localJSONException)
    {
      cn.jpush.android.c.r.i();
      ServiceInterface.a(paramString1, 996, paramContext);
    }
    return null;
  }
  
  public static JSONObject a(Context paramContext, String paramString1, JSONObject paramJSONObject, String paramString2)
  {
    if (paramJSONObject == null)
    {
      cn.jpush.android.c.r.d();
      ServiceInterface.a(paramString1, 996, paramContext);
    }
    for (;;)
    {
      return null;
      if (TextUtils.isEmpty(paramString2))
      {
        cn.jpush.android.c.r.d();
        return null;
      }
      try
      {
        if (!paramJSONObject.isNull(paramString2))
        {
          JSONObject localJSONObject = paramJSONObject.getJSONObject(paramString2);
          return localJSONObject;
        }
      }
      catch (JSONException localJSONException)
      {
        cn.jpush.android.c.r.i();
        ServiceInterface.a(paramString1, 996, paramContext);
      }
    }
    return null;
  }
  
  public static void a(Context paramContext, a parama)
  {
    
    if (paramContext == null) {
      throw new IllegalArgumentException(z[1]);
    }
    int i = parama.b;
    JSONObject localJSONObject1 = parama.a;
    String str1 = parama.c;
    String str2;
    if (i == 2)
    {
      str2 = localJSONObject1.optString(z[0], "").trim();
      if (a(str2)) {
        b(paramContext, str2, str1);
      }
    }
    JSONObject localJSONObject2;
    do
    {
      return;
      new StringBuilder(z[8]).append(str2).toString();
      cn.jpush.android.c.r.b();
      ServiceInterface.a(str1, 996, paramContext);
      return;
      if ((i != 1) && (i != 3) && (i != 4)) {
        break;
      }
      localJSONObject2 = a(paramContext, str1, localJSONObject1, z[0]);
    } while (localJSONObject2 == null);
    int j = localJSONObject2.optInt(z[5], -1);
    Object localObject;
    switch (j)
    {
    default: 
      new StringBuilder(z[4]).append(j).toString();
      cn.jpush.android.c.r.d();
      ServiceInterface.a(str1, 996, paramContext);
      return;
      new StringBuilder(z[11]).append(i).toString();
      cn.jpush.android.c.r.b();
      ServiceInterface.a(str1, 996, paramContext);
      return;
    case 0: 
      localObject = new o();
    }
    for (;;)
    {
      ((d)localObject).c = str1;
      ((d)localObject).b = i;
      ((d)localObject).n = j;
      ((d)localObject).g = parama.g;
      ((d)localObject).e = parama.e;
      ((d)localObject).f = parama.f;
      ((d)localObject).l = parama.l;
      ((d)localObject).d = parama.d;
      boolean bool = ((d)localObject).b(paramContext, localJSONObject2);
      cn.jpush.android.c.r.a();
      if (!bool) {
        break;
      }
      ((d)localObject).a(paramContext);
      cn.jpush.android.c.r.a();
      return;
      localObject = new h();
      continue;
      localObject = new r();
      continue;
      localObject = new q();
    }
    cn.jpush.android.c.r.d();
  }
  
  public static void a(Context paramContext, String paramString)
  {
    new StringBuilder(z[3]).append(paramString).toString();
    cn.jpush.android.c.r.a();
    if (paramContext == null) {
      throw new IllegalArgumentException(z[1]);
    }
    if (TextUtils.isEmpty(paramString)) {
      cn.jpush.android.c.r.e();
    }
    for (;;)
    {
      return;
      JSONObject localJSONObject1 = a(paramContext, z[9], paramString);
      if (localJSONObject1 != null)
      {
        String str1 = localJSONObject1.optString(z[6], "");
        if (ac.a(str1)) {
          str1 = localJSONObject1.optString(z[2], "");
        }
        int i = localJSONObject1.optInt(z[7], -1);
        if (i == 2)
        {
          String str2 = localJSONObject1.optString(z[0], "").trim();
          if (a(str2))
          {
            b(paramContext, str2, str1);
            return;
          }
          new StringBuilder(z[8]).append(str2).toString();
          cn.jpush.android.c.r.b();
          ServiceInterface.a(str1, 996, paramContext);
          return;
        }
        if (i == 1) {}
        for (JSONObject localJSONObject2 = a(paramContext, str1, localJSONObject1, z[0]); localJSONObject2 != null; localJSONObject2 = null)
        {
          int j = localJSONObject2.optInt(z[5], -1);
          Object localObject;
          switch (j)
          {
          default: 
            new StringBuilder(z[4]).append(j).toString();
            cn.jpush.android.c.r.d();
            ServiceInterface.a(str1, 996, paramContext);
            return;
          case 0: 
            localObject = new o();
          }
          for (;;)
          {
            boolean bool = ((d)localObject).b(paramContext, localJSONObject2);
            cn.jpush.android.c.r.a();
            ((d)localObject).c = str1;
            ((d)localObject).b = i;
            ((d)localObject).n = j;
            if (!bool) {
              break;
            }
            ((d)localObject).a(paramContext);
            cn.jpush.android.c.r.a();
            return;
            localObject = new h();
            continue;
            localObject = new r();
            continue;
            localObject = new q();
          }
          cn.jpush.android.c.r.d();
          return;
        }
      }
    }
  }
  
  public static boolean a(String paramString)
  {
    boolean bool;
    if (TextUtils.isEmpty(paramString)) {
      bool = false;
    }
    String str;
    do
    {
      return bool;
      str = paramString.trim();
      bool = str.matches(z[25]);
    } while (bool);
    new StringBuilder(z[26]).append(str).toString();
    cn.jpush.android.c.r.d();
    return bool;
  }
  
  public static boolean a(boolean paramBoolean, int paramInt, Context paramContext)
  {
    boolean bool = z[24].equalsIgnoreCase(cn.jpush.android.c.a.e(paramContext));
    return ((paramBoolean) && (paramInt == 0)) || ((paramBoolean) && (paramInt == 1) && (bool));
  }
  
  private static void b(Context paramContext, String paramString1, String paramString2)
  {
    new StringBuilder(z[10]).append(paramString1).toString();
    cn.jpush.android.c.r.a();
    if (paramContext == null) {
      throw new IllegalArgumentException(z[1]);
    }
    new m(paramString1, paramContext, paramString2).start();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.l
 * JD-Core Version:    0.7.1
 */