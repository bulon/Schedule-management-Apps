package cn.jpush.android.a;

import android.content.Context;
import android.text.TextUtils;
import cn.jpush.android.c.a;
import cn.jpush.android.c.n;
import cn.jpush.android.c.r;
import cn.jpush.android.service.ServiceInterface;

final class m
  extends Thread
{
  m(String paramString1, Context paramContext, String paramString2) {}
  
  public final void run()
  {
    String str = null;
    int i = 0;
    do
    {
      j = 0;
      if (i >= 4) {
        break;
      }
      i++;
      str = n.a(this.a, 5, 8000L);
    } while (n.a(str));
    int j = 1;
    if ((j != 0) && (!TextUtils.isEmpty(str)))
    {
      l.a(this.b, str);
      return;
    }
    ServiceInterface.a(this.c, 1021, a.b(this.b, this.a), this.b);
    ServiceInterface.a(this.c, 996, this.b);
    r.b();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.m
 * JD-Core Version:    0.7.1
 */