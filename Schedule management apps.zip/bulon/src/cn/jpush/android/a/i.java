package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.c.a;
import cn.jpush.android.c.m;
import cn.jpush.android.c.n;
import cn.jpush.android.c.r;
import cn.jpush.android.service.ServiceInterface;

final class i
  extends Thread
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = "^\tcfX\027O";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 98;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "\026\b{n\016";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 56;
        break label96;
        i3 = 96;
        break label96;
        i3 = 15;
        break label96;
        i3 = 3;
        break label96;
        m = 0;
      }
    }
  }
  
  i(h paramh1, h paramh2, Context paramContext, int paramInt) {}
  
  public final void run()
  {
    String str1 = this.a.ac.j;
    String str2 = this.a.c;
    if (!l.a(str1))
    {
      ServiceInterface.a(this.a.c, 996, this.b);
      return;
    }
    if (!this.a.ac.i)
    {
      ServiceInterface.a(str2, this.c, this.b);
      h.a(this.d, this.a, this.b);
      return;
    }
    String str3 = null;
    int i = 0;
    String str4;
    if (i < 4)
    {
      str3 = n.a(str1, 5, 5000L);
      if (!n.a(str3)) {
        str4 = str3;
      }
    }
    for (int j = 1;; j = 0)
    {
      if (j == 0)
      {
        ServiceInterface.a(str2, 1014, this.b);
        ServiceInterface.a(str2, 1021, a.b(this.b, str1), this.b);
        r.b();
        return;
        i++;
        break;
      }
      String str5 = str1.substring(0, 1 + str1.lastIndexOf("/"));
      if (!d.a(this.a.ac.k, this.b, str5, str2, this.a.f()))
      {
        r.b();
        ServiceInterface.a(str2, 1014, this.b);
        return;
      }
      if (this.a.f()) {}
      for (String str6 = cn.jpush.android.c.k.b(this.b, str2) + str2 + z[1]; m.a(str6, str4, this.b); str6 = cn.jpush.android.c.k.a(this.b, str2) + str2)
      {
        this.a.ac.n = (z[0] + str6);
        ServiceInterface.a(str2, this.c, this.b);
        h.a(this.d, this.a, this.b);
        return;
      }
      ServiceInterface.a(str2, 1014, this.b);
      return;
      str4 = str3;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.i
 * JD-Core Version:    0.7.1
 */