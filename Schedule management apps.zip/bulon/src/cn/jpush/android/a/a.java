package cn.jpush.android.a;

import android.content.Context;
import org.json.JSONObject;

public final class a
  extends d
{
  public JSONObject a;
  
  public static d a(a parama)
  {
    b localb = new b();
    localb.m = parama.m;
    localb.l = parama.l;
    localb.h = parama.h;
    localb.i = parama.i;
    localb.j = parama.j;
    localb.k = parama.k;
    localb.c = parama.c;
    localb.d = parama.d;
    localb.S = parama.S;
    localb.U = parama.U;
    localb.a(parama.f());
    return localb;
  }
  
  public final void a(Context paramContext) {}
  
  protected final boolean a(Context paramContext, JSONObject paramJSONObject)
  {
    return false;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.a
 * JD-Core Version:    0.7.1
 */