package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.api.k;
import cn.jpush.android.c.a;
import cn.jpush.android.service.ServiceInterface;
import org.json.JSONObject;

public final class r
  extends d
{
  private static final String[] ab;
  public String V;
  public String W;
  public String X;
  public String Y;
  public String Z;
  public int a;
  
  static
  {
    Object localObject1 = new String[6];
    int i = 0;
    String str1 = "s\016V9zQ\016\035!|B\005Rwa_\020Xw8\006";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 21;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "P?H%y";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "P?T9sI";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "P?P3 ";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "P?I.eC";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "P?X\"gJ";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        ab = (String[])localObject2;
        return;
        i3 = 38;
        continue;
        i3 = 96;
        continue;
        i3 = 61;
        continue;
        i3 = 87;
      }
    }
  }
  
  public r()
  {
    this.n = 2;
  }
  
  public final void a(Context paramContext)
  {
    cn.jpush.android.c.r.a();
    ServiceInterface.a(this.c, 995, paramContext);
    if (this.a == 0)
    {
      if (a.b(paramContext)) {
        ServiceInterface.a(paramContext, this);
      }
      return;
    }
    if (this.a == 1)
    {
      k.a(paramContext, this);
      return;
    }
    new StringBuilder(ab[0]).append(this.a).toString();
    cn.jpush.android.c.r.b();
  }
  
  public final boolean a(Context paramContext, JSONObject paramJSONObject)
  {
    cn.jpush.android.c.r.a();
    this.a = paramJSONObject.optInt(ab[4], 0);
    this.V = paramJSONObject.optString(ab[1], "");
    this.W = paramJSONObject.optString(ab[5], "");
    this.Y = paramJSONObject.optString(ab[3], "");
    this.X = paramJSONObject.optString(ab[2], "");
    return true;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.r
 * JD-Core Version:    0.7.1
 */