package cn.jpush.android.a;

import cn.jpush.android.c.ac;

public final class e
{
  private static final String[] z;
  public String a;
  public String b;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = "G>E~~Nm\037\001";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 23;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "\006m\002NaO?PHsO\022ORpu$F\001*\n";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 42;
        break label96;
        i3 = 77;
        break label96;
        i3 = 34;
        break label96;
        i3 = 33;
        break label96;
        m = 0;
      }
    }
  }
  
  public e(d paramd1, d paramd2)
  {
    this.a = paramd2.c;
    this.b = paramd2.d;
  }
  
  public final boolean equals(Object paramObject)
  {
    if (!(paramObject instanceof e)) {}
    e locale;
    do
    {
      do
      {
        return false;
        locale = (e)paramObject;
      } while ((ac.a(this.a)) || (ac.a(locale.a)) || (!ac.a(this.a, locale.a)));
      if ((ac.a(this.b)) && (ac.a(locale.b))) {
        return true;
      }
    } while ((ac.a(this.b)) || (ac.a(locale.b)) || (!ac.a(this.b, locale.b)));
    return true;
  }
  
  public final String toString()
  {
    return z[0] + this.a + z[1] + this.b;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.e
 * JD-Core Version:    0.7.1
 */