package cn.jpush.android.a;

import android.content.Context;
import android.text.TextUtils;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.k;
import cn.jpush.android.c.m;
import cn.jpush.android.c.n;
import cn.jpush.android.service.ServiceInterface;
import java.io.IOException;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public abstract class d
  implements Serializable
{
  private static final String[] V;
  public String A;
  public List<d> B;
  public int C = -1;
  public int D;
  public int E;
  public String F;
  public String G;
  public int H;
  public int I;
  public int J;
  public boolean K = false;
  public boolean L = false;
  public boolean M = false;
  public boolean N = false;
  public int O = -1;
  public String P;
  public ArrayList<String> Q = null;
  public String R = "";
  public String S;
  public String T;
  public String U;
  private boolean a = false;
  public int b;
  public String c;
  public String d;
  public boolean e;
  public int f;
  public boolean g;
  public String h;
  public String i;
  public String j;
  public String k;
  public String l;
  public String m;
  public int n;
  public int o;
  public boolean p;
  public String q;
  public boolean r = false;
  public String s;
  public boolean t = false;
  public List<String> u = null;
  public boolean v;
  public int w;
  public String x;
  public int y;
  public String z;
  
  static
  {
    Object localObject1 = new String[30];
    int i1 = 0;
    String str1 = "jB;HNe\033#N@oi;LMBL.FDYD<NTyB*R\001&\001:SM[S*GHs\033";
    int i2 = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int i3 = localObject3.length;
    int i4 = 0;
    label36:
    Object localObject4;
    int i5;
    int i6;
    Object localObject5;
    label52:
    int i7;
    int i8;
    if (i3 <= 1)
    {
      localObject4 = localObject3;
      i5 = i4;
      i6 = i3;
      localObject5 = localObject3;
      i7 = localObject5[i4];
      switch (i5 % 5)
      {
      default: 
        i8 = 33;
      }
    }
    for (;;)
    {
      localObject5[i4] = ((char)(i8 ^ i7));
      i4 = i5 + 1;
      if (i6 == 0)
      {
        localObject5 = localObject4;
        i5 = i4;
        i4 = i6;
        break label52;
      }
      i3 = i6;
      localObject3 = localObject4;
      if (i3 > i4) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (i2)
      {
      default: 
        localObject1[i1] = str2;
        i1 = 1;
        str1 = "XT,BDnEoUN+M @E+H\"@Fn\001b\001";
        localObject1 = localObject2;
        i2 = 0;
        break;
      case 0: 
        localObject1[i1] = str2;
        i1 = 2;
        str1 = "cU;Q\033$\016";
        i2 = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i1] = str2;
        i1 = 3;
        str1 = "oN8OMd@+\001GjH#DE＇H\"@Fnt=M\033+";
        i2 = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i1] = str2;
        i1 = 4;
        str1 = "bB O~~S#";
        i2 = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i1] = str2;
        i1 = 5;
        str1 = "-T&E\034";
        i2 = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i1] = str2;
        i1 = 6;
        str1 = "}H*V~bL(~TyM";
        i2 = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i1] = str2;
        i1 = 7;
        str1 = "yH!F~f";
        i2 = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i1] = str2;
        i1 = 8;
        str1 = "f@=FHe~;NQ";
        i2 = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i1] = str2;
        i1 = 9;
        str1 = "oD<JUdQ\020RIdV\020UX{D";
        i2 = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i1] = str2;
        i1 = 10;
        str1 = "e~;HUgD";
        i2 = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i1] = str2;
        i1 = 11;
        str1 = "fR(~HfF\020TSg";
        i2 = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i1] = str2;
        i1 = 12;
        str1 = "jM#NVTB.OBnM";
        i2 = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i1] = str2;
        i1 = 13;
        str1 = "}H*V~cD&FI";
        i2 = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i1] = str2;
        i1 = 14;
        str1 = "j~-SNxV*S";
        i2 = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i1] = str2;
        i1 = 15;
        str1 = "bB O";
        i2 = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i1] = str2;
        i1 = 16;
        str1 = "e~*YUy@<";
        i2 = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i1] = str2;
        i1 = 17;
        str1 = "-\007";
        i2 = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i1] = str2;
        i1 = 18;
        str1 = "e~,NOD!U";
        i2 = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i1] = str2;
        i1 = 19;
        str1 = "f@=FHe~#DG";
        i2 = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i1] = str2;
        i1 = 20;
        str1 = "oD<JUdQ\020RIdV\020BNeU*OU";
        i2 = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i1] = str2;
        i1 = 21;
        str1 = "}H*V~|H+UI";
        i2 = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i1] = str2;
        i1 = 22;
        str1 = "jE\020BNeU*OU";
        i2 = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i1] = str2;
        i1 = 23;
        str1 = "jQ?~UrQ*";
        i2 = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i1] = str2;
        i1 = 24;
        str1 = "e~&L@lD\020TSg";
        i2 = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i1] = str2;
        i1 = 25;
        str1 = "xX<~WbD8";
        i2 = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i1] = str2;
        i1 = 26;
        str1 = "e~)M@l";
        i2 = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i1] = str2;
        i1 = 27;
        str1 = "mT#M~xB=DDe";
        i2 = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i1] = str2;
        i1 = 28;
        str1 = "bL.FDTT=M~gH<U";
        i2 = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i1] = str2;
        i1 = 29;
        str1 = "jB;HNe\033#N@oh\"FsnRo\f\001~S#\033";
        i2 = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i1] = str2;
        V = (String[])localObject2;
        return;
        i8 = 11;
        continue;
        i8 = 33;
        continue;
        i8 = 79;
        continue;
        i8 = 33;
      }
    }
  }
  
  public static d a(Context paramContext, d paramd)
  {
    String str1;
    int i1;
    if ((paramd.u != null) && (paramd.u.size() > 0))
    {
      paramd.Q = new ArrayList();
      Iterator localIterator = paramd.u.iterator();
      for (;;)
      {
        if (localIterator.hasNext())
        {
          str1 = (String)localIterator.next();
          if (!ac.a(str1))
          {
            byte[] arrayOfByte = n.a(str1, 5, 5000L, 4);
            if (arrayOfByte != null) {
              try
              {
                String str2 = str1.substring(1 + str1.lastIndexOf("/"));
                String str3 = k.a(paramContext, paramd.c) + str2;
                if (m.a(str3, arrayOfByte, paramContext))
                {
                  paramd.Q.add(str3);
                  new StringBuilder(V[1]).append(str3).toString();
                  cn.jpush.android.c.r.a();
                }
              }
              catch (IOException localIOException)
              {
                cn.jpush.android.c.r.g();
                i1 = 0;
              }
            }
          }
        }
      }
    }
    while (i1 != 0)
    {
      cn.jpush.android.c.r.c();
      return paramd;
      cn.jpush.android.c.r.e();
      i1 = 0;
      continue;
      new StringBuilder(V[3]).append(str1).toString();
      cn.jpush.android.c.r.d();
      ServiceInterface.a(paramd.c, 1020, cn.jpush.android.c.a.b(paramContext, str1), paramContext);
      i1 = 0;
      continue;
      cn.jpush.android.c.r.e();
      i1 = 0;
      continue;
      i1 = 1;
      continue;
      cn.jpush.android.c.r.e();
      i1 = 0;
    }
    cn.jpush.android.c.r.d();
    ServiceInterface.a(paramd.c, 1014, paramContext);
    return null;
  }
  
  static String a(String paramString1, String paramString2, String paramString3, Context paramContext)
  {
    new StringBuilder(V[29]).append(paramString1).toString();
    cn.jpush.android.c.r.a();
    if ((l.a(paramString1)) && (paramContext != null) && (!TextUtils.isEmpty(paramString2)) && (!TextUtils.isEmpty(paramString3)))
    {
      byte[] arrayOfByte = n.a(paramString1, 5, 5000L, 4);
      if (arrayOfByte != null) {
        try
        {
          String str = k.a(paramContext, paramString2) + paramString3;
          m.a(str, arrayOfByte, paramContext);
          new StringBuilder(V[1]).append(str).toString();
          cn.jpush.android.c.r.a();
          return str;
        }
        catch (IOException localIOException)
        {
          cn.jpush.android.c.r.i();
          return "";
        }
      }
      ServiceInterface.a(paramString2, 1020, cn.jpush.android.c.a.b(paramContext, paramString1), paramContext);
    }
    return "";
  }
  
  static boolean a(ArrayList<String> paramArrayList, Context paramContext, String paramString1, String paramString2, boolean paramBoolean)
  {
    boolean bool1 = true;
    new StringBuilder(V[0]).append(paramString1).toString();
    cn.jpush.android.c.r.a();
    boolean bool2;
    String str1;
    if ((l.a(paramString1)) && (paramContext != null) && (paramArrayList.size() > 0) && (!TextUtils.isEmpty(paramString2)))
    {
      Iterator localIterator = paramArrayList.iterator();
      bool2 = bool1;
      if (localIterator.hasNext())
      {
        str1 = (String)localIterator.next();
        if ((str1 == null) || (str1.startsWith(V[2]))) {
          break label295;
        }
      }
    }
    label295:
    for (String str2 = paramString1 + str1;; str2 = str1)
    {
      byte[] arrayOfByte = n.a(str2, 5, 5000L, 4);
      if (arrayOfByte != null) {
        for (;;)
        {
          try
          {
            if (str1.startsWith(V[2])) {
              str1 = m.c(str1);
            }
            if (paramBoolean) {
              break label236;
            }
            localObject = k.a(paramContext, paramString2) + str1;
            m.a((String)localObject, arrayOfByte, paramContext);
            new StringBuilder(V[1]).append((String)localObject).toString();
            cn.jpush.android.c.r.a();
          }
          catch (IOException localIOException)
          {
            cn.jpush.android.c.r.g();
            bool2 = false;
          }
          break;
          label236:
          String str3 = k.b(paramContext, paramString2) + str1;
          Object localObject = str3;
        }
      }
      ServiceInterface.a(paramString2, 1020, cn.jpush.android.c.a.b(paramContext, str2), paramContext);
      bool2 = false;
      break;
      bool1 = bool2;
      return bool1;
    }
  }
  
  public abstract void a(Context paramContext);
  
  public final void a(String paramString)
  {
    this.U = paramString;
  }
  
  public final void a(boolean paramBoolean)
  {
    this.a = paramBoolean;
  }
  
  public final boolean a()
  {
    return (this.n == 3) || (this.n == 1);
  }
  
  protected abstract boolean a(Context paramContext, JSONObject paramJSONObject);
  
  public final boolean b()
  {
    return this.n == 2;
  }
  
  public final boolean b(Context paramContext, JSONObject paramJSONObject)
  {
    cn.jpush.android.c.r.a();
    this.o = paramJSONObject.optInt(V[7], 3);
    boolean bool1;
    if (paramJSONObject.optInt(V[27], 0) > 0)
    {
      bool1 = true;
      this.p = bool1;
      if (paramJSONObject.optInt(V[14], 0) <= 0) {
        break label620;
      }
    }
    label550:
    label620:
    for (boolean bool2 = true;; bool2 = false)
    {
      this.N = bool2;
      this.y = paramJSONObject.optInt(V[26], 0);
      this.w = paramJSONObject.optInt(V[15], 1);
      this.x = paramJSONObject.optString(V[4], "");
      this.z = paramJSONObject.optString(V[10], "");
      this.A = paramJSONObject.optString(V[18], "");
      this.q = paramJSONObject.optString(V[24]);
      this.R = paramJSONObject.optString(V[11], "");
      this.k = paramJSONObject.optString(V[16], "");
      JSONObject localJSONObject1 = paramJSONObject.optJSONObject(V[20]);
      if (localJSONObject1 != null)
      {
        cn.jpush.android.c.r.c();
        this.C = localJSONObject1.optInt(V[9], -1);
        this.D = localJSONObject1.optInt(V[21], -1);
        this.E = localJSONObject1.optInt(V[13], -1);
        this.F = localJSONObject1.optString(V[6]);
        this.H = localJSONObject1.optInt(V[8]);
        this.I = localJSONObject1.optInt(V[19], Integer.MIN_VALUE);
        this.J = localJSONObject1.optInt(V[23], 0);
      }
      if (!ac.a(this.R)) {
        this.A = this.A.replaceAll(V[17], V[5] + cn.jpush.android.c.a.s(paramContext));
      }
      JSONObject localJSONObject2 = paramJSONObject.optJSONObject(V[25]);
      if (localJSONObject2 != null) {
        cn.jpush.android.c.r.c();
      }
      JSONObject localJSONObject3;
      do
      {
        try
        {
          this.s = localJSONObject2.toString();
          JSONArray localJSONArray = localJSONObject2.getJSONArray(V[28]);
          int i1 = localJSONArray.length();
          this.u = new LinkedList();
          for (int i2 = 0; i2 < i1; i2++) {
            this.u.add(localJSONArray.getString(i2));
          }
          if (localJSONObject2.optInt(V[12], 1) > 0) {}
          for (boolean bool3 = true;; bool3 = false)
          {
            this.v = bool3;
            if (!ac.a(this.z)) {
              break label550;
            }
            if (this.g) {
              break;
            }
            cn.jpush.android.c.r.b();
            ServiceInterface.a(this.c, 996, paramContext);
            return false;
          }
          cn.jpush.android.c.r.b();
        }
        catch (Exception localException)
        {
          cn.jpush.android.c.r.g();
          ServiceInterface.a(this.c, 996, paramContext);
          return false;
        }
        this.z = cn.jpush.android.a.c;
        localJSONObject3 = l.a(paramContext, this.c, paramJSONObject, V[22]);
        if (localJSONObject3 != null) {
          break;
        }
      } while ((!this.g) || (!this.e));
      return true;
      if ((this.g) && (this.e)) {
        this.a = true;
      }
      return a(paramContext, localJSONObject3);
      bool1 = false;
      break;
    }
  }
  
  public final boolean c()
  {
    return this.n == 3;
  }
  
  public final String d()
  {
    if (a()) {
      return ((h)this).ab;
    }
    if (b()) {
      return ((r)this).V;
    }
    if (this.a) {
      return this.U;
    }
    return "";
  }
  
  public final String e()
  {
    if (a()) {
      return ((h)this).ag;
    }
    if (b()) {
      return ((r)this).Z;
    }
    return "";
  }
  
  public final boolean f()
  {
    return this.a;
  }
  
  public final String g()
  {
    String str2;
    if (a())
    {
      String str3 = ((h)this).ad;
      str2 = null;
      if (str3 != null)
      {
        boolean bool2 = "".equals(str3);
        str2 = null;
        if (!bool2) {
          str2 = str3.trim();
        }
      }
    }
    String str1;
    boolean bool1;
    do
    {
      do
      {
        return str2;
        if (!b()) {
          break;
        }
        str1 = ((r)this).Y;
        str2 = null;
      } while (str1 == null);
      bool1 = "".equals(str1);
      str2 = null;
    } while (bool1);
    return str1.trim();
    return "";
  }
  
  public final e h()
  {
    return new e(this, this);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.d
 * JD-Core Version:    0.7.1
 */