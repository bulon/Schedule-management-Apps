package cn.jpush.android.a;

import android.content.Context;
import org.json.JSONObject;

final class b
  extends d
{
  public final void a(Context paramContext) {}
  
  protected final boolean a(Context paramContext, JSONObject paramJSONObject)
  {
    return false;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.b
 * JD-Core Version:    0.7.1
 */