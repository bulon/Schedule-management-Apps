package cn.jpush.android.a;

import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;

final class g
  extends Handler
{
  g(f paramf) {}
  
  public final void handleMessage(Message paramMessage)
  {
    if (paramMessage.what == 0) {
      if ((f.a(this.a) != null) && (f.b(this.a) != null)) {
        f.a(this.a).setImageBitmap(f.b(this.a));
      }
    }
    while ((paramMessage.what != 1) || (f.c(this.a) == null) || (f.d(this.a) == null)) {
      return;
    }
    f.c(this.a).setImageBitmap(f.d(this.a));
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.g
 * JD-Core Version:    0.7.1
 */