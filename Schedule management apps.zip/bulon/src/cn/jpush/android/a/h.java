package cn.jpush.android.a;

import android.content.Context;
import cn.jpush.android.c.a;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.service.ServiceInterface;
import org.json.JSONObject;

public class h
  extends d
{
  private static final String[] bb;
  public String V;
  public boolean W;
  public boolean X;
  public int Y;
  public boolean Z;
  public String a;
  public int aa;
  public String ab;
  public k ac = new k(this);
  public String ad;
  public boolean ae;
  public boolean af = true;
  public String ag;
  public boolean ah;
  
  static
  {
    Object localObject1 = new String[28];
    int i = 0;
    String str1 = "B\023q\020kr\036`\r-]a\006py\022c\006;g\0264\033sx\n4\005ts\0304E;";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 27;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "v\"q\035i{";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "v\"}\005zp\030K\035i{";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "v\"f\rh";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "v\r7h\022c";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "v\r7ne\021";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "v\"}\006}x";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "v\"g\013te\030";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "v\"}\013ty\"a\032w";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "v\"b\ri";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "v\"`\001o{\030";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "v\"v\032td\nq\032";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "v\r7zb\t{7ry\016`\tw{";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "v\r7u";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "v\b`\007Dy";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "v\"`\021kr";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "H\nq\nKv\032q8zc\025";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "v\b`\007De\036";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "v\"g\001ar";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "H\024y\t|r-u\034s";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "v\r7~t\022z";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "v\r7n";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "v\"q\032~d";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "v\b`\007De";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "v\r7h\022c7}~\023}\033sr\031K\006tc\024";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "v\b`\007Dz";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "v\r7vsH";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        bb = (String[])localObject2;
        return;
        i3 = 23;
        continue;
        i3 = 125;
        continue;
        i3 = 20;
        continue;
        i3 = 104;
      }
    }
  }
  
  public h()
  {
    this.n = 1;
  }
  
  public void a(Context paramContext)
  {
    r.a();
    boolean bool = a.f(paramContext, this.a);
    int i = 995;
    if ((!this.W) && (bool))
    {
      r.b();
      ServiceInterface.a(this.c, 997, paramContext);
      return;
    }
    if ((this.W) && (bool))
    {
      r.b();
      i = 998;
    }
    if (this.aa == 1)
    {
      new i(this, this, paramContext, i).start();
      return;
    }
    if (this.aa == 0)
    {
      new j(this, paramContext, i, this).start();
      return;
    }
    new StringBuilder(bb[0]).append(this.aa).toString();
    r.d();
  }
  
  public boolean a(Context paramContext, JSONObject paramJSONObject)
  {
    r.a();
    this.a = paramJSONObject.optString(bb[13], "");
    boolean bool1;
    boolean bool2;
    label57:
    boolean bool3;
    label95:
    boolean bool4;
    if (paramJSONObject.optInt(bb[22], 0) > 0)
    {
      bool1 = true;
      this.W = bool1;
      if (paramJSONObject.optInt(bb[26], 0) <= 0) {
        break label249;
      }
      bool2 = true;
      this.X = bool2;
      this.Y = paramJSONObject.optInt(bb[14], 0);
      if (paramJSONObject.optInt(bb[24], 0) <= 0) {
        break label255;
      }
      bool3 = true;
      this.Z = bool3;
      this.aa = paramJSONObject.optInt(bb[4], 1);
      this.ab = paramJSONObject.optString(bb[5], "").trim();
      this.ad = paramJSONObject.optString(bb[27], "");
      this.V = paramJSONObject.optString(bb[17], "");
      if (paramJSONObject.optInt(bb[25], 0) <= 0) {
        break label261;
      }
      bool4 = true;
      label182:
      this.ae = bool4;
      if (paramJSONObject.optInt(bb[12], 1) != 1) {
        break label267;
      }
    }
    JSONObject localJSONObject;
    label261:
    label267:
    for (boolean bool5 = true;; bool5 = false)
    {
      this.af = bool5;
      if (this.n != 1) {
        break label645;
      }
      localJSONObject = l.a(paramContext, this.c, paramJSONObject, bb[21]);
      if (localJSONObject != null) {
        break label273;
      }
      return false;
      bool1 = false;
      break;
      label249:
      bool2 = false;
      break label57;
      label255:
      bool3 = false;
      break label95;
      bool4 = false;
      break label182;
    }
    label273:
    k localk = this.ac;
    r.a();
    localk.a = localJSONObject.optString(bb[10], "");
    localk.b = localJSONObject.optString(bb[8], "").trim();
    localk.c = localJSONObject.optString(bb[9], "");
    localk.d = localJSONObject.optString(bb[15], "");
    boolean bool6;
    h localh;
    if (localJSONObject.optInt(bb[7], 0) == 0)
    {
      bool6 = true;
      localk.e = bool6;
      localk.f = localJSONObject.optString(bb[18], "");
      localk.g = localJSONObject.optString(bb[6], "");
      localk.h = localJSONObject.optString(bb[2], "").trim();
      localk.j = localJSONObject.optString(bb[1], "").trim();
      localh = localk.o;
      if (localJSONObject.optInt(bb[11], 0) != 1) {
        break label653;
      }
    }
    label645:
    label653:
    for (boolean bool7 = true;; bool7 = false)
    {
      localh.N = bool7;
      int i = localJSONObject.optInt(bb[3], 0);
      boolean bool8 = false;
      if (i == 0) {
        bool8 = true;
      }
      localk.i = bool8;
      if (localk.i) {
        localk.k = cn.jpush.android.c.h.a(localJSONObject.optJSONArray(bb[23]));
      }
      if (ac.a(localk.m)) {
        localk.m = localJSONObject.optString(bb[20], "").trim();
      }
      if (ac.a(localk.l)) {
        localk.l = localJSONObject.optString(bb[19], "").trim();
      }
      if (ac.a(localk.l)) {
        localk.l = localJSONObject.optString(bb[16], "").trim();
      }
      return true;
      bool6 = false;
      break;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.h
 * JD-Core Version:    0.7.1
 */