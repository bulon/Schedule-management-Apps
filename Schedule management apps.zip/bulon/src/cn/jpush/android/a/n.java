package cn.jpush.android.a;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import cn.jpush.android.c.r;

public final class n
  extends SQLiteOpenHelper
{
  private static n a;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[14];
    int i = 0;
    String str1 = "l\022VNnzJ";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 7;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "l\022VNs\025Jt";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "j\024VNs\025Jt";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "l\022VNnz";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "j\024VNc\003G";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "l\022VNc\003G";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "l\022VNwl\022@x";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "l\022V?c|";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "]%cPS[WrPER2\006edn(Rper\022\0069u{\007yxc>\036Heby\022T1wl\036KpugWMt~>\026Sehw\031Ecbs\022He+j\024VNc\003G1S[/r8";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "]%cPS[WrPER2\006cbn(Rper\022\0069u{\007yxc>\036Heby\022T1wl\036KpugWMt~>\026Sehw\031Ecbs\022He+l\022VNwl\022@x>#cIS2\005CaXz\026Rp'J2~E.";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "z\005Ia'j\026D}b>>`1BF>uET>\003EaXj\026D}b";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "z\005Ia'j\026D}b>>`1BF>uET>\005CaXj\026D}b";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "J\037C1hr\023ptum\036I'w\004\0341";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = ">\003Nt'p\022QGbl\004O~i>\036U1=>";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        return;
        i3 = 30;
        continue;
        i3 = 119;
        continue;
        i3 = 38;
        continue;
        i3 = 17;
      }
    }
  }
  
  private n(Context paramContext)
  {
    super(paramContext, z[7], null, 3);
  }
  
  public static Cursor a(Context paramContext)
  {
    try
    {
      SQLiteDatabase localSQLiteDatabase = c(paramContext).getWritableDatabase();
      String str = z[1];
      String[] arrayOfString = new String[3];
      arrayOfString[0] = z[3];
      arrayOfString[1] = z[5];
      arrayOfString[2] = z[6];
      Cursor localCursor = localSQLiteDatabase.query(str, arrayOfString, null, null, null, null, z[3]);
      return localCursor;
    }
    catch (Exception localException)
    {
      r.g();
    }
    return null;
  }
  
  public static boolean a(Context paramContext, int paramInt)
  {
    try
    {
      int i = c(paramContext).getWritableDatabase().delete(z[1], z[0] + paramInt, null);
      return i > 0;
    }
    catch (Exception localException)
    {
      r.g();
    }
    return false;
  }
  
  public static boolean a(Context paramContext, String paramString)
  {
    try
    {
      SQLiteDatabase localSQLiteDatabase = c(paramContext).getWritableDatabase();
      ContentValues localContentValues = new ContentValues();
      localContentValues.put(z[4], paramString);
      long l = localSQLiteDatabase.insert(z[2], z[3], localContentValues);
      boolean bool1 = l < 0L;
      boolean bool2 = false;
      if (bool1) {
        bool2 = true;
      }
      return bool2;
    }
    catch (Exception localException)
    {
      r.g();
    }
    return false;
  }
  
  public static boolean a(Context paramContext, String paramString1, String paramString2)
  {
    try
    {
      SQLiteDatabase localSQLiteDatabase = c(paramContext).getWritableDatabase();
      ContentValues localContentValues = new ContentValues();
      localContentValues.put(z[6], paramString1);
      localContentValues.put(z[5], paramString2);
      long l = localSQLiteDatabase.insert(z[1], z[3], localContentValues);
      return l > 0L;
    }
    catch (Exception localException)
    {
      r.g();
    }
    return false;
  }
  
  public static Cursor b(Context paramContext)
  {
    try
    {
      SQLiteDatabase localSQLiteDatabase = c(paramContext).getWritableDatabase();
      String str = z[2];
      String[] arrayOfString = new String[2];
      arrayOfString[0] = z[3];
      arrayOfString[1] = z[4];
      Cursor localCursor = localSQLiteDatabase.query(str, arrayOfString, null, null, null, null, z[3]);
      return localCursor;
    }
    catch (Exception localException)
    {
      r.g();
    }
    return null;
  }
  
  public static boolean b(Context paramContext, int paramInt)
  {
    try
    {
      int i = c(paramContext).getWritableDatabase().delete(z[2], z[0] + paramInt, null);
      boolean bool = false;
      if (i > 0) {
        bool = true;
      }
      return bool;
    }
    catch (Exception localException)
    {
      r.g();
    }
    return false;
  }
  
  private static n c(Context paramContext)
  {
    if (a == null) {
      a = new n(paramContext);
    }
    return a;
  }
  
  public final void onCreate(SQLiteDatabase paramSQLiteDatabase)
  {
    r.c();
    paramSQLiteDatabase.execSQL(z[9]);
    paramSQLiteDatabase.execSQL(z[8]);
  }
  
  public final void onUpgrade(SQLiteDatabase paramSQLiteDatabase, int paramInt1, int paramInt2)
  {
    new StringBuilder(z[12]).append(paramInt1).append(z[13]).append(paramInt2).toString();
    r.b();
    paramSQLiteDatabase.execSQL(z[11]);
    paramSQLiteDatabase.execSQL(z[10]);
    onCreate(paramSQLiteDatabase);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.a.n
 * JD-Core Version:    0.7.1
 */