package cn.jpush.android.api;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import cn.jpush.android.c.aa;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.i;
import cn.jpush.android.c.r;
import cn.jpush.android.c.w;
import java.lang.ref.WeakReference;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import org.json.JSONException;
import org.json.JSONObject;

public class e
{
  public static boolean a;
  public static boolean b;
  private static final String c;
  private static e e;
  private static final String[] z;
  private ExecutorService d = Executors.newSingleThreadExecutor();
  private String f = null;
  private String g = null;
  private ArrayList<a> h = new ArrayList();
  private long i = 30L;
  private long j = 0L;
  private long k = 0L;
  private boolean l = false;
  private boolean m = true;
  private boolean n = true;
  private boolean o = false;
  private boolean p = true;
  private WeakReference<JSONObject> q = null;
  private JSONObject r = null;
  private Object s = new Object();
  
  static
  {
    Object localObject1 = new String[22];
    int i1 = 0;
    String str1 = "N<L\006";
    int i2 = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int i3 = localObject3.length;
    int i4 = 0;
    label36:
    Object localObject4;
    int i5;
    int i6;
    Object localObject5;
    label52:
    int i7;
    int i8;
    if (i3 <= 1)
    {
      localObject4 = localObject3;
      i5 = i4;
      i6 = i3;
      localObject5 = localObject3;
      i7 = localObject5[i4];
      switch (i5 % 5)
      {
      default: 
        i8 = 97;
      }
    }
    for (;;)
    {
      localObject5[i4] = ((char)(i8 ^ i7));
      i4 = i5 + 1;
      if (i6 == 0)
      {
        localObject5 = localObject4;
        i5 = i4;
        i4 = i6;
        break label52;
      }
      i3 = i6;
      localObject3 = localObject4;
      if (i3 > i4) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (i2)
      {
      default: 
        localObject1[i1] = str2;
        i1 = 1;
        str1 = "^4U\006";
        localObject1 = localObject2;
        i2 = 0;
        break;
      case 0: 
        localObject1[i1] = str2;
        i1 = 2;
        str1 = "";
        i2 = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i1] = str2;
        i1 = 3;
        str1 = "U;q\002\024I0";
        i2 = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i1] = str2;
        i1 = 4;
        str1 = "v4R\027Al<D\024I{6U\n\027S!XJAW<R\020AU;s\006\022O8D";
        i2 = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i1] = str2;
        i1 = 5;
        str1 = "^ S\002\025S:O";
        i2 = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i1] = str2;
        i1 = 6;
        str1 = "Y S<\022_0R\n\016T\nD\r\005";
        i2 = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i1] = str2;
        i1 = 7;
        str1 = "S!H\016\004";
        i2 = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i1] = str2;
        i1 = 8;
        str1 = "I0R\020\bU;~\n\005";
        i2 = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i1] = str2;
        i1 = 9;
        str1 = "";
        i2 = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i1] = str2;
        i1 = 10;
        str1 = "";
        i2 = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i1] = str2;
        i1 = 11;
        str1 = "O!GNY";
        i2 = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i1] = str2;
        i1 = 12;
        str1 = "[6U\n\027S!H\006\022";
        i2 = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i1] = str2;
        i1 = 13;
        str1 = "V4R\027>J4T\020\004";
        i2 = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i1] = str2;
        i1 = 14;
        str1 = "y:O\027\004B!\001\020\tU M\007AX0\001\002\017\032\024B\027\bL<U\032";
        i2 = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i1] = str2;
        i1 = 15;
        str1 = "p\005T\020\ti\024\017\f\017h0R\026\f_}b\f\017N0Y\027H\0328T\020\025\0327DC\bT#N\b\004^uH\rA{6U\n\027S!XM\016T\007D\020\024W0\tJ";
        i2 = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i1] = str2;
        i1 = 16;
        str1 = "^:\001\r\016NuQ\002\022Iu@\023\021V<B\002\025S:O \016T!D\033\025\032!NC\025R<RC\f_!I\f\005";
        i2 = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i1] = str2;
        i1 = 17;
        str1 = "N,Q\006";
        i2 = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i1] = str2;
        i1 = 18;
        str1 = "[6U\n\027_\nM\002\024T6I";
        i2 = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i1] = str2;
        i1 = 19;
        str1 = "";
        i2 = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i1] = str2;
        i1 = 20;
        str1 = "U;s\006\022O8D";
        i2 = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i1] = str2;
        i1 = 21;
        str1 = "[6U\n\027_\nU\006\023W<O\002\025_";
        i2 = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i1] = str2;
        z = (String[])localObject2;
        c = e.class.getSimpleName();
        e = null;
        a = false;
        b = false;
        return;
        i8 = 58;
        continue;
        i8 = 85;
        continue;
        i8 = 33;
        continue;
        i8 = 99;
      }
    }
  }
  
  public static e a()
  {
    if (e == null) {}
    try
    {
      e = new e();
      return e;
    }
    finally
    {
      localObject = finally;
      throw ((Throwable)localObject);
    }
  }
  
  private JSONObject a(Context paramContext, long paramLong)
  {
    aa.a().b(paramContext, z[10], this.j);
    StringBuilder localStringBuilder = new StringBuilder();
    String str1 = cn.jpush.android.c.a.v(paramContext);
    if (!ac.a(str1)) {
      localStringBuilder.append(str1);
    }
    String str2 = cn.jpush.android.c.a.l(paramContext);
    if (!ac.a(str2)) {
      localStringBuilder.append(str2);
    }
    localStringBuilder.append(paramLong);
    this.g = cn.jpush.android.c.a.a(localStringBuilder.toString());
    aa.a().b(paramContext, z[8], this.g);
    JSONObject localJSONObject = new JSONObject();
    try
    {
      a(localJSONObject);
      localJSONObject.put(z[7], paramLong / 1000L);
      localJSONObject.put(z[8], this.g);
      localJSONObject.put(z[17], z[18]);
      return localJSONObject;
    }
    catch (JSONException localJSONException) {}
    return null;
  }
  
  private static void a(JSONObject paramJSONObject)
  {
    String str1 = i.a();
    String str2 = str1.split("_")[0];
    String str3 = str1.split("_")[1];
    paramJSONObject.put(z[1], str2);
    paramJSONObject.put(z[0], str3);
  }
  
  private boolean a(Context paramContext, String paramString)
  {
    if (!this.p)
    {
      r.c();
      return false;
    }
    if (paramContext == null)
    {
      r.c();
      return false;
    }
    if ((paramContext instanceof Application))
    {
      r.d(c, z[16]);
      throw new IllegalArgumentException(z[14]);
    }
    if (!a(paramString)) {
      throw new SecurityException(z[15]);
    }
    return true;
  }
  
  private static boolean a(String paramString)
  {
    StackTraceElement[] arrayOfStackTraceElement = new Throwable().getStackTrace();
    int i1 = arrayOfStackTraceElement.length;
    boolean bool = false;
    if (i1 >= 2) {}
    for (int i2 = 0;; i2++) {
      try
      {
        if (i2 < arrayOfStackTraceElement.length)
        {
          StackTraceElement localStackTraceElement = arrayOfStackTraceElement[i2];
          if (localStackTraceElement.getMethodName().equals(paramString))
          {
            Class localClass;
            for (Object localObject = Class.forName(localStackTraceElement.getClassName()); ((Class)localObject).getSuperclass() != null; localObject = localClass)
            {
              if (((Class)localObject).getSuperclass() == Activity.class)
              {
                bool = true;
                break;
              }
              localClass = ((Class)localObject).getSuperclass();
            }
          }
        }
        else
        {
          return bool;
        }
      }
      catch (Exception localException) {}
    }
  }
  
  private JSONObject d(Context paramContext)
  {
    if (this.r == null) {
      this.r = w.b(paramContext, z[2]);
    }
    return this.r;
  }
  
  public final void a(long paramLong)
  {
    this.i = paramLong;
  }
  
  public final void a(Context paramContext)
  {
    if (!a(paramContext, z[20])) {
      return;
    }
    a = true;
    if (this.o)
    {
      r.e(c, z[19]);
      this.o = false;
      return;
    }
    this.o = true;
    this.j = System.currentTimeMillis();
    this.f = paramContext.getClass().getName();
    try
    {
      this.d.execute(new f(this, paramContext));
      return;
    }
    catch (Exception localException) {}
  }
  
  public final void a(boolean paramBoolean)
  {
    this.p = paramBoolean;
  }
  
  public final void b(Context paramContext)
  {
    if (!a(paramContext, z[3])) {
      return;
    }
    b = true;
    if (!this.o)
    {
      r.e(c, z[4]);
      return;
    }
    this.o = false;
    if (this.f.equals(paramContext.getClass().getName()))
    {
      this.k = System.currentTimeMillis();
      long l1 = (this.k - this.j) / 1000L;
      a locala = new a(this.f, l1);
      this.h.add(locala);
      try
      {
        this.d.execute(new g(this, paramContext));
        return;
      }
      catch (Exception localException)
      {
        return;
      }
    }
    r.c();
  }
  
  public final void c(Context paramContext)
  {
    try
    {
      if ((this.f != null) && (this.o))
      {
        this.k = System.currentTimeMillis();
        long l1 = (this.k - this.j) / 1000L;
        a locala = new a(this.f, l1);
        this.h.add(locala);
      }
      return;
    }
    catch (Exception localException1)
    {
      try
      {
        this.d.execute(new h(this, paramContext));
        return;
      }
      catch (Exception localException2) {}
      localException1 = localException1;
      return;
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.e
 * JD-Core Version:    0.7.1
 */