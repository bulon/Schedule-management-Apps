package cn.jpush.android.api;

import android.app.Application;
import java.util.HashMap;

public final class i
{
  public static boolean a;
  private static boolean b = true;
  private static String c;
  private static HashMap<String, Integer> d = new HashMap();
  private static String e = null;
  private static String f = null;
  private static String g = null;
  
  static
  {
    a = false;
    Object localObject1 = "讟圏惩殩丐)D5\017L\001S8盢U\006u$\025O\005BiO咶\007I\021\007O\033BiO皾\033R1\003H@\016呏豥甒皐兔纞诇斃沽］\0136O\033O\b\bN\rU'\007Y\r\t.\bh\rT4\013_@\016a哪\032\"w4\025R!I5\003H\016F\"\003\024\007I\021\007O\033BiO".toCharArray();
    int i = localObject1.length;
    int j = 0;
    if (i <= 1) {}
    label140:
    while (i > j)
    {
      Object localObject2 = localObject1;
      int k = j;
      int m = i;
      Object localObject3 = localObject1;
      int n = localObject3[j];
      int i1;
      switch (k % 5)
      {
      default: 
        i1 = 58;
      }
      for (;;)
      {
        localObject3[j] = ((char)(i1 ^ n));
        j = k + 1;
        if (m != 0) {
          break label140;
        }
        localObject3 = localObject2;
        k = j;
        j = m;
        break;
        i1 = 104;
        continue;
        i1 = 39;
        continue;
        i1 = 65;
        continue;
        i1 = 102;
      }
      i = m;
      localObject1 = localObject2;
    }
    c = new String((char[])localObject1).intern();
  }
  
  public static void a(Application paramApplication)
  {
    j localj = new j();
    paramApplication.unregisterActivityLifecycleCallbacks(localj);
    paramApplication.registerActivityLifecycleCallbacks(localj);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.i
 * JD-Core Version:    0.7.1
 */