package cn.jpush.android.api;

public final class d
{
  public static int a = 6001;
  public static int b = 6002;
  public static int c = 6003;
  public static int d = 6004;
  public static int e = 6005;
  public static int f = 6006;
  public static int g = 6007;
  public static int h = 6008;
  public static int i = 6009;
  public static int j = 6010;
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.d
 * JD-Core Version:    0.7.1
 */