package cn.jpush.android.api;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.text.TextUtils;
import cn.jpush.android.a.d;
import cn.jpush.android.a.o;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.c.z;
import cn.jpush.android.service.PushReceiver;
import cn.jpush.android.service.PushService;
import cn.jpush.android.service.ServiceInterface;
import java.io.File;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.UUID;
import java.util.zip.Adler32;

public final class k
{
  private static Queue<Integer> a;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[40];
    int i = 0;
    String str1 = "W\037g`pa\016$wz$\006kbq$\003ibraJ)#";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 21;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "`\005sb{h\005eg5b\006kba$\032llakJbb|h\017`／|i\013cf@v\006>#";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "*8";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "t\013vbxa\036aq5v\017wWlt\017$lg$\fmfy`$enpwJaqgk\030*";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "VN`qts\013fop";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "n\032qp}[\004kw|b\003gbam\005j\\|g\005j";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "g\004*ieq\031l-tj\016vl|`Dmmaa\004p-FL%S\\SH%EWJR#ATJE)PJZJ";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "f\005`z";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "j\005pjsm\tew|k\004";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "e\tpjzjPgope\004Jlam\fm`tp\003km5)Jiffw\013cf\\`P";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "e\tpjzjPgope\004Jlam\fm`tp\003km5)Jjlam\fm`tp\003km\\`P";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "VNmg";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "VNhblk\037p";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "w\036ewp[\beqJm\007edp[\034mfb";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "i\017wptc\017[jxe\ra\\fp\013pfJf\013v\\ye\023kva";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "g\004*ieq\031l-tj\016vl|`DJLAM,M@TP#KMJG%JWPJ>[W\\P&A";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "g\004*ieq\031l-tj\016vl|`Dmmaa\004p-F]9PFX[,QOYW)VFPJ5GBAA-KQL";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "g\004*ieq\031l-tj\016vl|`DIPR[#@";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "g\004*ieq\031l-tj\016vl|`DEOPV>";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "g\004*ieq\031l-tj\016vl|`Dmmaa\004p-[K>ME\\G+PJZJ5KSPJ/@\\EV%\\Z;";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "j\005pjse\tpjzj5jvx";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "g\004*ieq\031l-tj\016vl|`DA[AV+";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "g\004*ieq\031l-tj\016vl|`DTVFL5MG";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "g\004*ieq\031l-tj\016vl|`Dmmaa\004p-[K>ME\\G+PJZJ5KSPJ/@";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "J\005pjsm\tew|k\004Lfyt\017v";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "g\004*ieq\031l-tj\016vl|`DJLAM,M@TP#KMJ@/RFYK:AQJE8C3";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "e\032t";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "g\004*ieq\031l-tj\016vl|`Dmmaa\004p-F]9PFX[,QOYW)VFPJ5E@AM%J";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "C\005p#[Q&H#{k\036me|g\013pjzjD$D|r\017$ve$\036k#fl\005s-";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "+\003gl{";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "g\004*ieq\031l-tj\016vl|`DLWXH5VFF";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = "g\004*ieq\031l-tj\016vl|`DLWXH5TBAL";
        j = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i] = str2;
        i = 32;
        str1 = "g\004*ieq\031l-tj\016vl|`Dmmaa\004p-[K>ME\\G+PJZJ5VFVA#RFQ";
        j = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i] = str2;
        i = 33;
        str1 = "*\032aqxm\031wjzjDNS@W\"[NPW9EDP";
        j = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i] = str2;
        i = 34;
        str1 = "l\036ps/+E";
        j = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i] = str2;
        i = 35;
        str1 = "b\003hf/+E";
        j = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i] = str2;
        i = 36;
        str1 = "W\017jg5t\037wk5v\017gf|r\017`#wv\005egve\031p#akJ`fca\006kspvJ`fsm\004ag5v\017gf|r\017v";
        j = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i] = str2;
        i = 37;
        str1 = "g\004*ieq\031l-tj\016vl|`DJLAM,M@TP#KMJM.";
        j = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i] = str2;
        i = 38;
        str1 = "e\tpjzjPgope\004EoyJ\005pjsm\tew|k\004$.5i\017wptc\017Mg/";
        j = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i] = str2;
        i = 39;
        str1 = "`\005smyk\013`#fp\013pvf$\003gl{$\fejya\016（jxe\raVghP$";
        j = 38;
        localObject1 = localObject2;
        break;
      case 38: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        a = new LinkedList();
        return;
        i3 = 4;
        continue;
        i3 = 106;
        continue;
        i3 = 4;
        continue;
        i3 = 3;
      }
    }
  }
  
  private static int a(int paramInt)
  {
    int i = 17301586;
    switch (paramInt)
    {
    case 1: 
    default: 
    case -1: 
      do
      {
        return i;
        String str = z[4];
        String[] arrayOfString = new String[1];
        arrayOfString[0] = z[5];
        HashMap localHashMap = a(str, arrayOfString);
        try
        {
          int j = ((Integer)localHashMap.get(z[5])).intValue();
          i = j;
        }
        catch (Exception localException)
        {
          for (;;)
          {
            r.e();
            i = 0;
          }
        }
      } while (i > 0);
      return 17301618;
    case 0: 
      return 17301647;
    case 2: 
      return 17301618;
    }
    return 17301567;
  }
  
  public static int a(d paramd, int paramInt)
  {
    String str = paramd.c;
    if (!ac.a(paramd.d)) {
      str = paramd.d;
    }
    return a(str, paramInt);
  }
  
  private static int a(String paramString, int paramInt)
  {
    int j;
    if (TextUtils.isEmpty(paramString))
    {
      r.b();
      j = 0;
    }
    do
    {
      return j;
      try
      {
        int k = Integer.valueOf(paramString).intValue();
        return k;
      }
      catch (Exception localException)
      {
        r.e();
        Adler32 localAdler32 = new Adler32();
        localAdler32.update(paramString.getBytes());
        int i = (int)localAdler32.getValue();
        if (i < 0) {
          i = Math.abs(i);
        }
        j = i + 13889152 * paramInt;
      }
    } while (j >= 0);
    return Math.abs(j);
  }
  
  /* Error */
  public static Notification a(Context paramContext, int paramInt, Intent paramIntent, d paramd, boolean paramBoolean1, boolean paramBoolean2)
  {
    // Byte code:
    //   0: iload 4
    //   2: ifeq +446 -> 448
    //   5: invokestatic 167	cn/jpush/android/c/r:b	()V
    //   8: aload_0
    //   9: invokevirtual 201	android/content/Context:getPackageManager	()Landroid/content/pm/PackageManager;
    //   12: aload_0
    //   13: invokevirtual 204	android/content/Context:getPackageName	()Ljava/lang/String;
    //   16: sipush 256
    //   19: invokevirtual 210	android/content/pm/PackageManager:getPackageInfo	(Ljava/lang/String;I)Landroid/content/pm/PackageInfo;
    //   22: getfield 216	android/content/pm/PackageInfo:applicationInfo	Landroid/content/pm/ApplicationInfo;
    //   25: getfield 222	android/content/pm/ApplicationInfo:icon	I
    //   28: istore 6
    //   30: iload 6
    //   32: ifge +12 -> 44
    //   35: aload_3
    //   36: getfield 225	cn/jpush/android/a/d:w	I
    //   39: invokestatic 227	cn/jpush/android/api/k:a	(I)I
    //   42: istore 6
    //   44: new 229	android/app/Notification
    //   47: dup
    //   48: invokespecial 230	android/app/Notification:<init>	()V
    //   51: astore 7
    //   53: aload 7
    //   55: invokestatic 235	java/lang/System:currentTimeMillis	()J
    //   58: putfield 239	android/app/Notification:when	J
    //   61: aload 7
    //   63: iload 6
    //   65: putfield 240	android/app/Notification:icon	I
    //   68: aload 7
    //   70: aload_3
    //   71: getfield 243	cn/jpush/android/a/d:A	Ljava/lang/String;
    //   74: putfield 247	android/app/Notification:tickerText	Ljava/lang/CharSequence;
    //   77: aload 7
    //   79: aload_3
    //   80: getfield 250	cn/jpush/android/a/d:y	I
    //   83: invokestatic 252	cn/jpush/android/api/k:b	(I)I
    //   86: putfield 255	android/app/Notification:flags	I
    //   89: aload_3
    //   90: getfield 258	cn/jpush/android/a/d:o	I
    //   93: tableswitch	default:+31 -> 124, 0:+293->386, 1:+281->374, 2:+287->380, 3:+299->392
    //   125: istore 8
    //   127: aload 7
    //   129: iload 8
    //   131: putfield 261	android/app/Notification:defaults	I
    //   134: aload_3
    //   135: getfield 265	cn/jpush/android/a/d:g	Z
    //   138: ifeq +22 -> 160
    //   141: aload 7
    //   143: iconst_3
    //   144: putfield 261	android/app/Notification:defaults	I
    //   147: aload_0
    //   148: invokestatic 271	cn/jpush/android/c/a:p	(Landroid/content/Context;)Z
    //   151: ifeq +9 -> 160
    //   154: aload 7
    //   156: iconst_0
    //   157: putfield 261	android/app/Notification:defaults	I
    //   160: iload 5
    //   162: ifeq +236 -> 398
    //   165: aload_0
    //   166: iload_1
    //   167: aload_2
    //   168: ldc_w 272
    //   171: invokestatic 278	android/app/PendingIntent:getBroadcast	(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   174: astore 9
    //   176: aload_3
    //   177: getfield 281	cn/jpush/android/a/d:P	Ljava/lang/String;
    //   180: invokestatic 155	cn/jpush/android/c/ac:a	(Ljava/lang/String;)Z
    //   183: ifne +246 -> 429
    //   186: aload_3
    //   187: getfield 281	cn/jpush/android/a/d:P	Ljava/lang/String;
    //   190: invokestatic 287	android/graphics/BitmapFactory:decodeFile	(Ljava/lang/String;)Landroid/graphics/Bitmap;
    //   193: astore 11
    //   195: aload 11
    //   197: ifnull +220 -> 417
    //   200: getstatic 107	cn/jpush/android/api/k:z	[Ljava/lang/String;
    //   203: bipush 11
    //   205: aaload
    //   206: astore 12
    //   208: iconst_1
    //   209: anewarray 13	java/lang/String
    //   212: astore 13
    //   214: aload 13
    //   216: iconst_0
    //   217: getstatic 107	cn/jpush/android/api/k:z	[Ljava/lang/String;
    //   220: bipush 13
    //   222: aaload
    //   223: aastore
    //   224: aload 12
    //   226: aload 13
    //   228: invokestatic 120	cn/jpush/android/api/k:a	(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/HashMap;
    //   231: getstatic 107	cn/jpush/android/api/k:z	[Ljava/lang/String;
    //   234: bipush 13
    //   236: aaload
    //   237: invokevirtual 126	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   240: checkcast 128	java/lang/Integer
    //   243: astore 14
    //   245: getstatic 107	cn/jpush/android/api/k:z	[Ljava/lang/String;
    //   248: bipush 12
    //   250: aaload
    //   251: astore 15
    //   253: iconst_1
    //   254: anewarray 13	java/lang/String
    //   257: astore 16
    //   259: aload 16
    //   261: iconst_0
    //   262: getstatic 107	cn/jpush/android/api/k:z	[Ljava/lang/String;
    //   265: bipush 14
    //   267: aaload
    //   268: aastore
    //   269: aload 15
    //   271: aload 16
    //   273: invokestatic 120	cn/jpush/android/api/k:a	(Ljava/lang/String;[Ljava/lang/String;)Ljava/util/HashMap;
    //   276: getstatic 107	cn/jpush/android/api/k:z	[Ljava/lang/String;
    //   279: bipush 14
    //   281: aaload
    //   282: invokevirtual 126	java/util/HashMap:get	(Ljava/lang/Object;)Ljava/lang/Object;
    //   285: checkcast 128	java/lang/Integer
    //   288: astore 17
    //   290: aload 14
    //   292: ifnull +120 -> 412
    //   295: aload 17
    //   297: ifnull +115 -> 412
    //   300: aload 14
    //   302: invokevirtual 132	java/lang/Integer:intValue	()I
    //   305: ifle +107 -> 412
    //   308: aload 17
    //   310: invokevirtual 132	java/lang/Integer:intValue	()I
    //   313: ifle +99 -> 412
    //   316: new 289	android/widget/RemoteViews
    //   319: dup
    //   320: aload_0
    //   321: invokevirtual 204	android/content/Context:getPackageName	()Ljava/lang/String;
    //   324: aload 17
    //   326: invokevirtual 132	java/lang/Integer:intValue	()I
    //   329: invokespecial 292	android/widget/RemoteViews:<init>	(Ljava/lang/String;I)V
    //   332: astore 18
    //   334: aload 18
    //   336: aload 14
    //   338: invokevirtual 132	java/lang/Integer:intValue	()I
    //   341: aload 11
    //   343: invokevirtual 296	android/widget/RemoteViews:setImageViewBitmap	(ILandroid/graphics/Bitmap;)V
    //   346: aload 7
    //   348: aload 18
    //   350: putfield 300	android/app/Notification:contentView	Landroid/widget/RemoteViews;
    //   353: aload 7
    //   355: aload 9
    //   357: putfield 304	android/app/Notification:contentIntent	Landroid/app/PendingIntent;
    //   360: aload 7
    //   362: areturn
    //   363: astore 19
    //   365: iconst_m1
    //   366: istore 6
    //   368: invokestatic 306	cn/jpush/android/c/r:g	()V
    //   371: goto -341 -> 30
    //   374: iconst_1
    //   375: istore 8
    //   377: goto -250 -> 127
    //   380: iconst_2
    //   381: istore 8
    //   383: goto -256 -> 127
    //   386: iconst_m1
    //   387: istore 8
    //   389: goto -262 -> 127
    //   392: iconst_4
    //   393: istore 8
    //   395: goto -268 -> 127
    //   398: aload_0
    //   399: iload_1
    //   400: aload_2
    //   401: ldc_w 272
    //   404: invokestatic 309	android/app/PendingIntent:getActivity	(Landroid/content/Context;ILandroid/content/Intent;I)Landroid/app/PendingIntent;
    //   407: astore 9
    //   409: goto -233 -> 176
    //   412: invokestatic 311	cn/jpush/android/c/r:d	()V
    //   415: aconst_null
    //   416: areturn
    //   417: invokestatic 311	cn/jpush/android/c/r:d	()V
    //   420: aconst_null
    //   421: areturn
    //   422: astore 10
    //   424: invokestatic 314	cn/jpush/android/c/r:h	()V
    //   427: aconst_null
    //   428: areturn
    //   429: aload 7
    //   431: aload_0
    //   432: aload_3
    //   433: getfield 316	cn/jpush/android/a/d:z	Ljava/lang/String;
    //   436: aload_3
    //   437: getfield 243	cn/jpush/android/a/d:A	Ljava/lang/String;
    //   440: aload 9
    //   442: invokevirtual 320	android/app/Notification:setLatestEventInfo	(Landroid/content/Context;Ljava/lang/CharSequence;Ljava/lang/CharSequence;Landroid/app/PendingIntent;)V
    //   445: goto -85 -> 360
    //   448: iconst_m1
    //   449: istore 6
    //   451: goto -421 -> 30
    // Local variable table:
    //   start	length	slot	name	signature
    //   0	454	0	paramContext	Context
    //   0	454	1	paramInt	int
    //   0	454	2	paramIntent	Intent
    //   0	454	3	paramd	d
    //   0	454	4	paramBoolean1	boolean
    //   0	454	5	paramBoolean2	boolean
    //   28	422	6	i	int
    //   51	379	7	localNotification	Notification
    //   125	269	8	j	int
    //   174	267	9	localPendingIntent	PendingIntent
    //   422	1	10	localException	Exception
    //   193	149	11	localBitmap	android.graphics.Bitmap
    //   206	19	12	str1	String
    //   212	15	13	arrayOfString1	String[]
    //   243	94	14	localInteger1	Integer
    //   251	19	15	str2	String
    //   257	15	16	arrayOfString2	String[]
    //   288	37	17	localInteger2	Integer
    //   332	17	18	localRemoteViews	android.widget.RemoteViews
    //   363	1	19	localNameNotFoundException	android.content.pm.PackageManager.NameNotFoundException
    // Exception table:
    //   from	to	target	type
    //   8	30	363	android/content/pm/PackageManager$NameNotFoundException
    //   186	195	422	java/lang/Exception
    //   200	290	422	java/lang/Exception
    //   300	360	422	java/lang/Exception
    //   412	415	422	java/lang/Exception
    //   417	420	422	java/lang/Exception
  }
  
  public static HashMap<String, Integer> a(String paramString, String[] paramArrayOfString)
  {
    int i = 0;
    if ((ac.a(paramString)) || (paramArrayOfString == null) || (paramArrayOfString.length == 0)) {
      throw new NullPointerException(z[3]);
    }
    localHashMap = new HashMap();
    try
    {
      String str1 = cn.jpush.android.a.d.getPackageName();
      for (Class localClass : Class.forName(str1 + z[2]).getDeclaredClasses()) {
        if (localClass.getName().contains(paramString))
        {
          int m = paramArrayOfString.length;
          while (i < m)
          {
            String str2 = paramArrayOfString[i];
            localHashMap.put(str2, Integer.valueOf(localClass.getDeclaredField(str2).getInt(str2)));
            i++;
          }
        }
      }
      return localHashMap;
    }
    catch (Exception localException)
    {
      r.h();
    }
  }
  
  public static void a(Context paramContext)
  {
    for (;;)
    {
      Integer localInteger = (Integer)a.poll();
      if (localInteger == null) {
        break;
      }
      a(paramContext, localInteger.intValue());
    }
  }
  
  public static void a(Context paramContext, int paramInt)
  {
    new StringBuilder(z[10]).append(paramInt).toString();
    r.b();
    if (paramContext == null) {
      paramContext = cn.jpush.android.a.d;
    }
    ((NotificationManager)paramContext.getSystemService(z[8])).cancel(paramInt);
  }
  
  public static void a(Context paramContext, d paramd)
  {
    if (Thread.currentThread().getId() == PushService.a)
    {
      r.c();
      new Thread(new l(paramContext, paramd)).start();
      return;
    }
    b(paramContext, paramd);
  }
  
  public static void a(Context paramContext, d paramd, int paramInt)
  {
    new StringBuilder(z[9]).append(paramd.c).toString();
    r.b();
    if (paramContext == null) {
      paramContext = cn.jpush.android.a.d;
    }
    ((NotificationManager)paramContext.getSystemService(z[8])).cancel(a(paramd, 0));
  }
  
  public static void a(Context paramContext, d paramd, boolean paramBoolean1, boolean paramBoolean2)
  {
    r.a();
    int i = a(paramd, 0);
    if ((paramd.g) && (paramd.e))
    {
      NotificationManager localNotificationManager2 = (NotificationManager)paramContext.getSystemService(z[8]);
      String str2;
      String str3;
      String str4;
      if ((paramd instanceof o))
      {
        str2 = paramd.A;
        str3 = paramd.z;
        str4 = paramd.k;
        if (!ac.a(paramd.l)) {
          break label235;
        }
      }
      HashMap localHashMap;
      label235:
      for (String str5 = paramContext.getPackageName();; str5 = paramd.l)
      {
        localHashMap = new HashMap();
        localHashMap.put(z[22], paramd.c);
        localHashMap.put(z[17], paramd.c);
        localHashMap.put(z[18], str2);
        if (!TextUtils.isEmpty(str3)) {
          localHashMap.put(z[15], str3);
        }
        if (!ac.a(str4)) {
          localHashMap.put(z[21], str4);
        }
        if (!ac.a(str4)) {
          localHashMap.put(z[21], str4);
        }
        if (!ac.a(str2)) {
          break;
        }
        a(paramContext, localHashMap, 0, "", str5, paramd);
        return;
      }
      PushNotificationBuilder localPushNotificationBuilder = JPushInterface.b(paramd.f);
      String str6 = localPushNotificationBuilder.a();
      Notification localNotification2 = localPushNotificationBuilder.a(str2, localHashMap);
      if ((localNotification2 != null) && (!ac.a(str2)))
      {
        Intent localIntent2;
        if (!paramd.f()) {
          if (cn.jpush.android.c.a.d(paramContext, PushReceiver.class.getCanonicalName()))
          {
            localIntent2 = new Intent(z[19] + UUID.randomUUID().toString());
            localIntent2.setClass(paramContext, PushReceiver.class);
            a(localIntent2, localHashMap, i);
            localIntent2.putExtra(z[18], str2);
            localIntent2.putExtra(z[26], str5);
            if (!ac.a(str6)) {
              localIntent2.putExtra(z[25], str6);
            }
          }
        }
        for (PendingIntent localPendingIntent = PendingIntent.getBroadcast(paramContext, 0, localIntent2, 0);; localPendingIntent = PendingIntent.getActivity(paramContext, i, cn.jpush.android.c.a.a(paramContext, paramd, false), 134217728))
        {
          localNotification2.contentIntent = localPendingIntent;
          if (!JPushInterface.a(paramd.f))
          {
            localNotification2.flags = b(paramd.y);
            if (localNotification2.defaults == 0) {
              localNotification2.defaults = 3;
            }
          }
          if (cn.jpush.android.c.a.p(paramContext)) {
            localNotification2.defaults = 0;
          }
          localNotificationManager2.notify(i, localNotification2);
          if (!a.contains(Integer.valueOf(i))) {
            a.offer(Integer.valueOf(i));
          }
          if (a.size() > z.a(paramContext, z[20], Integer.MAX_VALUE)) {}
          try
          {
            int j = ((Integer)a.poll()).intValue();
            if (j != 0) {
              localNotificationManager2.cancel(j);
            }
          }
          catch (Exception localException)
          {
            for (;;)
            {
              r.e();
            }
          }
          ServiceInterface.a(paramd.c, 1018, paramContext);
          a(paramContext, localHashMap, i, str6, str5, paramd);
          return;
          r.c();
          localIntent2 = new Intent(z[23]);
          localIntent2.addCategory(str5);
          break;
        }
      }
      r.d(z[24], z[28]);
      return;
    }
    NotificationManager localNotificationManager1 = (NotificationManager)paramContext.getSystemService(z[8]);
    Intent localIntent1;
    if ((paramd.Q != null) && (paramd.Q.size() > 0))
    {
      localIntent1 = new Intent();
      localIntent1.putExtra(z[7], paramd);
      localIntent1.setAction(z[27]);
      localIntent1.addCategory(z[16]);
    }
    for (Notification localNotification1 = a(paramContext, i, localIntent1, paramd, paramBoolean1, true);; localNotification1 = a(paramContext, i, cn.jpush.android.c.a.a(paramContext, paramd, paramBoolean2), paramd, paramBoolean1, false))
    {
      if ((paramd instanceof o)) {
        ((o)paramd).R.length();
      }
      if (localNotification1 != null) {
        break;
      }
      r.d();
      return;
    }
    if ((!paramBoolean1) && (!TextUtils.isEmpty(paramd.x)))
    {
      n localn = new n(paramContext.getMainLooper(), localNotification1, localNotificationManager1);
      String str1 = paramContext.getFilesDir().getAbsolutePath() + z[29];
      cn.jpush.android.c.n.a(paramd.x, str1, new m(localn, i, paramd));
      return;
    }
    ServiceInterface.a(paramd.c, 1018, paramContext);
    localNotificationManager1.notify(i, localNotification1);
  }
  
  public static void a(Context paramContext, String paramString)
  {
    new StringBuilder(z[38]).append(paramString).toString();
    r.b();
    if (paramContext == null) {
      paramContext = cn.jpush.android.a.d;
    }
    NotificationManager localNotificationManager = (NotificationManager)paramContext.getSystemService(z[8]);
    localNotificationManager.cancel(a(paramString, 0));
    localNotificationManager.cancel(a(paramString, 1));
  }
  
  private static void a(Context paramContext, Map<String, String> paramMap, int paramInt, String paramString1, String paramString2, d paramd)
  {
    r.b(z[24], z[36]);
    Intent localIntent = new Intent(z[32]);
    a(localIntent, paramMap, paramInt);
    if (!ac.a(paramString1)) {
      localIntent.putExtra(z[25], paramString1);
    }
    if ((paramd.f()) && ((paramd instanceof o)))
    {
      o localo = (o)paramd;
      if (localo.aa.startsWith(z[35])) {
        localo.aa = localo.aa.replaceFirst(z[35], "");
      }
      localIntent.putExtra(z[31], localo.aa);
      if ((localo.X != null) && (localo.X.size() > 0))
      {
        StringBuilder localStringBuilder = new StringBuilder();
        String str1 = cn.jpush.android.c.k.b(paramContext, paramd.c);
        Iterator localIterator = localo.X.iterator();
        while (localIterator.hasNext())
        {
          String str2 = (String)localIterator.next();
          if (str2.startsWith(z[34])) {
            str2 = cn.jpush.android.c.m.c(str2);
          }
          if (ac.a(localStringBuilder.toString())) {
            localStringBuilder.append(str1).append(str2);
          } else {
            localStringBuilder.append(",").append(str1).append(str2);
          }
        }
        localIntent.putExtra(z[30], localStringBuilder.toString());
      }
    }
    localIntent.addCategory(paramString2);
    paramContext.sendBroadcast(localIntent, paramString2 + z[33]);
  }
  
  private static void a(Intent paramIntent, Map<String, String> paramMap, int paramInt)
  {
    Iterator localIterator = paramMap.keySet().iterator();
    while (localIterator.hasNext())
    {
      String str = (String)localIterator.next();
      paramIntent.putExtra(str, (String)paramMap.get(str));
    }
    if (paramInt != 0) {
      paramIntent.putExtra(z[37], paramInt);
    }
  }
  
  private static int b(int paramInt)
  {
    switch (paramInt)
    {
    case 0: 
    default: 
      return 1;
    case 1: 
      return 16;
    }
    return 32;
  }
  
  public static void b(Context paramContext, d paramd)
  {
    d locald2;
    d locald1;
    if ((!ac.a(paramd.s)) && (!paramd.t))
    {
      locald2 = d.a(paramContext, paramd);
      if (locald2 == null)
      {
        r.e();
        locald1 = null;
        if (locald1 != null) {
          break label50;
        }
      }
    }
    label50:
    label102:
    do
    {
      do
      {
        return;
        locald2.t = true;
        locald1 = paramd;
        break;
        if (paramd.C < 0) {
          break label102;
        }
      } while (d(paramContext, paramd) == null);
      Intent localIntent = new Intent();
      localIntent.setAction(z[6]);
      localIntent.putExtra(z[7], paramd);
      paramContext.sendBroadcast(localIntent);
      return;
    } while (c(paramContext, paramd) == null);
    a(paramContext, paramd, false, false);
  }
  
  private static d c(Context paramContext, d paramd)
  {
    if ((!ac.a(paramd.q)) && (!paramd.r))
    {
      r.c();
      byte[] arrayOfByte = cn.jpush.android.c.n.a(paramd.q, 5, 5000L, 4);
      if (arrayOfByte != null) {
        try
        {
          int i = paramd.q.lastIndexOf("/");
          String str1 = paramd.q.substring(i + 1);
          String str2 = cn.jpush.android.c.k.a(paramContext, paramd.c) + str1;
          if (cn.jpush.android.c.m.a(str2, arrayOfByte, paramContext))
          {
            paramd.P = str2;
            paramd.r = true;
            new StringBuilder(z[0]).append(str2).toString();
            r.a();
            return paramd;
          }
          r.e();
          return null;
        }
        catch (Exception localException)
        {
          r.g();
          return null;
        }
      }
      new StringBuilder(z[39]).append(paramd.q).toString();
      r.d();
      paramd = null;
    }
    return paramd;
  }
  
  private static d d(Context paramContext, d paramd)
  {
    if (!ac.a(paramd.F))
    {
      r.c();
      byte[] arrayOfByte = cn.jpush.android.c.n.a(paramd.F, 5, 5000L, 4);
      if (arrayOfByte != null) {
        try
        {
          int i = paramd.F.lastIndexOf("/");
          String str1 = paramd.F.substring(i + 1);
          String str2 = cn.jpush.android.c.k.a(paramContext, paramd.c) + str1;
          if (cn.jpush.android.c.m.a(str2, arrayOfByte, paramContext))
          {
            paramd.G = str2;
            new StringBuilder(z[0]).append(str2).toString();
            r.a();
            return paramd;
          }
          r.e();
          return null;
        }
        catch (Exception localException)
        {
          r.g();
          return null;
        }
      }
      new StringBuilder(z[1]).append(paramd.G).toString();
      r.d();
      paramd = null;
    }
    return paramd;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.k
 * JD-Core Version:    0.7.1
 */