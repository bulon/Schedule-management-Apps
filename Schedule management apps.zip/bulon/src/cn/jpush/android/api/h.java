package cn.jpush.android.api;

import android.content.Context;

final class h
  implements Runnable
{
  h(e parame, Context paramContext) {}
  
  public final void run()
  {
    e.b(this.b, this.a);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.h
 * JD-Core Version:    0.7.1
 */