package cn.jpush.android.api;

public final class a
{
  public String a;
  public long b;
  
  public a(String paramString, long paramLong)
  {
    this.a = paramString;
    this.b = paramLong;
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.a
 * JD-Core Version:    0.7.1
 */