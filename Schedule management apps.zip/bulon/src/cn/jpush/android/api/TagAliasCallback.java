package cn.jpush.android.api;

import java.util.Set;

public abstract interface TagAliasCallback
{
  public abstract void gotResult(int paramInt, String paramString, Set<String> paramSet);
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.TagAliasCallback
 * JD-Core Version:    0.7.1
 */