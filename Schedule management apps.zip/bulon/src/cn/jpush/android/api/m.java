package cn.jpush.android.api;

import android.os.Bundle;
import android.os.Message;
import cn.jpush.android.a.d;
import cn.jpush.android.c.p;

final class m
  implements p
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[3];
    String str1 = "3`?149`\005&";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 85;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "7v\03776=";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        j = 2;
        arrayOfString2 = arrayOfString1;
        str1 = "8l '\005?q$";
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 94;
        break label96;
        i3 = 5;
        break label96;
        i3 = 76;
        break label96;
        i3 = 66;
        break label96;
        m = 0;
      }
    }
  }
  
  m(n paramn, int paramInt, d paramd) {}
  
  public final void a(boolean paramBoolean, String paramString)
  {
    Message localMessage = this.a.obtainMessage(this.b);
    Bundle localBundle = new Bundle();
    localBundle.putBoolean(z[1], paramBoolean);
    localBundle.putString(z[2], paramString);
    localBundle.putString(z[0], this.c.c);
    localMessage.setData(localBundle);
    localMessage.sendToTarget();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.m
 * JD-Core Version:    0.7.1
 */