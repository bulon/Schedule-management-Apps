package cn.jpush.android.api;

import android.app.Activity;
import android.app.Application.ActivityLifecycleCallbacks;
import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.os.Build.VERSION;
import android.os.Bundle;
import cn.jpush.android.c.a;
import cn.jpush.android.c.ac;
import java.util.HashMap;

final class j
  implements Application.ActivityLifecycleCallbacks
{
  private static final String[] z;
  
  static
  {
    String[] arrayOfString1 = new String[2];
    String str1 = "Z4u)ZR>?2[O?/\033X;e>RT(huyz\017_\030}~\b";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 53;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "Z4u)ZR>?2[O?/\033Z9e2ZUt\\\032|u";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 59;
        break label96;
        i3 = 90;
        break label96;
        i3 = 17;
        break label96;
        i3 = 91;
        break label96;
        m = 0;
      }
    }
  }
  
  public final void onActivityCreated(Activity paramActivity, Bundle paramBundle) {}
  
  public final void onActivityDestroyed(Activity paramActivity) {}
  
  public final void onActivityPaused(Activity paramActivity)
  {
    i.c(paramActivity.getClass().getName());
    if (ac.a(i.f())) {
      i.a(paramActivity.getClass().getName());
    }
    if ((Build.VERSION.SDK_INT >= 14) && (i.a))
    {
      if (!e.a)
      {
        i.c().put(i.f(), Integer.valueOf(0));
        if ((!ac.a(i.d())) && (i.d().equals(i.f()))) {
          a.a(paramActivity, i.e(), i.f(), 0);
        }
      }
      e.a = false;
    }
  }
  
  public final void onActivityResumed(Activity paramActivity)
  {
    i.a(paramActivity.getClass().getName());
    if ((Build.VERSION.SDK_INT >= 14) && (i.a))
    {
      if (i.a())
      {
        Intent localIntent = new Intent(z[1]);
        localIntent.setPackage(paramActivity.getPackageName());
        localIntent.addCategory(z[0]);
        i.b(paramActivity.getPackageManager().resolveActivity(localIntent, 0).activityInfo.name);
        i.a(false);
      }
    }
    else {
      return;
    }
    if (!e.b)
    {
      if (!i.c().containsKey(i.b())) {
        break label157;
      }
      i.c().put(i.b(), Integer.valueOf(2));
      if ((!ac.a(i.d())) && (i.d().equals(i.b()))) {
        a.a(paramActivity, i.e(), i.b(), 2);
      }
    }
    for (;;)
    {
      e.b = false;
      return;
      label157:
      i.c().put(i.b(), Integer.valueOf(1));
      if ((!ac.a(i.d())) && (i.d().equals(i.b()))) {
        a.a(paramActivity, i.e(), i.b(), 1);
      }
    }
  }
  
  public final void onActivitySaveInstanceState(Activity paramActivity, Bundle paramBundle) {}
  
  public final void onActivityStarted(Activity paramActivity) {}
  
  public final void onActivityStopped(Activity paramActivity) {}
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.j
 * JD-Core Version:    0.7.1
 */