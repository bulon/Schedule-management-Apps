package cn.jpush.android.api;

import android.app.Notification;
import android.content.Context;
import cn.jpush.android.a;

public class BasicPushNotificationBuilder
  extends DefaultPushNotificationBuilder
{
  private static final String[] z;
  protected Context a;
  public String developerArg0 = "";
  public int notificationDefaults = -1;
  public int notificationFlags = 16;
  public int statusBarDrawable = a.a;
  
  static
  {
    String[] arrayOfString1 = new String[5];
    String str1 = "~\023\034YPC-0ol";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 51;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "C-0ol";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        str1 = "\007\034D\\q";
        j = 2;
        arrayOfString2 = arrayOfString1;
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        str1 = "~\023\034YP";
        j = 3;
        arrayOfString2 = arrayOfString1;
        i = 2;
        break;
      case 2: 
        arrayOfString2[j] = str2;
        j = 4;
        arrayOfString2 = arrayOfString1;
        str1 = "R'#|\023\035\001DVd\006";
        i = 3;
        break;
      case 3: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 28;
        break label96;
        i3 = 114;
        break label96;
        i3 = 111;
        break label96;
        i3 = 48;
        break label96;
        m = 0;
      }
    }
  }
  
  public BasicPushNotificationBuilder(Context paramContext)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException(z[4]);
    }
    this.a = paramContext;
  }
  
  static PushNotificationBuilder a(String paramString)
  {
    String[] arrayOfString = paramString.split(z[1]);
    String str = arrayOfString[0];
    Object localObject;
    if (z[3].equals(str)) {
      localObject = new BasicPushNotificationBuilder(a.d);
    }
    for (;;)
    {
      ((BasicPushNotificationBuilder)localObject).a(arrayOfString);
      return (PushNotificationBuilder)localObject;
      if (z[2].equals(str)) {
        localObject = new CustomPushNotificationBuilder(a.d);
      } else {
        localObject = new BasicPushNotificationBuilder(a.d);
      }
    }
  }
  
  public final String a()
  {
    return this.developerArg0;
  }
  
  final void a(Notification paramNotification)
  {
    paramNotification.defaults = this.notificationDefaults;
    paramNotification.flags = this.notificationFlags;
    paramNotification.icon = this.statusBarDrawable;
  }
  
  void a(String[] paramArrayOfString)
  {
    this.notificationDefaults = Integer.parseInt(paramArrayOfString[1]);
    this.notificationFlags = Integer.parseInt(paramArrayOfString[2]);
    this.statusBarDrawable = Integer.parseInt(paramArrayOfString[3]);
    this.developerArg0 = paramArrayOfString[4];
  }
  
  String b()
  {
    return this.notificationDefaults + z[1] + this.notificationFlags + z[1] + this.statusBarDrawable + z[1] + this.developerArg0;
  }
  
  public String toString()
  {
    return z[0] + b();
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.BasicPushNotificationBuilder
 * JD-Core Version:    0.7.1
 */