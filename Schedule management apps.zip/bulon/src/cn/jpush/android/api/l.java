package cn.jpush.android.api;

import android.content.Context;
import cn.jpush.android.a.d;

final class l
  implements Runnable
{
  l(Context paramContext, d paramd) {}
  
  public final void run()
  {
    k.b(this.a, this.b);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.l
 * JD-Core Version:    0.7.1
 */