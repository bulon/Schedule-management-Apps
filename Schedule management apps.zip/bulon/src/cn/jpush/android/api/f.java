package cn.jpush.android.api;

import android.content.Context;

final class f
  implements Runnable
{
  f(e parame, Context paramContext) {}
  
  public final void run()
  {
    e.a(this.b, this.a);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.f
 * JD-Core Version:    0.7.1
 */