package cn.jpush.android.api;

import android.content.Context;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public final class c
  implements Thread.UncaughtExceptionHandler
{
  private static c b;
  private static final String[] z;
  public boolean a = false;
  private Thread.UncaughtExceptionHandler c = null;
  private Context d;
  
  static
  {
    Object localObject1 = new String[12];
    int i = 0;
    String str1 = "}gDe7zaDe9";
    int j = -1;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label36:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label52:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 92;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label52;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label36;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "m|Ph(";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "xvWu5a}Fi8k";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "`fIj";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "xvWu5a}Kg1k";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "maDu4zzHc";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "cvVu=iv";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "dcPu4QfKe={tMr9vp@v(g|KY:g@";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "zjUc";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "maDu4b|Bu";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "maDu4QJa";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "ggLk9";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        b = new c();
        return;
        i3 = 14;
        continue;
        i3 = 19;
        continue;
        i3 = 37;
        continue;
        i3 = 6;
      }
    }
  }
  
  public static c a()
  {
    return b;
  }
  
  private JSONArray a(Context paramContext, Throwable paramThrowable)
  {
    JSONArray localJSONArray = d(paramContext);
    StringWriter localStringWriter = new StringWriter();
    paramThrowable.printStackTrace(new PrintWriter(localStringWriter));
    String str1 = localStringWriter.toString();
    if (localJSONArray == null) {
      localJSONArray = new JSONArray();
    }
    int i = 0;
    try
    {
      if (i < localJSONArray.length())
      {
        localJSONObject1 = localJSONArray.optJSONObject(i);
        if ((localJSONObject1 == null) || (!str1.equals(localJSONObject1.getString(z[0])))) {
          break label337;
        }
        int k = 1 + localJSONObject1.getInt(z[1]);
        localJSONObject1.put(z[1], k);
        localJSONObject1.put(z[5], System.currentTimeMillis());
        j = i;
        if (localJSONObject1 != null)
        {
          localJSONArray = a(localJSONArray, j);
          localJSONArray.put(localJSONObject1);
          return localJSONArray;
        }
        JSONObject localJSONObject2 = new JSONObject();
        localJSONObject2.put(z[5], System.currentTimeMillis());
        localJSONObject2.put(z[0], str1);
        localJSONObject2.put(z[6], paramThrowable.toString());
        localJSONObject2.put(z[1], 1);
        PackageInfo localPackageInfo = this.d.getPackageManager().getPackageInfo(this.d.getPackageName(), 1);
        if (localPackageInfo != null) {
          if (localPackageInfo.versionName != null) {
            break label314;
          }
        }
        label314:
        for (String str2 = z[3];; str2 = localPackageInfo.versionName)
        {
          String str3 = localPackageInfo.versionCode;
          localJSONObject2.put(z[4], str2);
          localJSONObject2.put(z[2], str3);
          localJSONArray.put(localJSONObject2);
          return localJSONArray;
        }
      }
    }
    catch (PackageManager.NameNotFoundException localNameNotFoundException)
    {
      for (;;)
      {
        return localJSONArray;
        JSONObject localJSONObject1 = null;
        int j = 0;
        continue;
        label337:
        i++;
      }
    }
    catch (JSONException localJSONException) {}
    return localJSONArray;
  }
  
  private static JSONArray a(JSONArray paramJSONArray, int paramInt)
  {
    if (paramJSONArray == null) {
      return null;
    }
    JSONArray localJSONArray = new JSONArray();
    int i = 0;
    for (;;)
    {
      if ((i >= paramJSONArray.length()) || (i != paramInt)) {}
      try
      {
        localJSONArray.put(paramJSONArray.get(i));
        label39:
        i++;
        continue;
        return localJSONArray;
      }
      catch (JSONException localJSONException)
      {
        break label39;
      }
    }
  }
  
  private void a(JSONArray paramJSONArray)
  {
    String str = paramJSONArray.toString();
    if ((str != null) && (str.length() > 0)) {}
    try
    {
      FileOutputStream localFileOutputStream = this.d.openFileOutput(z[7], 0);
      localFileOutputStream.write(str.getBytes());
      localFileOutputStream.flush();
      localFileOutputStream.close();
      return;
    }
    catch (IOException localIOException) {}catch (FileNotFoundException localFileNotFoundException) {}
  }
  
  public static void b(Context paramContext)
  {
    File localFile = new File(paramContext.getFilesDir(), z[7]);
    if (localFile.exists()) {
      localFile.delete();
    }
  }
  
  private static JSONArray d(Context paramContext)
  {
    if (!new File(paramContext.getFilesDir(), z[7]).exists()) {
      return null;
    }
    JSONArray localJSONArray;
    try
    {
      FileInputStream localFileInputStream = paramContext.openFileInput(z[7]);
      byte[] arrayOfByte = new byte[1024];
      StringBuffer localStringBuffer = new StringBuffer();
      for (;;)
      {
        int i = localFileInputStream.read(arrayOfByte);
        if (i == -1) {
          break;
        }
        localStringBuffer.append(new String(arrayOfByte, 0, i));
      }
      if (localStringBuffer.toString().length() > 0) {
        localJSONArray = new JSONArray(localStringBuffer.toString());
      } else {
        localJSONArray = null;
      }
    }
    catch (Exception localException)
    {
      localJSONArray = null;
    }
    return localJSONArray;
  }
  
  public final void a(Context paramContext)
  {
    this.d = paramContext;
    if (this.c == null) {
      this.c = Thread.getDefaultUncaughtExceptionHandler();
    }
    Thread.setDefaultUncaughtExceptionHandler(this);
    this.a = true;
  }
  
  public final JSONObject c(Context paramContext)
  {
    if (!this.a) {}
    JSONArray localJSONArray;
    do
    {
      return null;
      localJSONArray = d(paramContext);
    } while (localJSONArray == null);
    JSONObject localJSONObject = new JSONObject();
    try
    {
      localJSONObject.put(z[9], localJSONArray);
      localJSONObject.put(z[11], System.currentTimeMillis() / 1000L);
      localJSONObject.put(z[8], z[10]);
      return localJSONObject;
    }
    catch (JSONException localJSONException) {}
    return localJSONObject;
  }
  
  public final void uncaughtException(Thread paramThread, Throwable paramThrowable)
  {
    JSONArray localJSONArray = a(this.d, paramThrowable);
    b(this.d);
    a(localJSONArray);
    if (this.c != this) {
      this.c.uncaughtException(paramThread, paramThrowable);
    }
    throw new RuntimeException(paramThrowable);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.c
 * JD-Core Version:    0.7.1
 */