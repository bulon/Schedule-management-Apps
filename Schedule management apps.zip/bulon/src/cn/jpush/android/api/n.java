package cn.jpush.android.api;

import android.app.Notification;
import android.app.NotificationManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;
import android.widget.RemoteViews;
import cn.jpush.android.a;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.service.ServiceInterface;

final class n
  extends Handler
{
  private static final String[] z;
  private NotificationManager a;
  private Notification b;
  
  static
  {
    String[] arrayOfString1 = new String[3];
    String str1 = "p\037>3\"z\037\004$";
    int i = -1;
    String[] arrayOfString2 = arrayOfString1;
    int j = 0;
    Object localObject1 = str1.toCharArray();
    int k = localObject1.length;
    int m;
    label35:
    int i3;
    if (k <= 1)
    {
      m = 0;
      Object localObject2 = localObject1;
      int n = m;
      int i1 = k;
      Object localObject3 = localObject1;
      for (;;)
      {
        int i2 = localObject3[m];
        switch (n % 5)
        {
        default: 
          i3 = 67;
          label96:
          localObject3[m] = ((char)(i3 ^ i2));
          m = n + 1;
          if (i1 != 0) {
            break label133;
          }
          localObject3 = localObject2;
          n = m;
          m = i1;
        }
      }
      label133:
      k = i1;
      localObject1 = localObject2;
    }
    for (;;)
    {
      if (k > m) {
        break label35;
      }
      String str2 = new String((char[])localObject1).intern();
      switch (i)
      {
      default: 
        arrayOfString2[j] = str2;
        str1 = "t\t\0365 ~";
        j = 1;
        arrayOfString2 = arrayOfString1;
        i = 0;
        break;
      case 0: 
        arrayOfString2[j] = str2;
        j = 2;
        arrayOfString2 = arrayOfString1;
        str1 = "{\023!%\023|\016%";
        i = 1;
        break;
      case 1: 
        arrayOfString2[j] = str2;
        z = arrayOfString1;
        return;
        i3 = 29;
        break label96;
        i3 = 122;
        break label96;
        i3 = 77;
        break label96;
        i3 = 64;
        break label96;
        m = 0;
      }
    }
  }
  
  public n(Looper paramLooper, Notification paramNotification, NotificationManager paramNotificationManager)
  {
    super(paramLooper);
    this.b = paramNotification;
    this.a = paramNotificationManager;
  }
  
  public final void handleMessage(Message paramMessage)
  {
    super.handleMessage(paramMessage);
    Bundle localBundle = paramMessage.getData();
    boolean bool = localBundle.getBoolean(z[1]);
    String str1 = localBundle.getString(z[2]);
    if ((bool) && (!TextUtils.isEmpty(str1))) {}
    for (;;)
    {
      try
      {
        Bitmap localBitmap = BitmapFactory.decodeFile(str1);
        if (localBitmap != null) {
          this.b.contentView.setImageViewBitmap(16908294, localBitmap);
        }
      }
      catch (Exception localException)
      {
        String str2;
        r.i();
        continue;
      }
      str2 = localBundle.getString(z[0]);
      if (!ac.a(str2)) {
        ServiceInterface.a(str2, 1018, a.d);
      }
      this.a.notify(paramMessage.what, this.b);
      return;
      r.a();
    }
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.n
 * JD-Core Version:    0.7.1
 */