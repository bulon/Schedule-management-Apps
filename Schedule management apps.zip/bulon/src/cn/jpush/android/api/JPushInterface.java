package cn.jpush.android.api;

import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.PackageManager;
import cn.jpush.android.c.a;
import cn.jpush.android.c.ac;
import cn.jpush.android.c.r;
import cn.jpush.android.c.t;
import cn.jpush.android.c.v;
import cn.jpush.android.c.z;
import cn.jpush.android.service.AlarmReceiver;
import cn.jpush.android.service.PushReceiver;
import cn.jpush.android.service.PushService;
import cn.jpush.android.service.ServiceInterface;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class JPushInterface
{
  public static final String ACTION_ACTIVITY_OPENDED;
  public static final String ACTION_MESSAGE_RECEIVED;
  public static final String ACTION_NOTIFICATION_OPENED;
  public static final String ACTION_NOTIFICATION_RECEIVED;
  public static final String ACTION_NOTIFICATION_RECEIVED_PROXY;
  public static final String ACTION_REGISTRATION_ID;
  public static final String ACTION_RESTOREPUSH;
  public static final String ACTION_RICHPUSH_CALLBACK;
  public static final String ACTION_STATUS;
  public static final String ACTION_STOPPUSH;
  public static final String ACTION_UNREGISTER;
  public static final String EXTRA_ACTIVITY_PARAM;
  public static final String EXTRA_ALERT;
  public static final String EXTRA_APP_KEY;
  public static final String EXTRA_CONTENT_TYPE;
  public static final String EXTRA_EXTRA;
  public static final String EXTRA_MESSAGE;
  public static final String EXTRA_MSG_ID;
  public static final String EXTRA_NOTIFICATION_DEVELOPER_ARG0;
  public static final String EXTRA_NOTIFICATION_ID;
  public static final String EXTRA_NOTIFICATION_TITLE;
  public static final String EXTRA_PUSH_ID;
  public static final String EXTRA_REGISTRATION_ID;
  public static final String EXTRA_RICHPUSH_FILE_PATH;
  public static final String EXTRA_RICHPUSH_FILE_TYPE;
  public static final String EXTRA_RICHPUSH_HTML_PATH;
  public static final String EXTRA_RICHPUSH_HTML_RES;
  public static final String EXTRA_STATUS;
  public static final String EXTRA_TITLE;
  private static final Integer a;
  private static ConcurrentHashMap<Integer, PushNotificationBuilder> b;
  private static e c;
  private static final String[] z;
  
  static
  {
    Object localObject1 = new String[49];
    int i = 0;
    String str1 = "m<Ys\016{!\0377\037`6\005v\027j|9V*G\024>Z?Z\0338W!G\026";
    int j = 48;
    Object localObject2 = localObject1;
    Object localObject3 = str1.toCharArray();
    int k = localObject3.length;
    int m = 0;
    label37:
    Object localObject4;
    int n;
    int i1;
    Object localObject5;
    label53:
    int i2;
    int i3;
    if (k <= 1)
    {
      localObject4 = localObject3;
      n = m;
      i1 = k;
      localObject5 = localObject3;
      i2 = localObject5[m];
      switch (n % 5)
      {
      default: 
        i3 = 126;
      }
    }
    for (;;)
    {
      localObject5[m] = ((char)(i3 ^ i2));
      m = n + 1;
      if (i1 == 0)
      {
        localObject5 = localObject4;
        n = m;
        m = i1;
        break label53;
        EXTRA_NOTIFICATION_ID = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\0037,K\001#V,K\002\"J6";
        j = 49;
        break;
        ACTION_RESTOREPUSH = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|6I.E\027.";
        j = 50;
        break;
        EXTRA_APP_KEY = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\00370A\006>_7M\023#P1@\r8I;@\0273";
        j = 51;
        break;
        ACTION_NOTIFICATION_OPENED = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\00373K\001$X9K\r%\\=K\033!\\:";
        j = 52;
        break;
        ACTION_MESSAGE_RECEIVED = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|%\\9G\001#K?Z\0338W!G\026";
        j = 53;
        break;
        EXTRA_REGISTRATION_ID = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|6Z*G\004>M'Q\0026K?C";
        j = 54;
        break;
        EXTRA_ACTIVITY_PARAM = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|:\\-]\0230\\";
        j = 55;
        break;
        EXTRA_MESSAGE = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\00370A\006>_7M\023#P1@\r%\\=K\033!\\:";
        j = 56;
        break;
        ACTION_NOTIFICATION_RECEIVED = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|?M3B\r'X*F";
        j = 57;
        break;
        EXTRA_RICHPUSH_HTML_PATH = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\00370A\006>_7M\023#P1@\r%\\=K\033!\\:Q\002%V&W";
        j = 58;
        break;
        ACTION_NOTIFICATION_RECEIVED_PROXY = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|1P2K\r'X*F";
        j = 59;
        break;
        EXTRA_RICHPUSH_FILE_PATH = str2;
        str1 = "";
        j = 60;
        break;
        ACTION_UNREGISTER = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|$M?Z\007$";
        j = 61;
        break;
        EXTRA_STATUS = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\0037?M\006>V0Q\0234M7X\033#@!A\0022W:K\026";
        j = 62;
        break;
        ACTION_ACTIVITY_OPENDED = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|?M3B\r%\\-";
        j = 63;
        break;
        EXTRA_RICHPUSH_HTML_RES = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|1P2K\r#@.K";
        j = 64;
        break;
        EXTRA_RICHPUSH_FILE_TYPE = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|9V*G\024>Z?Z\0338W!M\0359M;@\006(M7Z\0362";
        j = 65;
        break;
        EXTRA_NOTIFICATION_TITLE = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\0037,K\025>J*\\\023#P1@";
        j = 66;
        break;
        ACTION_REGISTRATION_ID = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|4V0Z\0279M!Z\013'\\";
        j = 67;
        break;
        EXTRA_CONTENT_TYPE = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|#P*B\027";
        j = 68;
        break;
        EXTRA_TITLE = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|'L-F\r>]";
        j = 69;
        break;
        EXTRA_PUSH_ID = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|6U;\\\006";
        j = 70;
        break;
        EXTRA_ALERT = str2;
        str1 = "";
        j = 71;
        break;
        EXTRA_NOTIFICATION_DEVELOPER_ARG0 = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|:J9Q\0333";
        j = 72;
        break;
        EXTRA_MSG_ID = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|2A*\\\023";
        j = 73;
        break;
        EXTRA_EXTRA = str2;
        str1 = "";
        j = 74;
        break;
        ACTION_RICHPUSH_CALLBACK = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\0037-Z\035'I+]\032";
        j = 75;
        break;
        ACTION_STOPPUSH = str2;
        str1 = "m<Ys\016{!\0377\037`6\005v\027j|\036w\nk<\0037-Z\023#L-";
        j = 76;
        break;
        ACTION_STATUS = str2;
        str1 = "Z:\02290a&\036\027m3\003p\021`r5l\027b6\022k^g6Wx\022|7\026}\007.7\017j\027z!W4^";
        j = -1;
        break;
      }
      k = i1;
      localObject3 = localObject4;
      if (k > m) {
        break label37;
      }
      String str2 = new String((char[])localObject3).intern();
      switch (j)
      {
      case 48: 
      case 49: 
      case 50: 
      case 51: 
      case 52: 
      case 53: 
      case 54: 
      case 55: 
      case 56: 
      case 57: 
      case 58: 
      case 59: 
      case 60: 
      case 61: 
      case 62: 
      case 63: 
      case 64: 
      case 65: 
      case 66: 
      case 67: 
      case 68: 
      case 69: 
      case 70: 
      case 71: 
      case 72: 
      case 73: 
      case 74: 
      case 75: 
      case 76: 
      default: 
        localObject1[i] = str2;
        i = 1;
        str1 = "g6Wj\026a'\033}^l7Wu\037|5\022k^z:\026w^>";
        localObject1 = localObject2;
        j = 0;
        break;
      case 0: 
        localObject1[i] = str2;
        i = 2;
        str1 = "@\007;U^~'\004q0a&\036\027m3\003p\021`\020\002p\022j7\005";
        j = 1;
        localObject1 = localObject2;
        break;
      case 1: 
        localObject1[i] = str2;
        i = 3;
        str1 = "o1\003p\021`h\004|\n^'\004q0a&\036\027m3\003p\021`\020\002p\022j7\0059S.;\023#";
        j = 2;
        localObject1 = localObject2;
        break;
      case 2: 
        localObject1[i] = str2;
        i = 4;
        str1 = "D\002\002j\026G<\003|\fh3\024|";
        j = 3;
        localObject1 = localObject2;
        break;
      case 3: 
        localObject1[i] = str2;
        i = 5;
        str1 = "M'\004m\021c;\r|\032.0\002p\022j7\0059\030|=\0329\ro$\022}^~ \022\033|7\031z\033.W";
        j = 4;
        localObject1 = localObject2;
        break;
      case 4: 
        localObject1[i] = str2;
        i = 6;
        str1 = "o1\003p\021`h\020|\n^'\004q0a&\036\027m3\003p\021`\020\002p\022j7\0059D.";
        j = 5;
        localObject1 = localObject2;
        break;
      case 5: 
        localObject1[i] = str2;
        i = 7;
        str1 = "o1\003p\021`h\036w\027z~WM\026kr\004}\025.$\022k\rg=\0319\027}r";
        j = 6;
        localObject1 = localObject2;
        break;
      case 6: 
        localObject1[i] = str2;
        i = 8;
        str1 = "`=\003p\030o1\003p\021`\r\031l\023";
        j = 7;
        localObject1 = localObject2;
        break;
      case 7: 
        localObject1[i] = str2;
        i = 9;
        str1 = "@\007;U^m=\031m\033v&";
        j = 8;
        localObject1 = localObject2;
        break;
      case 8: 
        localObject1[i] = str2;
        i = 10;
        str1 = "";
        j = 9;
        localObject1 = localObject2;
        break;
      case 9: 
        localObject1[i] = str2;
        i = 11;
        str1 = "棎洙則彊刳沯杛缦绅ぼ歪勺伫尟坖朇缃纫旯膔劦纵纚找蠲「";
        j = 10;
        localObject1 = localObject2;
        break;
      case 10: 
        localObject1[i] = str2;
        i = 12;
        str1 = "\"r\003x\031}h";
        j = 11;
        localObject1 = localObject2;
        break;
      case 11: 
        localObject1[i] = str2;
        i = 13;
        str1 = "Z:\0229\022k<\020m\026.=\0219\no5\0049\rf=\002u\032.0\0229\022k!\0049\nf3\0319O>bG9\034w&\022jP";
        j = 12;
        localObject1 = localObject2;
        break;
      case 12: 
        localObject1[i] = str2;
        i = 14;
        str1 = "G<\001x\022g6Wx\022g3\004#^";
        j = 13;
        localObject1 = localObject2;
        break;
      case 13: 
        localObject1[i] = str2;
        i = 15;
        str1 = "";
        j = 14;
        localObject1 = localObject2;
        break;
      case 14: 
        localObject1[i] = str2;
        i = 16;
        str1 = "@\007;U^o>\036x\r.3\031}^z3\020jP.\025\036o\033.'\0079\037m&\036v\020 ";
        j = 15;
        localObject1 = localObject2;
        break;
      case 15: 
        localObject1[i] = str2;
        i = 17;
        str1 = "G<\001x\022g6Wm\037i![9\tg>\0339\020a&Wj\033zr\003x\031}r\003q\027}r\003p\023k|";
        j = 16;
        localObject1 = localObject2;
        break;
      case 16: 
        localObject1[i] = str2;
        i = 18;
        str1 = "o1\003p\021`h\004|\nO>\036x\rO<\023M\037i!W4^o>\036x\r4";
        j = 17;
        localObject1 = localObject2;
        break;
      case 17: 
        localObject1[i] = str2;
        i = 19;
        str1 = "@\007;U^`=\003p\030g1\026m\027a<";
        j = 18;
        localObject1 = localObject2;
        break;
      case 18: 
        localObject1[i] = str2;
        i = 20;
        str1 = "G<\001x\022g6Ww\021z;\021p\035o&\036v\020G6[99g$\0229\013~r\026z\ng=\0317P";
        j = 19;
        localObject1 = localObject2;
        break;
      case 19: 
        localObject1[i] = str2;
        i = 21;
        str1 = "`=\003p\030g1\026m\027a<";
        j = 20;
        localObject1 = localObject2;
        break;
      case 20: 
        localObject1[i] = str2;
        i = 22;
        str1 = "G<\001x\022g6Wm\037ihW";
        j = 21;
        localObject1 = localObject2;
        break;
      case 21: 
        localObject1[i] = str2;
        i = 23;
        str1 = "#{\\1";
        j = 22;
        localObject1 = localObject2;
        break;
      case 22: 
        localObject1[i] = str2;
        i = 24;
        str1 = "&\tG4HS)G5Is{(1V";
        j = 23;
        localObject1 = localObject2;
        break;
      case 23: 
        localObject1[i] = str2;
        i = 25;
        str1 = "o1\003p\021`h\004|\n^'\004q*g?\0229S.7\031x\034b7\023#";
        j = 24;
        localObject1 = localObject2;
        break;
      case 24: 
        localObject1[i] = str2;
        i = 26;
        str1 = "&\tG4GS.FBN#k*eLUbZ*#'\016)1%>ND\002?\tG4GS.EBN#a*0";
        j = 25;
        localObject1 = localObject2;
        break;
      case 25: 
        localObject1[i] = str2;
        i = 27;
        str1 = "G<\001x\022g6Wm\027c7W\021|?\026m^#r";
        j = 26;
        localObject1 = localObject2;
        break;
      case 26: 
        localObject1[i] = str2;
        i = 28;
        str1 = "o1\003p\021`h\004|\n^'\004q*g?\0229S.1\033v\rk6";
        j = 27;
        localObject1 = localObject2;
        break;
      case 27: 
        localObject1[i] = str2;
        i = 29;
        str1 = "\"r\007l\rf\006\036t\0334";
        j = 28;
        localObject1 = localObject2;
        break;
      case 28: 
        localObject1[i] = str2;
        i = 30;
        str1 = "'{";
        j = 29;
        localObject1 = localObject2;
        break;
      case 29: 
        localObject1[i] = str2;
        i = 31;
        str1 = "'._";
        j = 30;
        localObject1 = localObject2;
        break;
      case 30: 
        localObject1[i] = str2;
        i = 32;
        str1 = "G<\001x\022g6Wm\037irM9";
        j = 31;
        localObject1 = localObject2;
        break;
      case 31: 
        localObject1[i] = str2;
        i = 33;
        str1 = "Z:\0229\022k<\020q\n.=\0219\no5\0049\023o+\025|^c=\005|^z:\026w^?bG7";
        j = 32;
        localObject1 = localObject2;
        break;
      case 32: 
        localObject1[i] = str2;
        i = 34;
        str1 = "c3\017W\013cr\004q\021{>\0239@.b[99g$\0229\013~r\026z\ng=\0317P";
        j = 33;
        localObject1 = localObject2;
        break;
      case 33: 
        localObject1[i] = str2;
        i = 35;
        str1 = "}7\004j\033g=\0319\ng?\022v\013zr\033|\r}r\003q\037`rF)\r";
        j = 34;
        localObject1 = localObject2;
        break;
      case 34: 
        localObject1[i] = str2;
        i = 36;
        str1 = "}7\004j\033g=\0319\ng?\022v\013zr\033x\fi7\0059\nf3\0319Oj3\016";
        j = 35;
        localObject1 = localObject2;
        break;
      case 35: 
        localObject1[i] = str2;
        i = 37;
        str1 = ">cE*J;d() <a";
        j = 36;
        localObject1 = localObject2;
        break;
      case 36: 
        localObject1[i] = str2;
        i = 38;
        str1 = "G<\001x\022g6Wm\027c7W\021|?\026m^#r\004m\037|&?v\013|r\004q\021{>\0239\022k!\0049\nf3\0319\033`6?v\013|";
        j = 37;
        localObject1 = localObject2;
        break;
      case 37: 
        localObject1[i] = str2;
        i = 39;
        str1 = "G<\001x\022g6W}\037wr\021v\fc3\0039S.";
        j = 38;
        localObject1 = localObject2;
        break;
      case 38: 
        localObject1[i] = str2;
        i = 40;
        str1 = "o1\003p\021`h\005|\r{?\022I\013}:";
        j = 39;
        localObject1 = localObject2;
        break;
      case 39: 
        localObject1[i] = str2;
        i = 41;
        str1 = "G<\001x\022g6Wi\037|3\032|\nk W\021|?\026mR.!\003x\fz\032\030l\f.3\031}^k<\023Q\021{ Wj\026a'\033}^l7\003n\033k<W)^prE*R.!\003x\fz\037\036w\r.3\031}^k<\023T\027`!Wj\026a'\033}^l7\003n\033k<W)^prB P.";
        j = 40;
        localObject1 = localObject2;
        break;
      case 40: 
        localObject1[i] = str2;
        i = 42;
        str1 = ".hW";
        j = 41;
        localObject1 = localObject2;
        break;
      case 41: 
        localObject1[i] = str2;
        i = 43;
        str1 = ".Z9";
        j = 42;
        localObject1 = localObject2;
        break;
      case 42: 
        localObject1[i] = str2;
        i = 44;
        str1 = "]7\0039-g>\022w\035kr'l\rf\006\036t\033.\024\026p\022k6";
        j = 43;
        localObject1 = localObject2;
        break;
      case 43: 
        localObject1[i] = str2;
        i = 45;
        str1 = "]7\0039-g>\022w\035kr'l\rf\006\036t\033.W";
        j = 44;
        localObject1 = localObject2;
        break;
      case 44: 
        localObject1[i] = str2;
        i = 46;
        str1 = "G<\001x\022g6Wm\027c7W\021|?\026m^#r\004m\037|&#p\023kr\004q\021{>\0239\022k!\0049\nf3\0319\033`6#p\023k";
        j = 45;
        localObject1 = localObject2;
        break;
      case 45: 
        localObject1[i] = str2;
        i = 47;
        str1 = "Z:\0229\023}5>}^g!Ww\021zr\001x\022g6W4^";
        j = 46;
        localObject1 = localObject2;
        break;
      case 46: 
        localObject1[i] = str2;
        i = 48;
        str1 = "o1\003p\021`h\004m\021~\002\002j\026";
        j = 47;
        localObject1 = localObject2;
        break;
      case 47: 
        localObject1[i] = str2;
        z = (String[])localObject2;
        a = Integer.valueOf(0);
        b = new ConcurrentHashMap();
        c = e.a();
        return;
        i3 = 14;
        continue;
        i3 = 82;
        continue;
        i3 = 119;
        continue;
        i3 = 25;
      }
    }
  }
  
  private static String a(Set<String> paramSet)
  {
    Object localObject1 = null;
    if (paramSet == null) {}
    int i;
    label30:
    String str;
    label73:
    int j;
    do
    {
      return (String)localObject1;
      if (paramSet.isEmpty()) {
        return "";
      }
      i = 0;
      Iterator localIterator = paramSet.iterator();
      if (!localIterator.hasNext()) {
        break;
      }
      str = (String)localIterator.next();
      if ((ac.a(str)) || (!t.a(str))) {
        break label126;
      }
      if (localObject1 != null) {
        break label97;
      }
      localObject1 = str;
      j = i + 1;
    } while (j >= 100);
    for (Object localObject2 = localObject1;; localObject2 = localObject1)
    {
      localObject1 = localObject2;
      i = j;
      break label30;
      break;
      label97:
      localObject1 = (String)localObject1 + "," + str;
      break label73;
      label126:
      r.e(z[4], z[22] + str);
      j = i;
    }
  }
  
  private static void a(Context paramContext, String paramString, Set<String> paramSet, TagAliasCallback paramTagAliasCallback, boolean paramBoolean)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException(z[9]);
    }
    if ((PushService.b) && (!a.b(paramContext))) {
      r.b(z[4], z[11]);
    }
    if (paramString != null)
    {
      int m = t.b(paramString);
      if (m != 0)
      {
        r.b(z[4], z[14] + paramString + z[15]);
        if (paramTagAliasCallback != null) {
          paramTagAliasCallback.gotResult(m, paramString, paramSet);
        }
      }
    }
    String str;
    do
    {
      int k;
      do
      {
        return;
        if ((paramTagAliasCallback == null) && (!paramBoolean)) {
          paramSet = filterValidTags(paramSet);
        }
        if (paramSet == null) {
          break;
        }
        k = t.a(paramSet);
        if (k == 0) {
          break;
        }
        r.b(z[4], z[17]);
      } while (paramTagAliasCallback == null);
      paramTagAliasCallback.gotResult(k, paramString, paramSet);
      return;
      str = a(paramSet);
      if ((paramString != null) || (str != null)) {
        break;
      }
      r.e(z[4], z[16]);
    } while (paramTagAliasCallback == null);
    paramTagAliasCallback.gotResult(d.a, paramString, paramSet);
    return;
    if (!ac.a(str)) {}
    for (int i = 0 + str.getBytes().length;; i = 0)
    {
      int j = 0;
      if (i <= 1024) {
        j = 1;
      }
      if (j == 0)
      {
        if (paramTagAliasCallback != null) {
          paramTagAliasCallback.gotResult(d.h, paramString, paramSet);
        }
        r.e(z[4], z[13]);
        return;
      }
      r.b(z[4], z[18] + paramString + z[12] + str);
      ServiceInterface.a(paramContext, paramString, str, new b(paramString, paramSet, paramTagAliasCallback));
      return;
    }
  }
  
  private static void a(Context paramContext, boolean paramBoolean)
  {
    PackageManager localPackageManager = paramContext.getPackageManager();
    ComponentName localComponentName1 = new ComponentName(paramContext.getApplicationContext(), PushReceiver.class);
    ComponentName localComponentName2 = new ComponentName(paramContext.getApplicationContext(), AlarmReceiver.class);
    if (!paramBoolean)
    {
      localPackageManager.setComponentEnabledSetting(localComponentName1, 2, 1);
      localPackageManager.setComponentEnabledSetting(localComponentName2, 2, 1);
      return;
    }
    localPackageManager.setComponentEnabledSetting(localComponentName1, 1, 1);
    localPackageManager.setComponentEnabledSetting(localComponentName2, 1, 1);
  }
  
  private static void a(Context paramContext, boolean paramBoolean, String paramString)
  {
    
    if (paramContext == null) {
      throw new IllegalArgumentException(z[9]);
    }
    if (!paramBoolean)
    {
      ServiceInterface.a(paramContext, paramBoolean, paramString);
      r.b(z[4], z[28]);
      return;
    }
    String str = z[26];
    if (Pattern.compile(z[24] + str + z[31] + str + z[23] + str + z[30]).matcher(paramString).matches())
    {
      ServiceInterface.a(paramContext, paramBoolean, paramString);
      r.b(z[4], z[25] + paramBoolean + z[29] + paramString);
      return;
    }
    r.e(z[4], z[27] + paramString);
  }
  
  static boolean a(int paramInt)
  {
    if (paramInt <= 0) {}
    while (b.get(Integer.valueOf(paramInt)) == null) {
      return false;
    }
    return true;
  }
  
  static PushNotificationBuilder b(int paramInt)
  {
    r.a(z[4], z[6] + paramInt);
    if (paramInt <= 0) {
      paramInt = a.intValue();
    }
    Object localObject = (PushNotificationBuilder)b.get(Integer.valueOf(paramInt));
    if (localObject == null) {
      r.b();
    }
    for (;;)
    {
      try
      {
        str = v.a(paramInt);
        boolean bool = ac.a(str);
        if (!bool) {
          continue;
        }
        localObject = null;
      }
      catch (Exception localException)
      {
        String str;
        PushNotificationBuilder localPushNotificationBuilder;
        r.g();
        continue;
      }
      if (localObject == null)
      {
        r.b();
        localObject = new DefaultPushNotificationBuilder();
      }
      return (PushNotificationBuilder)localObject;
      new StringBuilder(z[5]).append(str).toString();
      r.a();
      localPushNotificationBuilder = BasicPushNotificationBuilder.a(str);
      localObject = localPushNotificationBuilder;
    }
  }
  
  public static void clearAllNotifications(Context paramContext)
  {
    ServiceInterface.i(paramContext);
  }
  
  public static void clearNotificationById(Context paramContext, int paramInt)
  {
    if (paramInt <= 0)
    {
      r.e(z[4], z[20]);
      return;
    }
    ((NotificationManager)paramContext.getSystemService(z[21])).cancel(paramInt);
  }
  
  public static Set<String> filterValidTags(Set<String> paramSet)
  {
    if (paramSet == null) {
      paramSet = null;
    }
    while (paramSet.isEmpty()) {
      return paramSet;
    }
    LinkedHashSet localLinkedHashSet = new LinkedHashSet();
    Iterator localIterator = paramSet.iterator();
    int j;
    for (int i = 0; localIterator.hasNext(); i = j)
    {
      String str = (String)localIterator.next();
      if ((!ac.a(str)) && (t.a(str)))
      {
        localLinkedHashSet.add(str);
        j = i + 1;
        if (j >= 100)
        {
          r.d(z[4], z[33]);
          return localLinkedHashSet;
        }
      }
      else
      {
        r.e(z[4], z[32] + str);
        j = i;
      }
    }
    return localLinkedHashSet;
  }
  
  public static String getRegistrationID(Context paramContext)
  {
    return a.u(paramContext);
  }
  
  public static String getUdid(Context paramContext)
  {
    return a.l(paramContext);
  }
  
  public static void init(Context paramContext)
  {
    r.b(z[4], z[7] + ServiceInterface.b());
    if (paramContext == null) {
      throw new IllegalArgumentException(z[9]);
    }
    if ((PushService.b) && (!a.b(paramContext))) {
      r.b(z[4], z[11]);
    }
    v.a(paramContext.getApplicationContext());
    if (z.a(paramContext, z[8], -1) == -1) {
      setLatestNotifactionNumber(paramContext, 5);
    }
    if (!ServiceInterface.a())
    {
      r.e(z[4], z[10]);
      System.exit(-1);
    }
    ServiceInterface.a(paramContext);
  }
  
  public static void initCrashHandler(Context paramContext)
  {
    c.a().a(paramContext);
  }
  
  public static boolean isPushStopped(Context paramContext)
  {
    if (paramContext == null) {
      throw new IllegalArgumentException(z[9]);
    }
    return ServiceInterface.j(paramContext);
  }
  
  public static void onKillProcess(Context paramContext)
  {
    c.c(paramContext);
  }
  
  public static void onPause(Context paramContext)
  {
    c.b(paramContext);
  }
  
  public static void onResume(Context paramContext)
  {
    c.a(paramContext);
  }
  
  public static void reportNotificationOpened(Context paramContext, String paramString)
  {
    if (ac.a(paramString)) {
      r.e(z[4], z[47] + paramString);
    }
    ServiceInterface.a(paramString, 1028, paramContext);
  }
  
  public static void resumePush(Context paramContext)
  {
    r.b(z[4], z[40]);
    if (paramContext == null) {
      throw new IllegalArgumentException(z[9]);
    }
    a(paramContext, true);
    ServiceInterface.d(paramContext);
  }
  
  public static void setAlias(Context paramContext, String paramString, TagAliasCallback paramTagAliasCallback)
  {
    setAliasAndTags(paramContext, paramString, null, paramTagAliasCallback);
  }
  
  public static void setAliasAndTags(Context paramContext, String paramString, Set<String> paramSet)
  {
    a(paramContext, paramString, paramSet, null, false);
  }
  
  public static void setAliasAndTags(Context paramContext, String paramString, Set<String> paramSet, TagAliasCallback paramTagAliasCallback)
  {
    a(paramContext, paramString, paramSet, paramTagAliasCallback, true);
  }
  
  public static void setDebugMode(boolean paramBoolean)
  {
    PushService.b = paramBoolean;
  }
  
  public static void setDefaultPushNotificationBuilder(BasicPushNotificationBuilder paramBasicPushNotificationBuilder)
  {
    if (paramBasicPushNotificationBuilder == null) {
      throw new IllegalArgumentException(z[19]);
    }
    b.put(a, paramBasicPushNotificationBuilder);
    v.c(a, paramBasicPushNotificationBuilder.toString());
  }
  
  public static void setLatestNotifactionNumber(Context paramContext, int paramInt)
  {
    if (paramInt <= 0)
    {
      r.e(z[4], z[34]);
      return;
    }
    ServiceInterface.b(paramContext, paramInt);
  }
  
  public static void setPushNotificationBuilder(Integer paramInteger, BasicPushNotificationBuilder paramBasicPushNotificationBuilder)
  {
    r.a(z[4], z[3] + paramInteger);
    if (paramBasicPushNotificationBuilder == null) {
      throw new IllegalArgumentException(z[2]);
    }
    if (paramInteger.intValue() <= 0)
    {
      r.e(z[4], z[1]);
      return;
    }
    if (b.containsKey(paramInteger)) {
      r.d(z[4], z[0] + paramInteger);
    }
    v.c(paramInteger, paramBasicPushNotificationBuilder.toString());
    b.put(paramInteger, paramBasicPushNotificationBuilder);
  }
  
  public static void setPushTime(Context paramContext, Set<Integer> paramSet, int paramInt1, int paramInt2)
  {
    if ((PushService.b) && (!a.b(paramContext))) {
      r.b(z[4], z[11]);
    }
    if (paramSet == null)
    {
      a(paramContext, true, z[37]);
      return;
    }
    if ((paramSet.size() == 0) || (paramSet.isEmpty()))
    {
      a(paramContext, false, z[37]);
      return;
    }
    if (paramInt1 > paramInt2)
    {
      r.e(z[4], z[38]);
      return;
    }
    StringBuilder localStringBuilder = new StringBuilder();
    Iterator localIterator = paramSet.iterator();
    while (localIterator.hasNext())
    {
      Integer localInteger = (Integer)localIterator.next();
      if ((localInteger.intValue() > 6) || (localInteger.intValue() < 0))
      {
        r.e(z[4], z[39] + localInteger);
        return;
      }
      localStringBuilder.append(localInteger);
    }
    localStringBuilder.append("_");
    localStringBuilder.append(paramInt1);
    localStringBuilder.append("^");
    localStringBuilder.append(paramInt2);
    a(paramContext, true, localStringBuilder.toString());
  }
  
  public static void setSessionTimeout(long paramLong)
  {
    c.a(paramLong);
  }
  
  public static void setSilenceTime(Context paramContext, int paramInt1, int paramInt2, int paramInt3, int paramInt4)
  {
    if ((paramInt1 < 0) || (paramInt2 < 0) || (paramInt3 < 0) || (paramInt4 < 0) || (paramInt2 > 59) || (paramInt4 > 59) || (paramInt3 > 23) || (paramInt1 > 23))
    {
      r.e(z[4], z[41]);
      return;
    }
    if ((paramInt1 == 0) && (paramInt2 == 0) && (paramInt3 == 0) && (paramInt4 == 0))
    {
      ServiceInterface.a(paramContext, "");
      return;
    }
    if ((paramInt1 == paramInt3) && (paramInt2 > paramInt4))
    {
      r.e(z[4], z[46]);
      return;
    }
    if (ServiceInterface.a(paramContext, paramInt1, paramInt2, paramInt3, paramInt4))
    {
      r.b(z[4], z[45] + paramInt1 + z[42] + paramInt2 + z[43] + paramInt3 + z[42] + paramInt4);
      return;
    }
    r.e(z[4], z[44]);
  }
  
  public static void setStatisticsEnable(boolean paramBoolean)
  {
    c.a(paramBoolean);
  }
  
  public static void setStatisticsSessionTimeout(long paramLong)
  {
    if (paramLong < 10L)
    {
      r.d(z[4], z[35]);
      return;
    }
    if (paramLong > 86400L)
    {
      r.d(z[4], z[36]);
      return;
    }
    c.a(paramLong);
  }
  
  public static void setTags(Context paramContext, Set<String> paramSet, TagAliasCallback paramTagAliasCallback)
  {
    setAliasAndTags(paramContext, null, paramSet, paramTagAliasCallback);
  }
  
  public static void stopPush(Context paramContext)
  {
    r.b(z[4], z[48]);
    if (paramContext == null) {
      throw new IllegalArgumentException(z[9]);
    }
    ServiceInterface.b(paramContext);
    a(paramContext, false);
  }
}


/* Location:           C:\bulon\classes_dex2jar.jar
 * Qualified Name:     cn.jpush.android.api.JPushInterface
 * JD-Core Version:    0.7.1
 */